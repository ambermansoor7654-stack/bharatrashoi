ALTER TABLE public.channels ADD COLUMN banner_path text;
ALTER TABLE public.channels ADD COLUMN avatar_path text;

CREATE POLICY "Channel owners upload channel images" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'channel-images' AND (storage.foldername(name))[1] = auth.uid()::text AND EXISTS (SELECT 1 FROM public.channels WHERE owner_id = auth.uid()));
CREATE POLICY "Owners and public read channel images" ON storage.objects FOR SELECT TO anon, authenticated USING (bucket_id = 'channel-images' AND ((storage.foldername(name))[1] = auth.uid()::text OR EXISTS (SELECT 1 FROM public.channels WHERE avatar_path = name OR banner_path = name)));
CREATE POLICY "Channel owners update channel images" ON storage.objects FOR UPDATE TO authenticated USING (bucket_id = 'channel-images' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "Channel owners remove channel images" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'channel-images' AND (storage.foldername(name))[1] = auth.uid()::text);