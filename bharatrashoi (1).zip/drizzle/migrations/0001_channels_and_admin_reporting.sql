CREATE TABLE public.channels (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL UNIQUE,
  name text NOT NULL CHECK (char_length(name) BETWEEN 2 AND 60),
  handle text NOT NULL CHECK (handle ~ '^[a-z0-9_]{3,30}$'),
  description text NOT NULL DEFAULT '' CHECK (char_length(description) <= 500),
  monetized boolean NOT NULL DEFAULT false,
  monetized_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX channels_handle_lower_key ON public.channels (lower(handle));
GRANT SELECT ON public.channels TO anon, authenticated;
GRANT INSERT (owner_id, name, handle, description), UPDATE (name, handle, description), DELETE ON public.channels TO authenticated;
GRANT ALL ON public.channels TO service_role;
ALTER TABLE public.channels ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Channels are public" ON public.channels FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Users create own channel" ON public.channels FOR INSERT TO authenticated WITH CHECK (owner_id = auth.uid());
CREATE POLICY "Users update own channel" ON public.channels FOR UPDATE TO authenticated USING (owner_id = auth.uid()) WITH CHECK (owner_id = auth.uid());
CREATE POLICY "Users delete own channel" ON public.channels FOR DELETE TO authenticated USING (owner_id = auth.uid());
CREATE TRIGGER channels_updated_at BEFORE UPDATE ON public.channels FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.channel_videos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  channel_id uuid NOT NULL REFERENCES public.channels(id) ON DELETE CASCADE,
  owner_id uuid NOT NULL,
  title text NOT NULL CHECK (char_length(title) BETWEEN 2 AND 100),
  description text NOT NULL DEFAULT '' CHECK (char_length(description) <= 1000),
  state text NOT NULL DEFAULT 'Other',
  video_path text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX channel_videos_created_idx ON public.channel_videos (created_at DESC);
GRANT SELECT ON public.channel_videos TO anon, authenticated;
GRANT INSERT (channel_id, owner_id, title, description, state, video_path), DELETE ON public.channel_videos TO authenticated;
GRANT ALL ON public.channel_videos TO service_role;
ALTER TABLE public.channel_videos ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Channel videos are public" ON public.channel_videos FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Owners publish to own channel" ON public.channel_videos FOR INSERT TO authenticated WITH CHECK (
  owner_id = auth.uid() AND split_part(video_path, '/', 1) = auth.uid()::text
  AND EXISTS (SELECT 1 FROM public.channels c WHERE c.id = channel_id AND c.owner_id = auth.uid())
);
CREATE POLICY "Owners delete own videos" ON public.channel_videos FOR DELETE TO authenticated USING (owner_id = auth.uid());

CREATE TABLE public.daily_logins (
  user_id uuid NOT NULL,
  day date NOT NULL,
  email text,
  provider text,
  first_at timestamptz NOT NULL DEFAULT now(),
  last_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, day)
);
GRANT ALL ON public.daily_logins TO service_role;
ALTER TABLE public.daily_logins ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.failed_logins (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  method text NOT NULL,
  reason text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX failed_logins_created_idx ON public.failed_logins (created_at DESC);
GRANT ALL ON public.failed_logins TO service_role;
ALTER TABLE public.failed_logins ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.site_visits (
  visitor_id text NOT NULL CHECK (char_length(visitor_id) BETWEEN 8 AND 80),
  day date NOT NULL,
  first_path text,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (visitor_id, day)
);
GRANT ALL ON public.site_visits TO service_role;
ALTER TABLE public.site_visits ENABLE ROW LEVEL SECURITY;