DROP POLICY IF EXISTS "Follows are public" ON public.follows;
CREATE POLICY "Published creator follows are readable"
ON public.follows
FOR SELECT
TO anon, authenticated
USING (
  follower_id = auth.uid()
  OR creator_id = auth.uid()
  OR EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = follows.creator_id
      AND (p.is_creator = true OR p.creator_status = 'approved')
  )
);

DROP POLICY IF EXISTS "Ratings are public" ON public.recipe_ratings;
CREATE POLICY "Published recipe ratings are readable"
ON public.recipe_ratings
FOR SELECT
TO anon, authenticated
USING (
  user_id = auth.uid()
  OR EXISTS (
    SELECT 1 FROM public.recipes r
    WHERE r.id = recipe_ratings.recipe_id
      AND r.published = true
  )
);

DROP POLICY IF EXISTS "Public identity is readable" ON public.profiles;
CREATE POLICY "Relevant public identities are readable"
ON public.profiles
FOR SELECT
TO anon, authenticated
USING (
  id = auth.uid()
  OR public.has_role(auth.uid(), 'admin'::public.app_role)
  OR is_creator = true
  OR creator_status = 'approved'
  OR EXISTS (
    SELECT 1 FROM public.recipes r
    WHERE r.author_id = profiles.id
      AND r.published = true
  )
);

DROP POLICY IF EXISTS "Save counts are public" ON public.recipe_saves;
CREATE POLICY "Published recipe saves are readable"
ON public.recipe_saves
FOR SELECT
TO anon, authenticated
USING (
  user_id = auth.uid()
  OR EXISTS (
    SELECT 1 FROM public.recipes r
    WHERE r.id = recipe_saves.recipe_id
      AND r.published = true
  )
);

DROP POLICY IF EXISTS "Likes are public" ON public.recipe_likes;
CREATE POLICY "Published recipe likes are readable"
ON public.recipe_likes
FOR SELECT
TO anon, authenticated
USING (
  user_id = auth.uid()
  OR EXISTS (
    SELECT 1 FROM public.recipes r
    WHERE r.id = recipe_likes.recipe_id
      AND r.published = true
  )
);

DROP POLICY IF EXISTS "Public read recipe images" ON storage.objects;
DROP POLICY IF EXISTS "Anyone can read avatars" ON storage.objects;
DROP POLICY IF EXISTS "Anyone can read recipe images" ON storage.objects;
DROP POLICY IF EXISTS "Anyone can read recipe videos" ON storage.objects;

CREATE POLICY "Referenced recipe images are readable"
ON storage.objects
FOR SELECT
TO anon, authenticated
USING (
  bucket_id = 'recipe-images'
  AND (
    owner_id = auth.uid()::text
    OR EXISTS (
      SELECT 1 FROM public.recipes r
      WHERE r.published = true
        AND (
          r.image_url = storage.objects.name
          OR r.cover_image_url = storage.objects.name
          OR r.images ? storage.objects.name
        )
    )
  )
);

CREATE POLICY "Referenced avatars are readable"
ON storage.objects
FOR SELECT
TO anon, authenticated
USING (
  bucket_id = 'avatars'
  AND (
    owner_id = auth.uid()::text
    OR EXISTS (
      SELECT 1 FROM public.profiles p
      WHERE p.avatar_url = storage.objects.name
        AND (
          p.is_creator = true
          OR p.creator_status = 'approved'
          OR EXISTS (
            SELECT 1 FROM public.recipes r
            WHERE r.author_id = p.id
              AND r.published = true
          )
        )
    )
  )
);

CREATE POLICY "Referenced recipe videos are readable"
ON storage.objects
FOR SELECT
TO anon, authenticated
USING (
  bucket_id = 'recipe-videos'
  AND (
    owner_id = auth.uid()::text
    OR EXISTS (
      SELECT 1 FROM public.recipes r
      WHERE r.published = true
        AND r.video_url = storage.objects.name
    )
  )
);