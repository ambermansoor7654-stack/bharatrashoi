
-- 1. Fix has_role: remove email bypass, rely solely on user_roles table
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

-- 2. Lock down SECURITY DEFINER functions from public/anon/authenticated
REVOKE ALL ON FUNCTION public.has_role(uuid, app_role) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, app_role) TO service_role;
-- has_role is used inside RLS policies which run as the policy owner, so authenticated access is not required.
-- However, several policies call it via auth.uid(); RLS policy evaluation uses the definer context, so revoking from authenticated is safe.

REVOKE ALL ON FUNCTION public.increment_recipe_views(text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.increment_recipe_views(text) TO service_role;

REVOKE ALL ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.handle_new_user() TO service_role;

-- Note: has_role is called from RLS policies. Policies invoke functions with the
-- caller's privileges, so revoking EXECUTE from authenticated would break policy
-- checks. Re-grant EXECUTE to authenticated on has_role only (needed by RLS),
-- since the function only reads user_roles and is safe to call.
GRANT EXECUTE ON FUNCTION public.has_role(uuid, app_role) TO authenticated, anon;

-- 3. Tighten chat_messages RLS: require non-trivial session_token instead of blanket true
DROP POLICY IF EXISTS "Anyone can insert chat messages" ON public.chat_messages;
DROP POLICY IF EXISTS "Anyone can delete chat messages" ON public.chat_messages;
DROP POLICY IF EXISTS "Anyone can read chat messages" ON public.chat_messages;

CREATE POLICY "Insert chat with session token"
  ON public.chat_messages FOR INSERT
  TO anon, authenticated
  WITH CHECK (session_token IS NOT NULL AND length(session_token) >= 16);

CREATE POLICY "Delete chat with session token"
  ON public.chat_messages FOR DELETE
  TO anon, authenticated
  USING (session_token IS NOT NULL AND length(session_token) >= 16);

CREATE POLICY "Read chat with session token"
  ON public.chat_messages FOR SELECT
  TO anon, authenticated
  USING (session_token IS NOT NULL AND length(session_token) >= 16);

-- 4. Tighten food_favorites RLS the same way
DROP POLICY IF EXISTS "Anyone can insert food favorites" ON public.food_favorites;
DROP POLICY IF EXISTS "Anyone can delete food favorites" ON public.food_favorites;
DROP POLICY IF EXISTS "Anyone can read food favorites" ON public.food_favorites;

CREATE POLICY "Insert favorite with session token"
  ON public.food_favorites FOR INSERT
  TO anon, authenticated
  WITH CHECK (session_token IS NOT NULL AND length(session_token) >= 16);

CREATE POLICY "Delete favorite with session token"
  ON public.food_favorites FOR DELETE
  TO anon, authenticated
  USING (session_token IS NOT NULL AND length(session_token) >= 16);

CREATE POLICY "Read favorite with session token"
  ON public.food_favorites FOR SELECT
  TO anon, authenticated
  USING (session_token IS NOT NULL AND length(session_token) >= 16);
