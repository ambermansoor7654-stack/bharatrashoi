-- 1. PROFILES: public identity + creator status
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS username text,
  ADD COLUMN IF NOT EXISTS display_name text,
  ADD COLUMN IF NOT EXISTS bio text,
  ADD COLUMN IF NOT EXISTS location text,
  ADD COLUMN IF NOT EXISTS food_preferences text[] NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS specialties text[] NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS onboarded boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS is_creator boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS creator_status text NOT NULL DEFAULT 'none';

CREATE UNIQUE INDEX IF NOT EXISTS profiles_username_lower_key ON public.profiles (lower(username)) WHERE username IS NOT NULL;

-- Public identity is readable by everyone; email is NOT (column-level privileges).
REVOKE SELECT ON public.profiles FROM anon, authenticated;
GRANT SELECT (id, username, display_name, name, bio, location, avatar_url, food_preferences, specialties,
              is_creator, creator_status, verified, onboarded, created_at) ON public.profiles TO anon;
GRANT SELECT (id, username, display_name, name, bio, location, avatar_url, food_preferences, specialties,
              is_creator, creator_status, verified, onboarded, created_at, is_premium, premium_plan,
              premium_expiry_date, premium_start_date) ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;

DROP POLICY IF EXISTS "Users read own profile" ON public.profiles;
CREATE POLICY "Public identity is readable" ON public.profiles
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "Users update own profile" ON public.profiles;
CREATE POLICY "Users update own profile" ON public.profiles
  FOR UPDATE TO authenticated USING (id = auth.uid()) WITH CHECK (id = auth.uid());
GRANT UPDATE (username, display_name, bio, location, avatar_url, food_preferences, onboarded, updated_at)
  ON public.profiles TO authenticated;

-- 2. CREATOR APPLICATIONS
CREATE TABLE IF NOT EXISTS public.creator_applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  bio text NOT NULL DEFAULT '',
  specialties text[] NOT NULL DEFAULT '{}',
  location text,
  message text,
  status text NOT NULL DEFAULT 'pending',
  reviewed_by uuid,
  reviewed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS creator_applications_open_key
  ON public.creator_applications (user_id) WHERE status = 'pending';
GRANT SELECT, INSERT ON public.creator_applications TO authenticated;
GRANT ALL ON public.creator_applications TO service_role;
ALTER TABLE public.creator_applications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users read own application" ON public.creator_applications
  FOR SELECT TO authenticated USING (user_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Users create own application" ON public.creator_applications
  FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid() AND status = 'pending');
CREATE TRIGGER creator_applications_set_updated_at BEFORE UPDATE ON public.creator_applications
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- 3. RECIPES: authorship + publishing workflow
ALTER TABLE public.recipes
  ADD COLUMN IF NOT EXISTS author_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'published',
  ADD COLUMN IF NOT EXISTS locked boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS servings integer,
  ADD COLUMN IF NOT EXISTS cuisine text,
  ADD COLUMN IF NOT EXISTS spice_level text,
  ADD COLUMN IF NOT EXISTS chef_tips text,
  ADD COLUMN IF NOT EXISTS cover_image_url text,
  ADD COLUMN IF NOT EXISTS images jsonb NOT NULL DEFAULT '[]'::jsonb;

UPDATE public.recipes SET author_id = created_by WHERE author_id IS NULL AND created_by IS NOT NULL;
UPDATE public.recipes SET status = CASE WHEN published THEN 'published' ELSE 'draft' END;
UPDATE public.recipes SET locked = true WHERE published;

CREATE INDEX IF NOT EXISTS recipes_author_idx ON public.recipes (author_id);
CREATE INDEX IF NOT EXISTS recipes_status_idx ON public.recipes (status);

DROP POLICY IF EXISTS "Authenticated can read published or all if admin" ON public.recipes;
CREATE POLICY "Read published, own drafts, or admin" ON public.recipes
  FOR SELECT TO authenticated
  USING (published = true OR author_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Approved creators insert drafts" ON public.recipes
  FOR INSERT TO authenticated
  WITH CHECK (
    author_id = auth.uid()
    AND published = false
    AND status IN ('draft', 'pending')
    AND locked = false
    AND EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.creator_status = 'approved')
  );

CREATE POLICY "Creators update own unpublished recipes" ON public.recipes
  FOR UPDATE TO authenticated
  USING (author_id = auth.uid() AND published = false AND locked = false)
  WITH CHECK (author_id = auth.uid() AND published = false AND locked = false AND status IN ('draft', 'pending'));

CREATE POLICY "Creators delete own unpublished recipes" ON public.recipes
  FOR DELETE TO authenticated
  USING (author_id = auth.uid() AND published = false AND locked = false);

-- 4. LIKES / SAVES / FOLLOWS / RATINGS
CREATE TABLE IF NOT EXISTS public.recipe_likes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  recipe_id uuid NOT NULL REFERENCES public.recipes(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, recipe_id)
);
GRANT SELECT, INSERT, DELETE ON public.recipe_likes TO authenticated;
GRANT SELECT ON public.recipe_likes TO anon;
GRANT ALL ON public.recipe_likes TO service_role;
ALTER TABLE public.recipe_likes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Likes are public" ON public.recipe_likes FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Users like as themselves" ON public.recipe_likes FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "Users remove own like" ON public.recipe_likes FOR DELETE TO authenticated USING (user_id = auth.uid());

CREATE TABLE IF NOT EXISTS public.recipe_saves (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  recipe_id uuid NOT NULL REFERENCES public.recipes(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, recipe_id)
);
GRANT SELECT, INSERT, DELETE ON public.recipe_saves TO authenticated;
GRANT SELECT ON public.recipe_saves TO anon;
GRANT ALL ON public.recipe_saves TO service_role;
ALTER TABLE public.recipe_saves ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Save counts are public" ON public.recipe_saves FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Users save as themselves" ON public.recipe_saves FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "Users remove own save" ON public.recipe_saves FOR DELETE TO authenticated USING (user_id = auth.uid());

CREATE TABLE IF NOT EXISTS public.follows (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  follower_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  creator_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (follower_id, creator_id),
  CHECK (follower_id <> creator_id)
);
GRANT SELECT, INSERT, DELETE ON public.follows TO authenticated;
GRANT SELECT ON public.follows TO anon;
GRANT ALL ON public.follows TO service_role;
ALTER TABLE public.follows ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Follows are public" ON public.follows FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Users follow as themselves" ON public.follows FOR INSERT TO authenticated WITH CHECK (follower_id = auth.uid() AND follower_id <> creator_id);
CREATE POLICY "Users unfollow themselves only" ON public.follows FOR DELETE TO authenticated USING (follower_id = auth.uid());

CREATE TABLE IF NOT EXISTS public.recipe_ratings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  recipe_id uuid NOT NULL REFERENCES public.recipes(id) ON DELETE CASCADE,
  rating smallint NOT NULL CHECK (rating BETWEEN 1 AND 5),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, recipe_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.recipe_ratings TO authenticated;
GRANT SELECT ON public.recipe_ratings TO anon;
GRANT ALL ON public.recipe_ratings TO service_role;
ALTER TABLE public.recipe_ratings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Ratings are public" ON public.recipe_ratings FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Users rate as themselves" ON public.recipe_ratings FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "Users update own rating" ON public.recipe_ratings FOR UPDATE TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE POLICY "Users delete own rating" ON public.recipe_ratings FOR DELETE TO authenticated USING (user_id = auth.uid());
CREATE TRIGGER recipe_ratings_set_updated_at BEFORE UPDATE ON public.recipe_ratings
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- 5. CORRECTION REQUESTS
CREATE TABLE IF NOT EXISTS public.correction_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  recipe_id uuid NOT NULL REFERENCES public.recipes(id) ON DELETE CASCADE,
  requested_by uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  message text NOT NULL,
  status text NOT NULL DEFAULT 'open',
  resolved_by uuid,
  resolved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.correction_requests TO authenticated;
GRANT ALL ON public.correction_requests TO service_role;
ALTER TABLE public.correction_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Read own correction requests" ON public.correction_requests
  FOR SELECT TO authenticated USING (requested_by = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Creators request corrections for own recipes" ON public.correction_requests
  FOR INSERT TO authenticated
  WITH CHECK (
    requested_by = auth.uid()
    AND status = 'open'
    AND EXISTS (SELECT 1 FROM public.recipes r WHERE r.id = recipe_id AND r.author_id = auth.uid())
  );
CREATE TRIGGER correction_requests_set_updated_at BEFORE UPDATE ON public.correction_requests
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- 6. LIVE COUNT SUMMARIES
CREATE OR REPLACE VIEW public.recipe_stats WITH (security_invoker = true) AS
SELECT r.id AS recipe_id,
       (SELECT count(*) FROM public.recipe_likes l WHERE l.recipe_id = r.id) AS likes,
       (SELECT count(*) FROM public.recipe_saves s WHERE s.recipe_id = r.id) AS saves,
       (SELECT count(*) FROM public.recipe_ratings t WHERE t.recipe_id = r.id) AS ratings_count,
       (SELECT coalesce(avg(t.rating), 0)::numeric(3,2) FROM public.recipe_ratings t WHERE t.recipe_id = r.id) AS rating
FROM public.recipes r;
GRANT SELECT ON public.recipe_stats TO anon, authenticated, service_role;

CREATE OR REPLACE VIEW public.profile_stats WITH (security_invoker = true) AS
SELECT p.id AS user_id,
       (SELECT count(*) FROM public.follows f WHERE f.creator_id = p.id) AS followers,
       (SELECT count(*) FROM public.follows f WHERE f.follower_id = p.id) AS following,
       (SELECT count(*) FROM public.recipes r WHERE r.author_id = p.id AND r.published) AS recipes_count,
       (SELECT count(*) FROM public.recipe_likes l JOIN public.recipes r ON r.id = l.recipe_id WHERE r.author_id = p.id) AS likes_received,
       (SELECT count(*) FROM public.recipe_saves s JOIN public.recipes r ON r.id = s.recipe_id WHERE r.author_id = p.id) AS saves_received,
       (SELECT count(*) FROM public.recipe_saves s WHERE s.user_id = p.id) AS saved_count
FROM public.profiles p;
GRANT SELECT ON public.profile_stats TO anon, authenticated, service_role;