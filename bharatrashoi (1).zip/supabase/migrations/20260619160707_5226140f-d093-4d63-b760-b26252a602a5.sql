
DROP POLICY IF EXISTS "Anyone can read published recipes" ON public.recipes;

CREATE POLICY "Anon can read published recipes"
  ON public.recipes FOR SELECT TO anon
  USING (published = true);

CREATE POLICY "Authenticated can read published or all if admin"
  ON public.recipes FOR SELECT TO authenticated
  USING (published = true OR public.has_role(auth.uid(), 'admin'));
