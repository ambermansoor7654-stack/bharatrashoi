-- Remove public column-level access to sensitive profile fields (email, payment_id).
REVOKE SELECT ON public.profiles FROM anon;
REVOKE SELECT ON public.profiles FROM authenticated;

-- anon: only non-sensitive public identity columns
GRANT SELECT (
  id, username, display_name, name, bio, location, avatar_url,
  food_preferences, specialties, is_creator, creator_status, verified,
  onboarded, created_at, updated_at
) ON public.profiles TO anon;

-- authenticated: public identity columns + premium status flags (no email, no payment_id)
GRANT SELECT (
  id, username, display_name, name, bio, location, avatar_url,
  food_preferences, specialties, is_creator, creator_status, verified,
  onboarded, created_at, updated_at,
  is_premium, premium_plan, premium_start_date, premium_expiry_date
) ON public.profiles TO authenticated;

GRANT ALL ON public.profiles TO service_role;