
ALTER TABLE public.recipes
  ADD COLUMN IF NOT EXISTS views bigint NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS video_url text;

CREATE OR REPLACE FUNCTION public.increment_recipe_views(_slug text)
RETURNS bigint
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE new_views bigint;
BEGIN
  UPDATE public.recipes
     SET views = views + 1
   WHERE slug = _slug AND published = true
   RETURNING views INTO new_views;
  RETURN COALESCE(new_views, 0);
END;
$$;

GRANT EXECUTE ON FUNCTION public.increment_recipe_views(text) TO anon, authenticated;

ALTER TABLE public.recipes REPLICA IDENTITY FULL;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND schemaname = 'public' AND tablename = 'recipes'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.recipes;
  END IF;
END $$;
