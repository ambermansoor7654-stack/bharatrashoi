CREATE POLICY "Anyone can read avatars" ON storage.objects
  FOR SELECT TO anon, authenticated USING (bucket_id = 'avatars');

CREATE POLICY "Users upload own avatar" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "Users update own avatar" ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "Users delete own avatar" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "Approved creators upload recipe media" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id IN ('recipe-images', 'recipe-videos')
    AND (storage.foldername(name))[1] = auth.uid()::text
    AND EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.creator_status = 'approved')
  );

CREATE POLICY "Creators manage own recipe media" ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id IN ('recipe-images', 'recipe-videos') AND owner_id = auth.uid()::text);

CREATE POLICY "Creators delete own recipe media" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id IN ('recipe-images', 'recipe-videos') AND owner_id = auth.uid()::text);