
CREATE TABLE public.chat_messages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  session_token TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
  parts JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX chat_messages_session_idx ON public.chat_messages (session_token, created_at);
GRANT SELECT, INSERT, DELETE ON public.chat_messages TO anon, authenticated;
GRANT ALL ON public.chat_messages TO service_role;
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can read chat messages" ON public.chat_messages FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Anyone can insert chat messages" ON public.chat_messages FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Anyone can delete chat messages" ON public.chat_messages FOR DELETE TO anon, authenticated USING (true);

CREATE TABLE public.food_favorites (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  session_token TEXT NOT NULL,
  food_name TEXT NOT NULL,
  food_data JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (session_token, food_name)
);
CREATE INDEX food_favorites_session_idx ON public.food_favorites (session_token, created_at DESC);
GRANT SELECT, INSERT, DELETE ON public.food_favorites TO anon, authenticated;
GRANT ALL ON public.food_favorites TO service_role;
ALTER TABLE public.food_favorites ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can read food favorites" ON public.food_favorites FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Anyone can insert food favorites" ON public.food_favorites FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Anyone can delete food favorites" ON public.food_favorites FOR DELETE TO anon, authenticated USING (true);

ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_messages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.food_favorites;
