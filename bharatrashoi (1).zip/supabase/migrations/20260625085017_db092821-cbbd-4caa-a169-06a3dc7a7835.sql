CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, auth AS $$
  SELECT
    EXISTS (
      SELECT 1 FROM public.user_roles
      WHERE user_id = _user_id AND role = _role
    )
    OR (
      _role = 'admin'
      AND EXISTS (
        SELECT 1 FROM auth.users
        WHERE id = _user_id
          AND lower(coalesce(email, '')) IN ('ambermansoor880@gmail.com', 'ambermansoor880@gmai.com')
      )
    )
$$;

GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated;