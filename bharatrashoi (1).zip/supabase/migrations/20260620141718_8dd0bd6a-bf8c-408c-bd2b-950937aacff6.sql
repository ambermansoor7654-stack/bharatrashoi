
-- recipe-videos bucket: admin write, signed-read by anyone
DROP POLICY IF EXISTS "Admins can upload recipe videos" ON storage.objects;
DROP POLICY IF EXISTS "Admins can update recipe videos" ON storage.objects;
DROP POLICY IF EXISTS "Admins can delete recipe videos" ON storage.objects;
DROP POLICY IF EXISTS "Anyone can read recipe videos" ON storage.objects;

CREATE POLICY "Admins can upload recipe videos" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'recipe-videos' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update recipe videos" ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'recipe-videos' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete recipe videos" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'recipe-videos' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Anyone can read recipe videos" ON storage.objects
  FOR SELECT TO anon, authenticated
  USING (bucket_id = 'recipe-videos');

-- Also ensure recipe-images allows anyone to read (admins already manage writes)
DROP POLICY IF EXISTS "Anyone can read recipe images" ON storage.objects;
CREATE POLICY "Anyone can read recipe images" ON storage.objects
  FOR SELECT TO anon, authenticated
  USING (bucket_id = 'recipe-images');
