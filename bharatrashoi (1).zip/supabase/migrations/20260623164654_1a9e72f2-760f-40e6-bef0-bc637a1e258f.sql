CREATE OR REPLACE FUNCTION public.ensure_current_user_roles()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  _uid uuid := auth.uid();
  _email text := lower(coalesce(auth.jwt() ->> 'email', ''));
  _is_admin boolean := false;
BEGIN
  IF _uid IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  INSERT INTO public.user_roles (user_id, role)
  VALUES (_uid, 'user')
  ON CONFLICT DO NOTHING;

  IF _email = 'ambermansoor880@gmail.com' THEN
    INSERT INTO public.user_roles (user_id, role)
    VALUES (_uid, 'admin')
    ON CONFLICT DO NOTHING;
    _is_admin := true;
  ELSE
    SELECT EXISTS (
      SELECT 1
      FROM public.user_roles
      WHERE user_id = _uid AND role = 'admin'
    ) INTO _is_admin;
  END IF;

  RETURN jsonb_build_object('is_admin', _is_admin, 'email', _email);
END;
$$;

REVOKE EXECUTE ON FUNCTION public.ensure_current_user_roles() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.ensure_current_user_roles() TO authenticated, service_role;