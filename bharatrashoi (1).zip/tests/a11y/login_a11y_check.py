"""Automated accessibility checks for the login page (/auth).
Run: python3 tests/a11y/login_a11y_check.py [chromium firefox webkit]  (dev server on :8080)
Default runs all three engines; webkit is the Safari engine.
Checks desktop + phone: screen-reader labels, keyboard focus ring, reduced motion, lite phone mode."""
import asyncio, sys
from playwright.async_api import async_playwright

URL = "http://localhost:8080/auth"
fails = []
def check(cond, msg):
    print(("PASS " if cond else "FAIL ") + msg)
    if not cond: fails.append(msg)

async def run(p, engine, name, vp, mobile, reduce):
    b = await getattr(p, engine).launch(headless=True)
    name = f"{engine}-{name}"
    ctx = await b.new_context(viewport=vp, is_mobile=mobile and engine != "firefox", has_touch=mobile,
                              reduced_motion="reduce" if reduce else "no-preference")
    pg = await ctx.new_page()
    errs = []; pg.on("pageerror", lambda e: errs.append(str(e)))
    await pg.goto(URL, wait_until="networkidle"); await pg.wait_for_timeout(1200)
    tag = f"[{name}]"
    # Screen-reader labels
    check(await pg.get_by_role("tablist", name="Login method").count() == 1, f"{tag} tablist labelled")
    check(await pg.get_by_role("tab", name="Email", selected=True).count() == 1, f"{tag} Email tab selected")
    check(await pg.get_by_role("button", name="Password", pressed=True).count() == 1, f"{tag} Password pressed state")
    check(await pg.get_by_role("textbox", name="Email").count() >= 1, f"{tag} email input labelled")
    unnamed = await pg.evaluate("""() => [...document.querySelectorAll('.auth-focus button, .auth-focus input, .auth-focus a')]
      .filter(e => !(e.getAttribute('aria-label') || e.textContent.trim() || e.labels?.length || e.placeholder)).length""")
    check(unnamed == 0, f"{tag} every control has an accessible name ({unnamed} unnamed)")
    await pg.get_by_role("tab", name="Phone OTP").click()
    check(await pg.get_by_role("textbox", name="Phone number with country code").count() == 1, f"{tag} phone input labelled")
    check(await pg.get_by_role("tab", name="Phone OTP", selected=True).count() == 1, f"{tag} Phone tab selected after click")
    await pg.get_by_role("tab", name="Email").click()
    # Keyboard focus
    await pg.get_by_role("tab", name="Email").focus()
    await pg.keyboard.press("Tab")
    ring = await pg.evaluate("() => { const s = getComputedStyle(document.activeElement); return [s.outlineStyle, s.outlineWidth, document.activeElement.closest('.auth-focus') !== null] }")
    check(ring[0] == "solid" and ring[1] != "0px" and ring[2], f"{tag} keyboard focus ring visible {ring}")
    await pg.screenshot(path=f"/tmp/browser/a11y_{name}.png")
    # Motion
    orbs = await pg.locator(".auth-focus > div[aria-hidden] > div").count()
    if mobile: check(orbs == 2, f"{tag} lite mode shows 2 orbs ({orbs})")
    else: check(orbs == 4, f"{tag} desktop shows 4 orbs ({orbs})")
    t1 = await pg.evaluate("() => getComputedStyle(document.querySelector('.auth-focus > div[aria-hidden] > div')).transform")
    await pg.wait_for_timeout(700)
    t2 = await pg.evaluate("() => getComputedStyle(document.querySelector('.auth-focus > div[aria-hidden] > div')).transform")
    if reduce: check(t1 == t2, f"{tag} orbs still with reduced motion")
    else: check(t1 != t2, f"{tag} orbs animate normally")
    check(not errs, f"{tag} no page errors {errs[:1]}")
    await b.close()

async def main():
    async with async_playwright() as p:
        engines = sys.argv[1:] or ["chromium", "firefox", "webkit"]  # webkit = Safari engine
        for e in engines:
            await run(p, e, "desktop", {"width":1280,"height":900}, False, False)
            await run(p, e, "desktop-reduced", {"width":1280,"height":900}, False, True)
            await run(p, e, "phone", {"width":390,"height":844}, True, False)
            await run(p, e, "phone-reduced", {"width":320,"height":700}, True, True)
    print("FAILED:" if fails else "ALL PASSED", len(fails)); sys.exit(1 if fails else 0)
asyncio.run(main())
