import { describe, it, expect } from "vitest";

const BASE = process.env.TEST_BASE_URL ?? "http://localhost:8080";

const MCP_HEADERS = {
  "Content-Type": "application/json",
  Accept: "application/json, text/event-stream",
};

const listToolsBody = JSON.stringify({
  jsonrpc: "2.0",
  id: 1,
  method: "tools/list",
});

describe("/mcp auth", () => {
  it("rejects requests with no bearer token (401)", async () => {
    const res = await fetch(`${BASE}/mcp`, {
      method: "POST",
      headers: MCP_HEADERS,
      body: listToolsBody,
    });
    expect(res.status).toBe(401);
  });

  it("rejects requests with an invalid bearer token (401)", async () => {
    const res = await fetch(`${BASE}/mcp`, {
      method: "POST",
      headers: { ...MCP_HEADERS, Authorization: "Bearer not-a-real-token" },
      body: listToolsBody,
    });
    expect(res.status).toBe(401);
  });

  it("advertises the OAuth protected-resource metadata publicly", async () => {
    const res = await fetch(`${BASE}/.well-known/oauth-protected-resource`);
    expect(res.status).toBe(200);
    const json = (await res.json()) as { resource?: string; authorization_servers?: string[] };
    expect(json.authorization_servers?.length).toBeGreaterThan(0);
  });

  it("accepts requests when a valid bearer token is supplied", async () => {
    const token = process.env.MCP_TEST_BEARER_TOKEN;
    if (!token) {
      // Skip in environments without a minted Supabase OAuth-client access token.
      // Set MCP_TEST_BEARER_TOKEN to run this assertion in CI.
      return;
    }
    const res = await fetch(`${BASE}/mcp`, {
      method: "POST",
      headers: { ...MCP_HEADERS, Authorization: `Bearer ${token}` },
      body: listToolsBody,
    });
    expect(res.status).toBe(200);
  });
});
