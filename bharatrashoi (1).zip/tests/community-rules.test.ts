import { describe, expect, it } from 'vitest';
import { canManageMonetization, validateChannelVideo } from '../src/lib/community-rules';
import { aiRemainingToday } from '../src/lib/ai-quota';
import { canSubscribe } from '../src/lib/channel-subscriptions';
describe('community access rules', () => {
  it('requires a signed-in viewer to subscribe', () => { expect(canSubscribe(undefined, 'creator')).toBe(false); expect(canSubscribe('viewer', 'creator')).toBe(true); });
  it('does not allow subscribing to your own channel', () => { expect(canSubscribe('creator', 'creator')).toBe(false); });
  it('only the verified owner admin can monetize', () => { expect(canManageMonetization(true, 'ambermansoor880@gmail.com')).toBe(true); expect(canManageMonetization(false, 'ambermansoor880@gmail.com')).toBe(false); expect(canManageMonetization(true, 'other@gmail.com')).toBe(false); });
  it('AI Chef has no app daily quota', () => { expect(aiRemainingToday()).toBe(Infinity); });
  it('rejects non-video uploads and accepts supported videos', () => { expect(() => validateChannelVideo({ size: 100, type: 'image/jpeg' })).toThrow(); expect(() => validateChannelVideo({ size: 100, type: 'video/mp4' })).not.toThrow(); });
  it('enforces the storage file ceiling', () => { expect(() => validateChannelVideo({ size: 50 * 1024 * 1024 + 1, type: 'video/mp4' })).toThrow(); });
});
