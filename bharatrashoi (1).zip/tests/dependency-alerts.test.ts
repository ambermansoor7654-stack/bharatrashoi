import { describe, it, expect } from "vitest";
import { spawnSync } from "node:child_process";

/**
 * Fails the suite when a critical-severity dependency advisory is present, so
 * vulnerable packages are caught before a release build.
 */
describe("dependency alerts", () => {
  it("has no critical severity advisories", () => {
    const res = spawnSync(process.execPath, ["scripts/check-vulnerable-deps.mjs"], {
      encoding: "utf8",
      maxBuffer: 32 * 1024 * 1024,
    });
    const output = `${res.stdout ?? ""}${res.stderr ?? ""}`;
    expect(output, output).not.toMatch(/ALERT/);
    expect(res.status, output).toBe(0);
  }, 120_000);
});
