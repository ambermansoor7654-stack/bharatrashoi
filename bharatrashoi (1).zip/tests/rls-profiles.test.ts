/**
 * RLS regression tests.
 *
 * These guard two previously-fixed findings:
 *  1. `profiles.email` (and `payment_id`) must never be readable by anon/authenticated
 *     roles — only public identity columns are granted.
 *  2. `payments.reference` (UPI/UTR) must never be readable by an unauthenticated caller.
 *
 * They run against the live Data API with the publishable (anon) key, exactly like a
 * browser would, so a regression in grants or policies fails the suite.
 */
import { describe, it, expect, beforeAll } from "vitest";
import { readFileSync } from "node:fs";

function loadEnv() {
  const out: Record<string, string> = {};
  try {
    for (const line of readFileSync(new URL("../.env", import.meta.url), "utf8").split("\n")) {
      const m = /^([A-Z0-9_]+)\s*=\s*(.*)$/.exec(line.trim());
      if (m) out[m[1]!] = m[2]!.replace(/^["']|["']$/g, "");
    }
  } catch {
    // no .env in CI — fall back to process env
  }
  return { ...out, ...process.env } as Record<string, string>;
}

const env = loadEnv();
const URL_ = env["VITE_SUPABASE_URL"] ?? env["SUPABASE_URL"];
const KEY = env["VITE_SUPABASE_PUBLISHABLE_KEY"] ?? env["SUPABASE_PUBLISHABLE_KEY"];

async function rest(path: string) {
  const res = await fetch(`${URL_}/rest/v1/${path}`, {
    headers: { apikey: KEY!, Accept: "application/json" },
  });
  let body: unknown = null;
  try {
    body = await res.json();
  } catch {
    body = null;
  }
  return { status: res.status, body };
}

describe("RLS: profiles column exposure", () => {
  beforeAll(() => {
    expect(URL_, "Supabase URL must be configured").toBeTruthy();
    expect(KEY, "Supabase publishable key must be configured").toBeTruthy();
  });

  it("denies anon reads of profiles.email", async () => {
    const { status, body } = await rest("profiles?select=email&limit=1");
    expect(status).toBeGreaterThanOrEqual(400);
    expect(JSON.stringify(body)).not.toMatch(/@[a-z0-9-]+\.[a-z]{2,}/i);
  });

  it("denies anon reads of profiles.payment_id", async () => {
    const { status } = await rest("profiles?select=payment_id&limit=1");
    expect(status).toBeGreaterThanOrEqual(400);
  });

  it("denies a wildcard select on profiles (would leak restricted columns)", async () => {
    const { status } = await rest("profiles?select=*&limit=1");
    expect(status).toBeGreaterThanOrEqual(400);
  });

  it("still allows public identity columns", async () => {
    const { status, body } = await rest(
      "profiles?select=id,username,display_name,avatar_url,bio,verified&limit=1",
    );
    expect(status).toBe(200);
    expect(Array.isArray(body)).toBe(true);
    for (const row of body as Record<string, unknown>[]) {
      expect(row).not.toHaveProperty("email");
      expect(row).not.toHaveProperty("payment_id");
    }
  });
});

describe("RLS: payment reference access", () => {
  it("returns no payment references to an unauthenticated caller", async () => {
    const { status, body } = await rest("payments?select=id,reference&limit=5");
    if (status === 200) {
      // Policy is authenticated-only, so anon must see an empty set.
      expect(body).toEqual([]);
    } else {
      expect(status).toBeGreaterThanOrEqual(400);
    }
  });

  it("does not expose payments through a profiles embed", async () => {
    const { status, body } = await rest("profiles?select=id,payments(reference)&limit=1");
    if (status === 200) {
      for (const row of body as Record<string, unknown>[]) {
        expect(row["payments"] ?? []).toEqual([]);
      }
    } else {
      expect(status).toBeGreaterThanOrEqual(400);
    }
  });

  it("keeps server-only tables unreadable for anon", async () => {
    for (const table of ["audit_logs", "phone_otps"]) {
      const { status, body } = await rest(`${table}?select=id&limit=1`);
      if (status === 200) expect(body).toEqual([]);
      else expect(status).toBeGreaterThanOrEqual(400);
    }
  });
});
