# Mobile UI polish

- [ ] Fix app-wide iPhone safe areas, viewport sizing, touch targets, and overflow.
- [ ] Refine mobile navigation and headers.
- [ ] Polish key mobile screens and dense content.
- [ ] Verify phone and iPhone-size layouts, interactions, and build health.
