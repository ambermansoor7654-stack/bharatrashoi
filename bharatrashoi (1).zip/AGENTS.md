<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Treat mobile safe areas and 320px-wide layouts as baseline constraints because the app is primarily used on phones and iPhones.
- Keep app-shell offline caching behind the guarded PWA registration wrapper so development and Lovable previews never register a service worker.
- Keep the public sitemap limited to indexable shared content, excluding account, personal, admin, API, and tool routes so search engines do not crawl private or thin pages.

- Community videos live in a dedicated private storage bucket with owner-scoped writes and signed public read URLs for published rows.
- Owner-admin reporting and monetization use authenticated server functions that check the role and verified account identity before privileged access.
- Visitor reporting counts device identifiers per UTC date, not unique people; login reporting is recorded only after validated sign-in.
- Channel subscriptions use owner-scoped browser queries and an aggregate-only public count function, so individual subscriber identities remain private.
- Email passwordless sign-in uses Cloud Auth OTP verification and preserves email-confirmation requirements; SMS retains the existing sender and removes failed-send challenges to avoid consuming delivery retries.
