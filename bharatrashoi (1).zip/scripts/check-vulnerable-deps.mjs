#!/usr/bin/env node
/**
 * Vulnerable dependency alert.
 *
 * Runs an audit of the installed dependency tree and fails (exit 1) when any
 * critical — or, with --high, high — severity advisory is present. Wire this
 * into your release flow (`bun run check:deps`) so vulnerable packages get
 * updated before a build ships.
 */
import { spawnSync } from "node:child_process";

const failOnHigh = process.argv.includes("--high");
const THRESHOLD = failOnHigh ? ["critical", "high"] : ["critical"];

function runAudit() {
  for (const cmd of [
    ["npm", ["audit", "--json", "--audit-level=high"]],
    ["bun", ["audit", "--json"]],
  ]) {
    const res = spawnSync(cmd[0], cmd[1], { encoding: "utf8", maxBuffer: 32 * 1024 * 1024 });
    if (res.error || !res.stdout) continue;
    try {
      return JSON.parse(res.stdout);
    } catch {
      // try the next runner
    }
  }
  return null;
}

const report = runAudit();
if (!report) {
  console.error("[deps] Could not run an audit (no npm/bun audit output). Skipping.");
  process.exit(0);
}

const advisories = [];
const vulns = report.vulnerabilities ?? report.advisories ?? {};
for (const [name, info] of Object.entries(vulns)) {
  const severity = String(info.severity ?? "").toLowerCase();
  if (!THRESHOLD.includes(severity)) continue;
  const fix = info.fixAvailable;
  advisories.push({
    name: info.name ?? name,
    severity,
    range: info.range ?? "",
    fix: fix === true ? "run an update" : fix ? `${fix.name}@${fix.version}` : "no automatic fix",
  });
}

if (advisories.length === 0) {
  console.log(`[deps] OK — no ${THRESHOLD.join("/")} severity advisories.`);
  process.exit(0);
}

console.error(`\n[deps] ALERT — ${advisories.length} blocking advisory(ies) found:\n`);
for (const a of advisories) {
  console.error(`  • ${a.name} (${a.severity}) ${a.range}\n    fix: ${a.fix}`);
}
console.error(
  "\nUpdate the package (or pin a patched version via package.json \"overrides\") before releasing.\n",
);
process.exit(1);
