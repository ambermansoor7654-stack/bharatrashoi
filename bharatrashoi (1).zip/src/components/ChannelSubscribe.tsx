import { useState } from 'react';
import { Link } from '@tanstack/react-router';
import { Bell, BellOff, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/lib/auth';
import { useChannelSubscriptions } from '@/lib/channel-subscriptions';

export function ChannelSubscribe({ channelId, ownerId, count }: { channelId: string; ownerId: string; count: number }) {
  const { user } = useAuth();
  const { ids, toggle, loading, error } = useChannelSubscriptions();
  const [busy, setBusy] = useState(false);
  const subscribed = ids.includes(channelId);
  return <div className="flex flex-wrap items-center gap-3">
    <span className="text-xs text-muted-foreground">{count.toLocaleString()} subscriber{count === 1 ? '' : 's'}</span>
    {!user ? <Button asChild size="sm" variant="outline"><Link to="/auth"><Bell /> Subscribe</Link></Button>
      : user.id !== ownerId && <Button size="sm" variant={subscribed ? 'secondary' : 'default'} disabled={busy || loading || Boolean(error)} aria-pressed={subscribed} onClick={async () => {
        setBusy(true);
        try { await toggle(channelId, ownerId); } catch (e) { toast.error(e instanceof Error ? e.message : 'Could not update subscription'); } finally { setBusy(false); }
      }}>{busy ? <Loader2 className="animate-spin" /> : subscribed ? <BellOff /> : <Bell />}{subscribed ? 'Unsubscribe' : 'Subscribe'}</Button>}
  </div>;
}