import { Link } from '@tanstack/react-router';
import { Mail, Video } from 'lucide-react';
import { Button } from '@/components/ui/button';
export function HomeFooter() {
  return <footer className="border-t border-border pt-8 pb-4"><div className="flex flex-wrap items-start justify-between gap-6"><div><h2 className="font-display text-2xl">Bharat Rasoi</h2><p className="mt-2 text-sm text-muted-foreground">Swaad Ghar Jaisa, App Hamara</p></div><Button asChild variant="outline"><Link to="/channels"><Video /> Create channel</Link></Button></div><nav aria-label="Footer" className="mt-6 flex flex-wrap gap-x-6 gap-y-4 text-sm"><Link to="/about">About us</Link><Link to="/contact">Contact us</Link><Link to="/terms">Terms &amp; conditions</Link><Link to="/privacy">Privacy policy</Link></nav><a href="mailto:contactbharatashoi@gmail.com" className="mt-6 flex w-fit max-w-full items-center gap-2 break-all text-sm text-muted-foreground"><Mail className="h-4 w-4 shrink-0" />contactbharatashoi@gmail.com</a></footer>;
}
