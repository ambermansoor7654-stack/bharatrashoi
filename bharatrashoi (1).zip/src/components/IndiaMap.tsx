import { useEffect, useState } from "react";
import { ComposableMap, Geographies, Geography } from "react-simple-maps";
import { motion, AnimatePresence } from "framer-motion";
import { MapPin } from "lucide-react";
import type { IndianState } from "@/lib/data";

const GEO_URL =
  "https://raw.githubusercontent.com/Anujarya300/bubble_maps/master/data/geography-data/india.topo.json";

// Topojson quirks -> our canonical state names
const NAME_FIXES: Record<string, string> = {
  "Arunanchal Pradesh": "Arunachal Pradesh",
  "NCT of Delhi": "Delhi",
  "Andaman & Nicobar Island": "Andaman & Nicobar Islands",
  "Dadara & Nagar Havelli": "Dadra & Nagar Haveli",
};

const canonical = (name?: string | null) =>
  (name && NAME_FIXES[name]) || name || "";

export function IndiaMap({
  states,
  selected,
  onSelect,
}: {
  states: IndianState[];
  selected: IndianState | null;
  onSelect: (s: IndianState) => void;
}) {
  const [hovered, setHovered] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  useEffect(() => setReady(true), []);

  const byName = new Map(states.map((s) => [s.name.toLowerCase(), s]));
  const lookup = (raw: string | null | undefined) =>
    byName.get(canonical(raw).toLowerCase()) ?? null;

  const label = hovered ?? selected?.name ?? null;

  if (!ready) {
    return (
      <div className="panel grid h-[420px] place-items-center rounded-3xl text-xs text-muted-foreground">
        <span className="skeleton inline-block h-4 w-40 rounded-full" /> Loading Bharat map…
      </div>
    );
  }

  return (
    <div className="panel relative overflow-hidden rounded-3xl">
      <div className="pointer-events-none absolute inset-x-0 top-0 z-10 flex items-center justify-between p-4">
        <div className="inline-flex items-center gap-1.5 rounded-full border border-[color-mix(in_oklab,var(--gold)_20%,transparent)] bg-[color-mix(in_oklab,var(--card)_88%,transparent)] px-3 py-1.5 text-[10px] font-semibold uppercase tracking-[0.18em] text-foreground/80 backdrop-blur">
          <MapPin className="h-3 w-3 text-[var(--saffron)]" aria-hidden="true" /> Bharat · Interactive Map
        </div>
        <AnimatePresence mode="popLayout">
          {label && (
            <motion.div
              key={label}
              initial={{ opacity: 0, y: -6, scale: 0.92 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -6, scale: 0.92 }}
              transition={{ duration: 0.22, ease: "easeOut" }}
              className="rounded-full gradient-gold px-3.5 py-1.5 text-[11px] font-semibold text-[oklch(0.24_0.05_46)] shadow-[var(--shadow-glow)]"
            >
              {label}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="relative">
        <ComposableMap
          projection="geoMercator"
          projectionConfig={{ scale: 900, center: [82, 22] }}
          width={720}
          height={720}
          style={{ width: "100%", height: "auto", background: "transparent" }}
        >
          <Geographies geography={GEO_URL}>
            {({ geographies }: { geographies: any[] }) =>
              geographies.map((geo) => {
                const raw = geo.properties?.name as string | null;
                const state = lookup(raw);
                const isSelected = state && selected?.id === state.id;
                const isHovered = state && hovered === state.name;
                return (
                  <Geography
                    key={geo.rsmKey}
                    geography={geo}
                    onMouseEnter={() => state && setHovered(state.name)}
                    onMouseLeave={() => setHovered(null)}
                    onClick={() => state && onSelect(state)}
                    style={{
                      default: {
                        fill: isSelected
                          ? "url(#goldFill)"
                          : "oklch(0.93 0.018 82)",
                        stroke: isSelected
                          ? "oklch(0.66 0.13 70)"
                          : isHovered
                            ? "oklch(0.62 0.135 68)"
                            : "oklch(0.8 0.03 76)",
                        strokeWidth: isSelected ? 1.6 : 0.6,
                        outline: "none",
                        cursor: state ? "pointer" : "default",
                        filter: isSelected
                          ? "drop-shadow(0 0 8px oklch(0.73 0.155 66 / 0.55)) drop-shadow(0 0 16px oklch(0.66 0.115 78 / 0.4))"
                          : "none",
                        transition: "all 220ms ease",
                      },
                      hover: {
                        fill: isSelected
                          ? "url(#goldFill)"
                          : "oklch(0.9 0.03 80)",
                        stroke: "oklch(0.62 0.135 68)",
                        strokeWidth: 1.1,
                        outline: "none",
                        cursor: state ? "pointer" : "default",
                      },
                      pressed: {
                        fill: "url(#goldFill)",
                        outline: "none",
                      },
                    }}
                  />
                );
              })
            }
          </Geographies>
          <defs>
            <linearGradient id="goldFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="oklch(0.86 0.09 88)" />
              <stop offset="48%" stopColor="oklch(0.73 0.155 66)" />
              <stop offset="100%" stopColor="oklch(0.56 0.11 62)" />
            </linearGradient>
          </defs>
        </ComposableMap>
      </div>

      <div className="pointer-events-none flex items-center justify-center gap-2 border-t border-[color-mix(in_oklab,var(--gold)_16%,transparent)] p-3 text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
        <span className="h-1.5 w-1.5 rounded-full bg-[var(--saffron)]" />
        <span>Tap a state to explore</span>
        <span className="h-1.5 w-1.5 rounded-full bg-[var(--india-green)]" />
      </div>
    </div>
  );
}
