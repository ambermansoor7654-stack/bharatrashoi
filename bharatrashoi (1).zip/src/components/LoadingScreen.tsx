import { BharatLogo } from "./BharatLogo";

/**
 * Full-panel loading screen shown while a route is pending.
 * A calm, premium loader built from the brand mark and skeleton lines —
 * no garish spinning rings.
 */
export function LoadingScreen({ label = "Warming up the tawa…" }: { label?: string }) {
  return (
    <div className="grid min-h-[60vh] place-items-center px-4">
      <div className="panel flex w-full max-w-md flex-col items-center gap-6 p-8 text-center">
        <div className="relative grid place-items-center">
          <div className="absolute h-16 w-16 rounded-full bg-[var(--gold)]/12 animate-pulse" />
          <div className="relative animate-[pulse_2.2s_ease-in-out_infinite]">
            <BharatLogo className="h-12 w-12" />
          </div>
        </div>

        <div>
          <p className="font-display text-lg text-foreground">{label}</p>
          <p className="mt-1 text-xs text-muted-foreground">Fresh ingredients loading…</p>
        </div>

        <div className="w-full space-y-2.5" aria-hidden>
          <div className="skeleton h-3 rounded-full" style={{ width: "90%" }} />
          <div className="skeleton h-3 rounded-full" style={{ width: "72%" }} />
          <div className="skeleton h-3 rounded-full" style={{ width: "80%" }} />
        </div>
      </div>
    </div>
  );
}
