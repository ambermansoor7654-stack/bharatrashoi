import { Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Clock, Youtube, Flame, ChefHat } from "lucide-react";
import { RecipeImage } from "./RecipeImage";
import { youtubeUrl, type DbRecipe } from "@/lib/recipes";

export function DbRecipeCard({ recipe, index = 0 }: { recipe: DbRecipe; index?: number }) {
  return (
    <motion.article
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: Math.min(index, 12) * 0.03 }}
      className="card-lift group relative overflow-hidden rounded-[1.375rem] border border-[color-mix(in_oklab,var(--gold)_16%,transparent)] bg-card shadow-[var(--shadow-soft)]"
    >
      <Link to="/recipes/$id" params={{ id: recipe.slug }} className="block">
        <div className="media-frame aspect-[4/3]">
          <RecipeImage
            src={recipe.image_url}
            alt={recipe.name}
            className="h-full w-full object-cover"
          />
          <div aria-hidden="true" className="scrim absolute inset-0" />
          <div className="absolute left-3 top-3 flex flex-wrap gap-1.5">
            <span className="rounded-full bg-[oklch(0.14_0.02_38/0.55)] px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.12em] text-[oklch(0.97_0.01_88)] backdrop-blur">
              {recipe.category}
            </span>
            {recipe.featured && (
              <span className="rounded-full bg-[var(--saffron)] px-2.5 py-1 text-[10px] font-bold text-[oklch(0.2_0.04_44)]">
                Featured
              </span>
            )}
            {!recipe.published && (
              <span className="rounded-full bg-amber-500 px-2.5 py-1 text-[10px] font-bold text-[oklch(0.2_0.04_44)]">
                Draft
              </span>
            )}
          </div>
          <div className="absolute inset-x-3 bottom-3 text-[oklch(0.98_0.01_88)]">
            <h3 className="truncate font-display text-xl leading-tight">{recipe.name}</h3>
            <p className="mt-0.5 line-clamp-2 text-[11px] opacity-75">{recipe.description}</p>
          </div>
        </div>
      </Link>
      <div className="flex items-center justify-between gap-2 px-4 py-3 text-[11px] font-medium text-muted-foreground">
        <span className="inline-flex items-center gap-1.5">
          <Clock className="h-3.5 w-3.5" aria-hidden="true" />
          {recipe.cook_time}
        </span>
        <span className="inline-flex items-center gap-1.5">
          <Flame className="h-3.5 w-3.5" aria-hidden="true" />
          {recipe.difficulty}
        </span>
        <span className="inline-flex items-center gap-1.5">
          <ChefHat className="h-3.5 w-3.5" aria-hidden="true" />
          {recipe.nutrition?.calories ?? "—"} kcal
        </span>
      </div>
      <a
        href={youtubeUrl(recipe.name)}
        target="_blank"
        rel="noreferrer noopener"
        className="absolute right-3 top-3 grid h-9 w-9 touch-manipulation place-items-center rounded-full border border-[oklch(1_0_0/0.2)] bg-[oklch(0.14_0.02_38/0.55)] text-[oklch(0.98_0.01_88)] backdrop-blur transition hover:scale-110 active:scale-95"
        aria-label={`Watch ${recipe.name} on YouTube`}
        onClick={e => e.stopPropagation()}
      >
        <Youtube className="h-4 w-4" aria-hidden="true" />
      </a>
    </motion.article>
  );
}
