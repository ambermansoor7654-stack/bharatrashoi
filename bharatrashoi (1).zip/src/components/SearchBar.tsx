import { Search, SlidersHorizontal } from "lucide-react";

type Props = {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
};

export function SearchBar({ value, onChange, placeholder = "Search biryani, dosa, dhokla…" }: Props) {
  return (
    <div className="group relative flex items-center gap-3 rounded-full border border-[color-mix(in_oklab,var(--gold)_22%,transparent)] bg-card/85 py-2 pl-5 pr-2 shadow-[var(--shadow-soft)] backdrop-blur-xl transition focus-within:border-[color-mix(in_oklab,var(--gold)_45%,transparent)] focus-within:shadow-[var(--shadow-glow)]">
      <Search className="h-[18px] w-[18px] shrink-0 text-muted-foreground transition group-focus-within:text-primary" aria-hidden="true" />
      <input
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        aria-label="Search recipes"
        className="min-w-0 flex-1 bg-transparent py-2 text-sm outline-none placeholder:text-muted-foreground/80"
      />
      <button
        type="button"
        aria-label="Search filters"
        className="btn-gold grid h-10 w-10 shrink-0 place-items-center rounded-full"
      >
        <SlidersHorizontal className="h-4 w-4" aria-hidden="true" />
      </button>
    </div>
  );
}
