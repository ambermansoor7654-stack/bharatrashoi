import { useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Bell, BellRing, CheckCircle2, XCircle } from "lucide-react";
import { auditSubtitle, describeAuditAction, useAdminNotificationCenter } from "@/lib/admin-notifications";

function timeAgo(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.round(diff / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.round(h / 24)}d ago`;
}

export function AdminNotificationBell() {
  const { isAdmin, items, unread, markAllRead } = useAdminNotificationCenter();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("mousedown", onDoc);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDoc);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  if (!isAdmin) return null;

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        aria-label={unread > 0 ? `${unread} new admin notifications` : "Admin notifications"}
        aria-expanded={open}
        onClick={() => {
          setOpen(o => !o);
          markAllRead();
        }}
        className="relative grid h-10 w-10 touch-manipulation place-items-center rounded-full border border-[color-mix(in_oklab,var(--gold)_28%,transparent)] bg-card/80 text-foreground/80 shadow-[var(--shadow-soft)] transition hover:text-foreground active:scale-95"
      >
        {unread > 0 ? <BellRing className="h-[18px] w-[18px] text-primary" aria-hidden="true" /> : <Bell className="h-[18px] w-[18px]" aria-hidden="true" />}
        {unread > 0 && (
          <span className="absolute -right-0.5 -top-0.5 grid min-h-[18px] min-w-[18px] place-items-center rounded-full bg-[var(--spice)] px-1 text-[10px] font-bold text-[oklch(0.99_0.01_88)]">
            {unread > 9 ? "9+" : unread}
          </span>
        )}
      </button>

      {open && (
        <div
          role="dialog"
          aria-label="Admin notifications"
          className="panel reveal absolute right-0 top-12 z-50 w-[19rem] overflow-hidden p-0 shadow-[var(--shadow-card)] sm:w-[22rem]"
        >
          <div className="flex items-center justify-between border-b border-border/70 px-4 py-3">
            <div>
              <div className="eyebrow">Live audit</div>
              <div className="font-display text-lg leading-tight">Notifications</div>
            </div>
            <Link to="/audit" onClick={() => setOpen(false)} className="text-[11px] font-semibold text-primary underline-offset-4 hover:underline">
              View all
            </Link>
          </div>

          <ul className="max-h-[22rem] divide-y divide-border/60 overflow-y-auto">
            {items.length === 0 && (
              <li className="px-4 py-8 text-center text-sm text-muted-foreground">
                No premium or blue-tick activity yet. New approvals appear here instantly.
              </li>
            )}
            {items.map(n => {
              const { title, tone } = describeAuditAction(n.action);
              const sub = auditSubtitle(n);
              return (
                <li key={n.id} className="flex items-start gap-3 px-4 py-3">
                  {tone === "bad" ? (
                    <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" aria-hidden="true" />
                  ) : (
                    <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[var(--india-green)]" aria-hidden="true" />
                  )}
                  <div className="min-w-0">
                    <div className="text-[13px] font-semibold leading-snug">{title}</div>
                    {sub && <div className="truncate text-xs text-muted-foreground">{sub}</div>}
                    <div className="mt-0.5 text-[10px] uppercase tracking-[0.14em] text-muted-foreground/80">{timeAgo(n.created_at)}</div>
                  </div>
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </div>
  );
}
