import { BadgeCheck, Crown } from "lucide-react";

export function VerifiedBadge({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <span title="Verified by Bharat Rasoi" aria-label="Verified account" className="inline-flex">
      <BadgeCheck className={`${className} text-[#1d9bf0]`} aria-hidden="true" />
    </span>
  );
}

export function PremiumBadge({ label = "Premium" }: { label?: string }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-full gradient-gold px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-[var(--ink)] shadow-[var(--shadow-glow)]">
      <Crown className="h-3 w-3" aria-hidden="true" /> {label}
    </span>
  );
}
