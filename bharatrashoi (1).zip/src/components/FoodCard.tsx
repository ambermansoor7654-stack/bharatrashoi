import { motion } from "framer-motion";
import { Heart, Share2, MapPin, Flame, Leaf, Drumstick, Clock, Sparkles, AlertTriangle, Utensils } from "lucide-react";
import { useEffect, useState } from "react";
import type { FoodCard as FoodCardType } from "@/lib/food-schema";
import { supabase } from "@/integrations/supabase/client";
import { getSessionToken } from "@/lib/session";
import { toast } from "sonner";

function unsplash(query: string) {
  return `https://source.unsplash.com/800x600/?${encodeURIComponent(query + ",indian food")}`;
}

function NutrientBar({ label, value, max, color }: { label: string; value: number; max: number; color: string }) {
  const pct = Math.min(100, Math.round((value / max) * 100));
  return (
    <div>
      <div className="mb-1 flex justify-between text-[11px] font-medium">
        <span className="text-muted-foreground">{label}</span>
        <span className="text-foreground">{value}g</span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-[color-mix(in_oklab,var(--muted)_75%,transparent)]">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className={`h-full rounded-full ${color}`}
        />
      </div>
    </div>
  );
}

export function FoodCard({ food }: { food: FoodCardType }) {
  const [saved, setSaved] = useState(false);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    const token = getSessionToken();
    supabase
      .from("food_favorites")
      .select("id")
      .eq("session_token", token)
      .eq("food_name", food.food_name)
      .maybeSingle()
      .then(({ data }) => {
        setSaved(!!data);
        setChecking(false);
      });
  }, [food.food_name]);

  const toggleSave = async () => {
    const token = getSessionToken();
    if (saved) {
      await supabase.from("food_favorites").delete().eq("session_token", token).eq("food_name", food.food_name);
      setSaved(false);
      toast("Removed from favorites");
    } else {
      const { error } = await supabase.from("food_favorites").insert({
        session_token: token,
        food_name: food.food_name,
        food_data: food as never,
      });
      if (!error) {
        setSaved(true);
        toast.success(`${food.food_name} saved`);
      }
    }
  };

  const share = async () => {
    const text = `${food.food_name} — ${food.origin}\n${food.cultural_background}`;
    try {
      if (navigator.share) await navigator.share({ title: food.food_name, text });
      else {
        await navigator.clipboard.writeText(text);
        toast.success("Copied to clipboard");
      }
    } catch { /* user cancelled */ }
  };

  const DietIcon = food.diet === "Non-Veg" ? Drumstick : Leaf;

  return (
    <motion.div
      initial={{ opacity: 0, y: 16, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ type: "spring", stiffness: 220, damping: 24 }}
      className="overflow-hidden rounded-[1.5rem] border border-[color-mix(in_oklab,var(--gold)_16%,transparent)] bg-card shadow-[var(--shadow-card)]"
    >
      {/* Cinematic header */}
      <div className="relative h-48 overflow-hidden sm:h-60">
        <img
          src={unsplash(food.image_query)}
          alt={food.food_name}
          loading="lazy"
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div aria-hidden="true" className="scrim absolute inset-0" />
        <div className="absolute right-3 top-3 flex gap-2">
          <button
            onClick={toggleSave}
            disabled={checking}
            className="grid h-9 w-9 place-items-center rounded-full glass-dark text-[oklch(0.98_0.01_88)] transition hover:scale-110 active:scale-95"
            aria-label="Save"
          >
            <Heart className={`h-4 w-4 ${saved ? "fill-[var(--spice)] text-[var(--spice)]" : ""}`} />
          </button>
          <button
            onClick={share}
            className="grid h-9 w-9 place-items-center rounded-full glass-dark text-[oklch(0.98_0.01_88)] transition hover:scale-110 active:scale-95"
            aria-label="Share"
          >
            <Share2 className="h-4 w-4" />
          </button>
        </div>
        <div className="absolute inset-x-0 bottom-0 p-4 text-[oklch(0.98_0.01_88)] sm:p-5">
          <div className="flex flex-wrap items-center gap-1.5 text-[10px]">
            <span className="inline-flex items-center gap-1 rounded-full glass-dark px-2 py-0.5 font-semibold">
              <MapPin className="h-3 w-3" />{food.origin}
            </span>
            <span className="rounded-full glass-dark px-2 py-0.5 font-semibold">{food.category}</span>
            <span className="inline-flex items-center gap-1 rounded-full glass-dark px-2 py-0.5 font-semibold">
              <DietIcon className="h-3 w-3" />{food.diet}
            </span>
          </div>
          <h3 className="mt-2 font-display text-3xl leading-tight">{food.food_name}</h3>
        </div>
      </div>

      {/* Description */}
      <div className="border-b border-[color-mix(in_oklab,var(--gold)_14%,transparent)] px-4 pb-4 pt-4 sm:px-5">
        <div className="eyebrow mb-1">Description</div>
        <p className="text-sm leading-relaxed text-foreground/85">{food.cultural_background}</p>
      </div>

      <div className="space-y-5 p-4 sm:p-5">
        {/* Calories + nutrition */}
        <div className="flex items-center gap-4">
          <div className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl gradient-gold text-[oklch(0.24_0.05_46)] shadow-[var(--shadow-glow)]">
            <div className="text-center leading-none">
              <div className="font-display text-xl">{food.calories_per_serving}</div>
              <div className="text-[8px] uppercase tracking-widest opacity-80">kcal</div>
            </div>
          </div>
          <div className="min-w-0 flex-1 space-y-2">
            <NutrientBar label="Protein" value={food.nutrition.protein_g} max={40} color="bg-[var(--india-green)]" />
            <NutrientBar label="Carbs" value={food.nutrition.carbs_g} max={80} color="bg-[var(--gold)]" />
            <NutrientBar label="Fat" value={food.nutrition.fat_g} max={40} color="bg-[var(--spice)]" />
            <NutrientBar label="Fiber" value={food.nutrition.fiber_g} max={15} color="bg-[var(--saffron)]" />
          </div>
        </div>

        <Section icon={<Utensils className="h-3.5 w-3.5" />} title="Main ingredients">
          <div className="flex flex-wrap gap-1.5">
            {food.main_ingredients.map(i => (
              <span key={i} className="rounded-full bg-accent px-2.5 py-0.5 text-[11px] font-medium text-accent-foreground">{i}</span>
            ))}
          </div>
        </Section>

        <Section icon={<Flame className="h-3.5 w-3.5" />} title="Cooking method">
          <p className="text-xs leading-relaxed text-muted-foreground">{food.cooking_method}</p>
        </Section>

        <Section icon={<Sparkles className="h-3.5 w-3.5" />} title="Taste & best time">
          <div className="flex flex-wrap items-center gap-1.5">
            {food.taste_profile.map(t => (
              <span key={t} className="rounded-full bg-[color-mix(in_oklab,var(--saffron)_16%,transparent)] px-2.5 py-0.5 text-[11px] font-medium text-foreground">{t}</span>
            ))}
            <span className="inline-flex items-center gap-1 text-[11px] text-muted-foreground">
              <Clock className="h-3 w-3" />{food.best_time_to_eat}
            </span>
          </div>
        </Section>

        <div className="grid gap-3 sm:grid-cols-2">
          <Section icon={<Leaf className="h-3.5 w-3.5 text-[var(--india-green)]" />} title="Health benefits">
            <ul className="space-y-1 text-xs text-muted-foreground">
              {food.health_benefits.map(b => (
                <li key={b} className="flex gap-1.5"><span className="text-[var(--india-green)]">✓</span>{b}</li>
              ))}
            </ul>
          </Section>
          <Section icon={<AlertTriangle className="h-3.5 w-3.5 text-[var(--spice)]" />} title="Risks & allergies">
            <ul className="space-y-1 text-xs text-muted-foreground">
              {food.risks_or_allergies.map(b => (
                <li key={b} className="flex gap-1.5"><span className="text-[var(--spice)]">!</span>{b}</li>
              ))}
            </ul>
          </Section>
        </div>

        <Section icon={<MapPin className="h-3.5 w-3.5" />} title="Famous places">
          <p className="text-xs leading-relaxed text-muted-foreground">{food.popular_places.join(" • ")}</p>
        </Section>


        {food.similar_foods.length > 0 && (
          <div>
            <div className="eyebrow mb-1.5">Similar foods</div>
            <div className="flex flex-wrap gap-1.5">
              {food.similar_foods.map(s => (
                <span key={s} className="rounded-full border border-[color-mix(in_oklab,var(--gold)_18%,transparent)] bg-card px-2.5 py-0.5 text-[11px] font-medium">{s}</span>
              ))}
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}

function Section({ icon, title, children }: { icon: React.ReactNode; title: string; children: React.ReactNode }) {
  return (
    <div className="hairline pt-3 first:border-t-0 first:pt-0">
      <div className="eyebrow mb-1.5 flex items-center gap-1.5 normal-case tracking-widest">
        {icon}{title}
      </div>
      {children}
    </div>
  );
}
