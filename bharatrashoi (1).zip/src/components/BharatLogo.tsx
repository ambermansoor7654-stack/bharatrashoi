export function BharatLogo({ className = "h-11 w-11" }: { className?: string }) {
  return (
    <div className={`relative grid shrink-0 place-items-center ${className}`} aria-label="Bharat Rasoi logo">
      {/* Gold rim */}
      <div className="absolute inset-0 rounded-full bg-[var(--gradient-gold)] shadow-[var(--shadow-masala)]" />
      {/* Ink plate */}
      <div className="absolute inset-[2px] rounded-full bg-[radial-gradient(circle_at_32%_26%,oklch(0.3_0.04_44),oklch(0.15_0.024_38)_72%)] ring-1 ring-[oklch(1_0_0/0.08)]" />
      <svg viewBox="0 0 72 72" className="relative h-[74%] w-[74%]" role="img" aria-hidden>
        <defs>
          <linearGradient id="br-petal" x1="18" x2="54" y1="12" y2="48" gradientUnits="userSpaceOnUse">
            <stop stopColor="#FFEEC0" />
            <stop offset=".55" stopColor="#E3A63F" />
            <stop offset="1" stopColor="#B9762A" />
          </linearGradient>
          <linearGradient id="br-leaf" x1="22" x2="50" y1="46" y2="62" gradientUnits="userSpaceOnUse">
            <stop stopColor="#4FA97A" />
            <stop offset="1" stopColor="#14603A" />
          </linearGradient>
        </defs>

        {/* Lotus / flame petals */}
        <g transform="translate(36 33)">
          {[0, 60, 120, 180, 240, 300].map(deg => (
            <path
              key={deg}
              transform={`rotate(${deg})`}
              d="M0 -21c4.4 4.8 4.4 12.4 0 19.4-4.4-7-4.4-14.6 0-19.4Z"
              fill="url(#br-petal)"
              opacity="0.96"
            />
          ))}
          <circle r="6.2" fill="#FFF0C8" />
          <circle r="2.1" fill="#7A3A12" />
        </g>

        {/* Green base — the leaf the plate rests on */}
        <path d="M17 51c8 7 30 7 38 0-2 7.6-9.6 11.4-19 11.4S19 58.6 17 51Z" fill="url(#br-leaf)" />
        <path d="M22.5 53.6c5.6 2.6 21.4 2.6 27 0" stroke="#fff" strokeOpacity=".22" strokeWidth="1.4" strokeLinecap="round" />
      </svg>
    </div>
  );
}
