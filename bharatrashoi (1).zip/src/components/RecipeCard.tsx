import { Link } from "@tanstack/react-router";
import { Clock, Star, Heart, ChefHat } from "lucide-react";
import type { Recipe } from "@/lib/data";
import { useFavorites } from "@/lib/favorites";

export function RecipeCard({ recipe, index = 0 }: { recipe: Recipe; index?: number }) {
  const { isFav, toggle } = useFavorites();
  const fav = isFav(recipe.id);

  return (
    <article
      style={{ animationDelay: `${Math.min(index, 8) * 45}ms` }}
      className="group card-lift reveal relative overflow-hidden rounded-[1.375rem] border border-[color-mix(in_oklab,var(--gold)_16%,transparent)] bg-card shadow-[var(--shadow-soft)]"
    >
      <Link to="/recipes/$id" params={{ id: recipe.id }} className="block">
        <div className="media-frame aspect-[4/3]">
          <img
            src={recipe.image}
            alt={recipe.name}
            loading="lazy"
            className="h-full w-full object-cover"
          />
          <div aria-hidden="true" className="scrim absolute inset-0" />
          <span className="absolute left-3 top-3 inline-flex items-center gap-1 rounded-full bg-[oklch(0.14_0.02_38/0.55)] px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.12em] text-[oklch(0.97_0.01_88)] backdrop-blur">
            {recipe.category}
          </span>
          <div className="absolute inset-x-3 bottom-3 flex items-end justify-between gap-2 text-[oklch(0.98_0.01_88)]">
            <div className="min-w-0">
              <h3 className="truncate font-display text-xl leading-tight">{recipe.name}</h3>
              <div className="mt-0.5 truncate text-[11px] font-medium uppercase tracking-[0.14em] opacity-75">{recipe.state}</div>
            </div>
            <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-[oklch(0.14_0.02_38/0.6)] px-2 py-1 text-[11px] font-semibold backdrop-blur">
              <Star className="h-3 w-3 fill-[var(--saffron)] text-[var(--saffron)]" aria-hidden="true" />
              {recipe.rating}
            </span>
          </div>
        </div>
        <div className="flex items-center justify-between px-4 py-3 text-[11px] font-medium text-muted-foreground">
          <span className="inline-flex items-center gap-1.5"><Clock className="h-3.5 w-3.5" aria-hidden="true" />{recipe.time}</span>
          <span className="inline-flex items-center gap-1.5"><ChefHat className="h-3.5 w-3.5" aria-hidden="true" />{recipe.difficulty}</span>
        </div>
      </Link>
      <button
        onClick={() => toggle(recipe.id)}
        aria-label={fav ? `Remove ${recipe.name} from favorites` : `Save ${recipe.name} to favorites`}
        aria-pressed={fav}
        className="absolute right-3 top-3 grid h-9 w-9 touch-manipulation place-items-center rounded-full border border-[oklch(1_0_0/0.2)] bg-[oklch(0.14_0.02_38/0.5)] backdrop-blur transition hover:scale-110 active:scale-95"
      >
        <Heart className={`h-4 w-4 transition ${fav ? "fill-[var(--spice)] text-[var(--spice)]" : "text-[oklch(0.98_0.01_88)]"}`} aria-hidden="true" />
      </button>
    </article>
  );
}
