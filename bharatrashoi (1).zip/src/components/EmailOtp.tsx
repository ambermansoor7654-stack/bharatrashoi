import { useEffect, useState } from 'react';
import { useNavigate } from '@tanstack/react-router';
import { Mail, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';

export function EmailOtp() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [sentTo, setSentTo] = useState('');
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [cooldown, setCooldown] = useState(0);
  const [error, setError] = useState('');
  useEffect(() => {
    if (!cooldown) return;
    const timer = setTimeout(() => setCooldown(cooldown - 1), 1000);
    return () => clearTimeout(timer);
  }, [cooldown]);
  const input = 'min-h-11 w-full min-w-0 rounded-md border border-input bg-background px-3 py-2 text-base';
  return <form className="mt-5 space-y-3" onSubmit={async e => {
    e.preventDefault(); setBusy(true); setError('');
    try {
      if (sentTo) {
        const { error, data } = await supabase.auth.verifyOtp({ email: sentTo, token: code.trim(), type: 'email' });
        if (error) throw error;
        if (!data.session) throw new Error('Verification incomplete. Please try again.');
        await navigate({ to: '/' });
      } else {
        const address = email.trim().toLowerCase();
        const { error } = await supabase.auth.signInWithOtp({ email: address, options: { emailRedirectTo: window.location.origin } });
        if (error) throw error;
        setSentTo(address); setCooldown(60);
      }
    } catch (e) { setError(e instanceof Error ? e.message : 'Could not sign in.'); } finally { setBusy(false); }
  }}>
    <label className="block space-y-2"><span className="text-sm">Email address</span><input type="email" autoComplete="email" required value={email} disabled={Boolean(sentTo)} onChange={e => setEmail(e.target.value)} className={input} /></label>
    {sentTo && <><p role="status" className="break-words text-sm text-muted-foreground">{sentTo} par sign-in email bheja gaya hai (Inbox, Spam aur Promotions dekho). Email mein "Log In" link ho to use isi phone/browser mein tap karo — aap seedha login ho jaoge. Code ho to neeche daalo.</p>
      <label className="block space-y-2"><span className="text-sm">Email code</span><input autoComplete="one-time-code" inputMode="numeric" pattern="[0-9]{4,8}" minLength={4} maxLength={8} required value={code} onChange={e => setCode(e.target.value.replace(/\D/g, ''))} className={input} /></label></>}
    {error && <p role="alert" className="break-words text-sm text-destructive">{error}</p>}
    <Button type="submit" className="w-full" disabled={busy}>{busy ? <Loader2 className="animate-spin" /> : <Mail />}{sentTo ? 'Verify email code' : 'Send email OTP'}</Button>
    {sentTo && <div className="flex flex-wrap gap-2"><Button type="button" variant="ghost" disabled={busy || cooldown > 0} onClick={() => { setSentTo(''); setCode(''); }}>{cooldown ? `Resend in ${cooldown}s` : 'Request another code'}</Button><Button type="button" variant="ghost" disabled={busy} onClick={() => { setSentTo(''); setCode(''); setError(''); }}>Change email</Button></div>}
  </form>;
}