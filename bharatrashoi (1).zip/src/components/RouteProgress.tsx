import { useRouter, useRouterState } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";

type Phase = "idle" | "loading" | "done" | "error";

/**
 * Top-of-page progress bar for TanStack Router transitions.
 * - Grows smoothly while loading, snaps to 100% on success, then fades.
 * - Switches to a red error state with a Retry button if the transition fails.
 */
export function RouteProgress() {
  const router = useRouter();
  const isLoading = useRouterState({ select: (s) => s.isLoading });
  const routerError = useRouterState({
    select: (s) => {
      const match = [...s.matches].reverse().find((m) => m.status === "error");
      return match?.error ? String((match.error as Error)?.message ?? "Something went wrong") : null;
    },
  });

  const [phase, setPhase] = useState<Phase>("idle");
  const [progress, setProgress] = useState(0);
  const rafRef = useRef<number | undefined>(undefined);
  const hideRef = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  useEffect(() => {
    if (routerError) {
      setPhase("error");
      setProgress(100);
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    }
  }, [routerError]);

  useEffect(() => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    if (hideRef.current) clearTimeout(hideRef.current);

    if (isLoading) {
      setPhase("loading");
      setProgress((p) => (p < 8 ? 8 : p));
      const tick = () => {
        setProgress((p) => (p < 88 ? p + (88 - p) * 0.08 : p));
        rafRef.current = requestAnimationFrame(tick);
      };
      rafRef.current = requestAnimationFrame(tick);
    } else if (phase === "loading") {
      setProgress(100);
      setPhase("done");
      hideRef.current = setTimeout(() => {
        setPhase("idle");
        setProgress(0);
      }, 320);
    }

    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isLoading]);

  if (phase === "idle") return null;

  const isError = phase === "error";

  return (
    <>
      <div
        className="pointer-events-none fixed inset-x-0 top-0 z-[100] h-[2.5px] overflow-hidden bg-[color-mix(in_oklab,var(--gold)_10%,transparent)]"
        role="progressbar"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={Math.round(progress)}
      >
        <div
          className={`h-full origin-left transition-[width] duration-200 ease-out ${
            isError
              ? "bg-[linear-gradient(90deg,oklch(0.58_0.18_25),oklch(0.5_0.19_28))] shadow-[0_0_10px_oklch(0.55_0.19_28/0.6)]"
              : "shadow-[0_0_10px_color-mix(in_oklab,var(--gold)_60%,transparent)]"
          }`}
          style={{ width: `${progress}%`, ...(!isError ? { backgroundImage: "var(--gradient-gold)" } : {}) }}
        />
      </div>
      {isError && (
        <div className="pointer-events-auto fixed left-1/2 top-4 z-[101] -translate-x-1/2">
          <div className="glass flex items-center gap-3 rounded-full border border-[oklch(0.55_0.19_28/0.35)] px-4 py-2 text-sm shadow-[var(--shadow-card)]">
            <span aria-hidden className="inline-block h-2 w-2 rounded-full bg-[oklch(0.55_0.19_28)]" />
            <span className="font-medium text-[oklch(0.42_0.17_25)]">Couldn't load this page.</span>
            <button
              type="button"
              onClick={() => {
                setPhase("idle");
                setProgress(0);
                router.invalidate();
              }}
              className="rounded-full bg-[oklch(0.5_0.19_28)] px-3 py-1 text-xs font-semibold text-[oklch(0.98_0.01_88)] transition hover:brightness-110"
            >
              Retry
            </button>
          </div>
        </div>
      )}
    </>
  );
}
