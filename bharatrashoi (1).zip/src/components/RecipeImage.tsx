import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { ImageOff } from "lucide-react";

const cache = new Map<string, string>();

/** Resolves an image_url / video_url stored in the DB. Accepts a full URL
 *  or a storage path within the given bucket and produces a signed URL. */
async function resolve(bucket: string, value: string): Promise<string> {
  const key = `${bucket}:${value}`;
  if (cache.has(key)) return cache.get(key)!;
  if (/^https?:\/\//i.test(value) || value.startsWith("data:")) {
    cache.set(key, value);
    return value;
  }
  const { data, error } = await supabase.storage
    .from(bucket)
    .createSignedUrl(value, 60 * 60 * 24);
  if (error || !data) throw error ?? new Error("Failed to sign URL");
  cache.set(key, data.signedUrl);
  return data.signedUrl;
}

export function useStorageUrl(src: string | null, bucket = "recipe-images") {
  const [url, setUrl] = useState<string | null>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    setFailed(false);
    setUrl(null);
    if (!src) return;
    let cancelled = false;
    resolve(bucket, src)
      .then(u => !cancelled && setUrl(u))
      .catch(() => !cancelled && setFailed(true));
    return () => {
      cancelled = true;
    };
  }, [src, bucket]);

  return { url, failed };
}

export function RecipeImage({
  src,
  alt,
  className,
  bucket = "recipe-images",
}: {
  src: string | null;
  alt: string;
  className?: string;
  bucket?: string;
}) {
  const { url, failed } = useStorageUrl(src, bucket);

  if (!src || failed) {
    return (
      <div className={`grid place-items-center bg-[linear-gradient(140deg,color-mix(in_oklab,var(--saffron)_18%,var(--card)),color-mix(in_oklab,var(--india-green)_14%,var(--card)))] ${className ?? ""}`}>
        <ImageOff className="h-8 w-8 text-muted-foreground/50" aria-hidden="true" />
      </div>
    );
  }

  return (
    <>
      {!url && <div className={`skeleton ${className ?? ""}`} aria-hidden="true" />}
      <img
        src={url ?? undefined}
        alt={alt}
        loading="lazy"
        className={`${className ?? ""} ${url ? "opacity-100" : "hidden opacity-0"} transition-opacity duration-500`}
      />
    </>
  );
}
