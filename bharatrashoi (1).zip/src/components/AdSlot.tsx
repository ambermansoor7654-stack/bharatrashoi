// Ad slot — automatically hidden for Premium / admin accounts.
import { Sparkles } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { usePremium } from "@/lib/use-premium";

export function AdSlot({ label = "Sponsored", className = "" }: { label?: string; className?: string }) {
  const { isPremium, loading } = usePremium();
  if (loading || isPremium) return null;

  return (
    <aside
      aria-label="Advertisement"
      className={`flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-dashed border-[color-mix(in_oklab,var(--gold)_28%,transparent)] bg-[color-mix(in_oklab,var(--muted)_55%,transparent)] px-4 py-3.5 ${className}`}
    >
      <div>
        <div className="eyebrow">{label}</div>
        <p className="mt-1 text-sm text-muted-foreground">
          Ads keep Bharat Rasoi free. Go Premium for an ad-free kitchen.
        </p>
      </div>
      <Link to="/premium" className="btn-gold inline-flex shrink-0 items-center gap-1.5 rounded-full px-4 py-2 text-xs font-semibold">
        <Sparkles className="h-3.5 w-3.5" /> Remove ads
      </Link>
    </aside>
  );
}
