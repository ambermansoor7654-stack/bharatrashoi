import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { BadgeCheck, Check, Crown, Loader2, RefreshCw, X } from "lucide-react";
import { PLANS, formatDate, type PlanId } from "@/lib/premium";
import { listAllPayments, reviewPayment, setUserVerified, grantPremiumManually } from "@/lib/premium.functions";
import { PremiumBadge } from "@/components/PremiumBadges";

type Filter = "pending" | "approved" | "rejected" | "all";

const STATUS_STYLE: Record<string, string> = {
  approved: "bg-[oklch(0.5_0.11_152/0.16)] text-[var(--india-green)]",
  rejected: "bg-[oklch(0.55_0.19_28/0.14)] text-[var(--destructive)]",
  pending: "bg-[color-mix(in_oklab,var(--gold)_20%,transparent)] text-[color-mix(in_oklab,var(--gold)_70%,var(--foreground))]",
};

export function PremiumAdminPanel() {
  const fetchPayments = useServerFn(listAllPayments);
  const review = useServerFn(reviewPayment);
  const verify = useServerFn(setUserVerified);
  const grant = useServerFn(grantPremiumManually);
  const [filter, setFilter] = useState<Filter>("pending");
  const [busyId, setBusyId] = useState<string | null>(null);

  const { data, isLoading, refetch } = useQuery({
    queryKey: ["admin-payments"],
    queryFn: () => fetchPayments(),
    refetchInterval: 30_000,
  });

  const rows = (data ?? []).filter((p) => filter === "all" || p.status === filter);
  const pendingCount = (data ?? []).filter((p) => p.status === "pending").length;

  async function act(id: string, decision: "approved" | "rejected") {
    setBusyId(id);
    try {
      const res = await review({ data: { paymentId: id, decision } });
      if (!res.ok) toast.error(res.message);
      else toast.success(decision === "approved" ? "Premium activated for this user 👑" : "Payment rejected.");
      await refetch();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Action failed.");
    } finally {
      setBusyId(null);
    }
  }

  async function toggleVerified(userId: string, next: boolean) {
    setBusyId(userId);
    try {
      await verify({ data: { userId, verified: next } });
      toast.success(next ? "Blue tick granted." : "Blue tick removed.");
      await refetch();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Action failed.");
    } finally {
      setBusyId(null);
    }
  }

  async function giveFreePremium(userId: string, plan: PlanId) {
    setBusyId(userId);
    try {
      await grant({ data: { userId, plan } });
      toast.success(`${PLANS[plan].label} Premium granted.`);
      await refetch();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Action failed.");
    } finally {
      setBusyId(null);
    }
  }

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="panel relative overflow-hidden rounded-3xl p-5 sm:p-6"
    >
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Crown className="h-5 w-5 text-[var(--gold)]" />
          <h2 className="font-display text-2xl">Premium payments</h2>
          {pendingCount > 0 && (
            <span className="rounded-full bg-[color-mix(in_oklab,var(--gold)_22%,transparent)] px-2.5 py-0.5 text-[11px] font-bold text-[color-mix(in_oklab,var(--gold)_70%,var(--foreground))]">
              {pendingCount} pending
            </span>
          )}
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {(["pending", "approved", "rejected", "all"] as Filter[]).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              aria-pressed={filter === f}
              className={`rounded-full px-3 py-1.5 text-xs font-semibold capitalize transition ${
                filter === f ? "btn-gold" : "btn-quiet"
              }`}
            >
              {f}
            </button>
          ))}
          <button onClick={() => refetch()} aria-label="Refresh" className="btn-quiet grid h-8 w-8 place-items-center rounded-full">
            <RefreshCw className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {isLoading ? (
        <div className="grid place-items-center py-10">
          <Loader2 className="h-6 w-6 animate-spin text-primary" />
        </div>
      ) : rows.length === 0 ? (
        <p className="py-8 text-center text-sm text-muted-foreground">No {filter === "all" ? "" : filter} payments yet.</p>
      ) : (
        <ul className="mt-4 divide-y divide-[color-mix(in_oklab,var(--gold)_14%,transparent)]">
          {rows.map((p) => (
            <li key={p.id} className="py-4 first:pt-0 last:pb-0">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5 font-semibold">
                    <span className="truncate">{p.user?.name || p.user?.email || "Unknown user"}</span>
                    {p.user?.verified && <BadgeCheck className="h-4 w-4 shrink-0 text-[#1d9bf0]" />}
                    {p.user?.is_premium && <PremiumBadge />}
                  </div>
                  <div className="truncate text-xs text-muted-foreground">{p.user?.email}</div>
                  <div className="mt-1 text-xs text-muted-foreground">
                    ₹{p.amount} · {PLANS[(p.plan as PlanId) ?? "monthly"].label} · {formatDate(p.created_at)}
                    {p.reference ? ` · Ref ${p.reference}` : ""}
                  </div>
                  {p.note && <div className="mt-1 text-xs italic text-muted-foreground">“{p.note}”</div>}
                  {p.user?.premium_expiry_date && (
                    <div className="mt-1 text-xs text-[var(--india-green)]">Premium till {formatDate(p.user.premium_expiry_date)}</div>
                  )}
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  {p.status === "pending" ? (
                    <>
                      <button
                        onClick={() => act(p.id, "approved")}
                        disabled={busyId !== null}
                        className="inline-flex items-center gap-1.5 rounded-full bg-[oklch(0.5_0.11_152/0.16)] px-3 py-1.5 text-xs font-bold text-[var(--india-green)] transition hover:bg-[oklch(0.5_0.11_152/0.24)] disabled:opacity-60"
                      >
                        {busyId === p.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}{" "}
                        Approve
                      </button>
                      <button
                        onClick={() => act(p.id, "rejected")}
                        disabled={busyId !== null}
                        className="inline-flex items-center gap-1.5 rounded-full bg-[oklch(0.55_0.19_28/0.12)] px-3 py-1.5 text-xs font-bold text-[var(--destructive)] transition hover:bg-[oklch(0.55_0.19_28/0.2)] disabled:opacity-60"
                      >
                        <X className="h-3.5 w-3.5" /> Reject
                      </button>
                    </>
                  ) : (
                    <span className={`rounded-full px-3 py-1 text-[11px] font-bold uppercase ${STATUS_STYLE[p.status]}`}>
                      {p.status}
                    </span>
                  )}

                  <button
                    onClick={() => toggleVerified(p.user_id, !p.user?.verified)}
                    disabled={busyId !== null}
                    className="btn-quiet inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold disabled:opacity-60"
                  >
                    <BadgeCheck className="h-3.5 w-3.5 text-[#1d9bf0]" />
                    {p.user?.verified ? "Remove tick" : "Give blue tick"}
                  </button>

                  {!p.user?.is_premium && (
                    <button
                      onClick={() => giveFreePremium(p.user_id, "monthly")}
                      disabled={busyId !== null}
                      className="btn-quiet inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold disabled:opacity-60"
                    >
                      <Crown className="h-3.5 w-3.5 text-[var(--gold)]" /> Grant 1 month
                    </button>
                  )}
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </motion.section>
  );
}
