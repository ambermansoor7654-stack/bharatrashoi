import { Link } from "@tanstack/react-router";
import { ArrowRight, ChefHat, MapPin, Star } from "lucide-react";
import { useEffect, useRef } from "react";
import heroThali from "@/assets/hero-thali.jpg";

/**
 * Home hero — cinematic food photography with a whisper of pointer parallax.
 *
 * Perf: parallax writes CSS vars from one rAF loop (no React renders, GPU-only
 * transforms), attaches only on `pointer: fine`, and is disabled on mobile and
 * reduced-motion via styles.css.
 */
export function Hero() {
  const stageRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const stage = stageRef.current;
    if (!stage) return;

    const fine = window.matchMedia("(pointer: fine)").matches;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (!fine || reduce) return;

    let raf = 0;
    let targetX = 0, targetY = 0, currentX = 0, currentY = 0;

    const onMove = (e: PointerEvent) => {
      if (e.pointerType !== "mouse") return;
      const rect = stage.getBoundingClientRect();
      targetX = ((e.clientX - rect.left) / rect.width - 0.5) * 2;
      targetY = ((e.clientY - rect.top) / rect.height - 0.5) * 2;
      if (!raf) raf = requestAnimationFrame(tick);
    };
    const onLeave = () => {
      targetX = 0; targetY = 0;
      if (!raf) raf = requestAnimationFrame(tick);
    };
    const tick = () => {
      currentX += (targetX - currentX) * 0.1;
      currentY += (targetY - currentY) * 0.1;
      stage.style.setProperty("--px", currentX.toFixed(3));
      stage.style.setProperty("--py", currentY.toFixed(3));
      raf = Math.abs(targetX - currentX) > 0.001 || Math.abs(targetY - currentY) > 0.001
        ? requestAnimationFrame(tick)
        : 0;
    };

    stage.addEventListener("pointermove", onMove, { passive: true });
    stage.addEventListener("pointerleave", onLeave);
    return () => {
      stage.removeEventListener("pointermove", onMove);
      stage.removeEventListener("pointerleave", onLeave);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <section
      ref={stageRef}
      aria-labelledby="hero-heading"
      className="hero-stage relative isolate min-h-[min(680px,78dvh)] overflow-hidden rounded-[1.25rem] border border-[color-mix(in_oklab,var(--gold)_28%,transparent)] bg-[oklch(0.16_0.026_40)] text-[oklch(0.97_0.01_88)] shadow-[var(--shadow-card)] sm:min-h-0 sm:rounded-[2.25rem]"
    >
      {/* Photography plate */}
      <img
        src={heroThali}
        alt="Indian thali with dal, biryani, kebabs and fresh naan on a dark table"
        width={1600}
        height={1104}
        className="hero-layer hero-photo absolute inset-0 -z-20 h-full w-full object-cover"
      />
      <div aria-hidden="true" className="absolute inset-0 -z-10 bg-[linear-gradient(100deg,oklch(0.13_0.02_38/0.95)_0%,oklch(0.14_0.02_38/0.78)_42%,oklch(0.14_0.02_38/0.25)_72%,transparent_100%)]" />
      <div aria-hidden="true" className="absolute inset-0 -z-10 bg-[linear-gradient(to_top,oklch(0.12_0.018_38/0.95),transparent_55%)] sm:bg-[linear-gradient(to_top,oklch(0.12_0.018_38/0.7),transparent_60%)]" />
      <div aria-hidden="true" className="hero-grain pointer-events-none absolute inset-0 -z-10" />

      <div className="hero-layer hero-copy relative z-10 flex min-h-[min(680px,78dvh)] max-w-2xl flex-col justify-end px-5 pb-7 pt-20 sm:block sm:min-h-0 sm:px-9 sm:pb-12 sm:pt-16 lg:min-h-[620px] lg:px-12 lg:pb-16 lg:pt-24">
        <span className="inline-flex items-center gap-2 rounded-full border border-[oklch(0.86_0.09_88/0.35)] bg-[oklch(1_0_0/0.06)] px-3.5 py-1.5 backdrop-blur">
          <Star className="h-3 w-3 fill-[var(--saffron)] text-[var(--saffron)]" aria-hidden="true" />
          <span className="eyebrow !text-[oklch(0.9_0.06_84)]">Bharat Rasoi · Est. Kitchen</span>
        </span>

        <h1 id="hero-heading" className="mt-5 font-display text-[2.35rem] leading-[0.98] min-[390px]:text-[2.6rem] sm:mt-6 sm:text-6xl lg:text-[4.75rem]">
          The recipes of India,
          <br />
          <em className="not-italic text-gradient">plated like fine dining.</em>
        </h1>

        <p className="mt-5 max-w-lg text-sm leading-relaxed text-[oklch(0.93_0.01_88/0.78)] sm:text-base">
          Authentic dishes from every state, an AI chef on standby, and a living kitchen where
          something new arrives every day.
        </p>

        <div className="mt-6 grid grid-cols-1 gap-2.5 min-[390px]:grid-cols-2 sm:mt-8 sm:flex sm:flex-wrap sm:items-center sm:gap-3">
          <Link
            to="/states"
            className="btn-gold inline-flex min-h-12 touch-manipulation items-center justify-center gap-2 rounded-full px-5 text-sm font-semibold sm:px-7"
          >
            Explore the states <ArrowRight className="h-4 w-4" aria-hidden="true" />
          </Link>
          <Link
            to="/chef"
            className="inline-flex min-h-12 touch-manipulation items-center justify-center gap-2 rounded-full border border-[oklch(1_0_0/0.18)] bg-[oklch(1_0_0/0.08)] px-5 text-sm font-semibold text-[oklch(0.97_0.01_88)] backdrop-blur-md transition hover:bg-[oklch(1_0_0/0.14)] active:scale-[0.97] sm:px-6"
          >
            <ChefHat className="h-4 w-4 text-[var(--saffron)]" aria-hidden="true" /> Ask the AI Chef
          </Link>
        </div>

        <dl className="mt-7 grid max-w-md grid-cols-3 gap-2 border-t border-[oklch(1_0_0/0.12)] pt-5 min-[390px]:gap-4 sm:mt-10 sm:gap-6 sm:pt-6">
          {[
            { k: "29", v: "States & regions" },
            { k: "500+", v: "Recipes" },
            { k: "24/7", v: "AI Chef" },
          ].map(s => (
            <div key={s.v}>
              <dt className="sr-only">{s.v}</dt>
              <dd className="font-display text-2xl text-[oklch(0.92_0.07_84)] sm:text-3xl">{s.k}</dd>
              <div className="mt-1 text-[9px] font-medium uppercase text-[oklch(0.93_0.01_88/0.6)] sm:text-[10px] sm:tracking-[0.16em]">{s.v}</div>
            </div>
          ))}
        </dl>
      </div>

      <div className="pointer-events-none absolute bottom-5 right-5 hidden items-center gap-2 rounded-full border border-[oklch(1_0_0/0.16)] bg-[oklch(1_0_0/0.08)] px-4 py-2 text-[11px] font-medium text-[oklch(0.95_0.01_88)] backdrop-blur-md lg:flex">
        <MapPin className="h-3.5 w-3.5 text-[var(--saffron)]" aria-hidden="true" /> Sourced from every corner of Bharat
      </div>
    </section>
  );
}
