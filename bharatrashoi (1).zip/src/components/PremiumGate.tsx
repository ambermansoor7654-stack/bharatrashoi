// Premium paywall wrapper used for exclusive recipes and premium-only actions.
import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { Crown, Lock } from "lucide-react";
import { usePremium } from "@/lib/use-premium";

function usePremiumAccess() {
  const premium = usePremium();
  return { allowed: premium.isPremium, loading: premium.loading, signedIn: premium.signedIn };
}

export function PremiumGate({
  title,
  description,
  children,
}: {
  title: string;
  description: string;
  children: ReactNode;
}) {
  const { allowed, loading } = usePremiumAccess();
  if (loading) return null;
  if (allowed) return <>{children}</>;

  return (
    <section className="panel-dark relative overflow-hidden rounded-3xl p-8 text-center">
      <div
        aria-hidden="true"
        className="absolute inset-0 -z-10 bg-[radial-gradient(120%_140%_at_50%_0%,color-mix(in_oklab,var(--gold)_22%,transparent),transparent_65%)]"
      />
      <div className="mx-auto grid h-14 w-14 place-items-center rounded-full border border-[color-mix(in_oklab,var(--gold)_35%,transparent)] bg-[color-mix(in_oklab,var(--gold)_16%,transparent)] shadow-[var(--shadow-glow)]">
        <Lock className="h-6 w-6 text-[var(--gold)]" />
      </div>
      <h2 className="mt-4 font-display text-2xl">{title}</h2>
      <p className="mx-auto mt-2 max-w-md text-sm text-[oklch(0.88_0.02_88)]">{description}</p>
      <Link to="/premium" className="btn-gold mt-5 inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-semibold">
        <Crown className="h-4 w-4" /> Unlock with Premium
      </Link>
    </section>
  );
}

export function PremiumOnlyBadge({ label = "Premium" }: { label?: string }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-full border border-[color-mix(in_oklab,var(--gold)_35%,transparent)] bg-[color-mix(in_oklab,var(--gold)_14%,transparent)] px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-[color-mix(in_oklab,var(--gold)_70%,var(--foreground))]">
      <Lock className="h-3 w-3" aria-hidden="true" /> {label}
    </span>
  );
}
