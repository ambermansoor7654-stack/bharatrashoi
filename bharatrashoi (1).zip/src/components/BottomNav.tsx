import { Link, useRouterState } from "@tanstack/react-router";
import { Home, Map, Video, User, ChefHat } from "lucide-react";

const items = [
  { to: "/" as const, label: "Home", icon: Home },
  { to: "/states" as const, label: "States", icon: Map },
  { to: "/chef" as const, label: "AI Chef", icon: ChefHat, accent: true },
  { to: "/channels" as const, label: "Channels", icon: Video },
  { to: "/profile" as const, label: "Profile", icon: User },
];

export function BottomNav() {
  const pathname = useRouterState({ select: s => s.location.pathname });

  return (
    <nav
      aria-label="Bottom navigation"
      className="fixed bottom-[max(0.5rem,env(safe-area-inset-bottom))] left-1/2 z-40 w-[calc(100%-1rem)] max-w-md -translate-x-1/2 md:hidden"
    >
      <ul className="grid grid-cols-5 items-center rounded-[1.35rem] border border-[color-mix(in_oklab,var(--gold)_24%,transparent)] bg-[color-mix(in_oklab,var(--cream)_92%,transparent)] px-1.5 py-1.5 shadow-[var(--shadow-card)] backdrop-blur-2xl">
        {items.map(({ to, label, icon: Icon, accent }) => {
          const active = to === "/" ? pathname === to : pathname.startsWith(to);
          if (accent) {
            return (
              <li key={to} className="contents">
                <Link
                  to={to}
                  aria-label={label}
                  aria-current={active ? "page" : undefined}
                  className="btn-gold mx-auto -mt-7 grid h-14 w-14 touch-manipulation place-items-center rounded-full ring-4 ring-[color-mix(in_oklab,var(--cream)_92%,transparent)]"
                >
                  <Icon className="h-[22px] w-[22px]" aria-hidden="true" />
                </Link>
              </li>
            );
          }
          return (
            <li key={to} className="contents">
              <Link
                to={to}
                aria-label={label}
                aria-current={active ? "page" : undefined}
                className={`flex min-h-12 min-w-0 touch-manipulation flex-col items-center justify-center gap-0.5 rounded-2xl px-1 py-1 transition active:scale-95 ${active ? "bg-[color-mix(in_oklab,var(--gold)_10%,transparent)]" : ""}`}
              >
                <Icon
                  className={`h-[19px] w-[19px] transition ${active ? "text-primary" : "text-muted-foreground"}`}
                  aria-hidden="true"
                />
                <span className={`max-w-full truncate text-[9px] font-semibold ${active ? "text-primary" : "text-muted-foreground"}`}>
                  {label}
                </span>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
