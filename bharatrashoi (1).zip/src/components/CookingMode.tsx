import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  X,
  ChevronLeft,
  ChevronRight,
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  CheckCircle2,
  Timer as TimerIcon,
} from "lucide-react";
import { toast } from "sonner";
import { recordCooked } from "@/lib/cooking-activity";

/** Pulls "10 minutes" / "5 mins" / "1 hour" out of a step and returns seconds. */
function suggestedSeconds(step: string): number | null {
  const m = step.match(/(\d+(?:\.\d+)?)\s*(?:-\s*\d+\s*)?(hours?|hrs?|minutes?|mins?|seconds?|secs?)/i);
  if (!m) return null;
  const n = parseFloat(m[1]);
  const unit = m[2].toLowerCase();
  if (unit.startsWith("h")) return Math.round(n * 3600);
  if (unit.startsWith("m")) return Math.round(n * 60);
  return Math.round(n);
}

function tokenize(text: string) {
  return text.toLowerCase().replace(/[^a-z0-9\s]/g, " ").split(/\s+/).filter((w) => w.length > 3);
}

/** Ingredients that are mentioned in the current step. */
function ingredientsForStep(step: string, ingredients: string[]) {
  const words = new Set(tokenize(step));
  return ingredients.filter((ing) => tokenize(ing).some((w) => words.has(w)));
}

function mmss(total: number) {
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export function CookingMode({
  recipe,
  onClose,
}: {
  recipe: { id: string; name: string; steps: string[]; ingredients: string[] };
  onClose: () => void;
}) {
  const steps = recipe.steps.length ? recipe.steps : ["No steps have been added for this recipe yet."];
  const [index, setIndex] = useState(0);
  const [done, setDone] = useState<boolean[]>(() => steps.map(() => false));
  const [voiceOn, setVoiceOn] = useState(false);
  const [finished, setFinished] = useState(false);

  const step = steps[index];
  const stepIngredients = useMemo(() => ingredientsForStep(step, recipe.ingredients), [step, recipe.ingredients]);
  const suggested = useMemo(() => suggestedSeconds(step), [step]);

  // ---- timer ----
  const [seconds, setSeconds] = useState(suggested ?? 300);
  const [running, setRunning] = useState(false);
  const beeped = useRef(false);

  useEffect(() => {
    setSeconds(suggested ?? 300);
    setRunning(false);
    beeped.current = false;
  }, [index, suggested]);

  useEffect(() => {
    if (!running) return;
    const t = window.setInterval(() => setSeconds((s) => Math.max(0, s - 1)), 1000);
    return () => window.clearInterval(t);
  }, [running]);

  useEffect(() => {
    if (seconds !== 0 || !running || beeped.current) return;
    beeped.current = true;
    setRunning(false);
    toast.success("Timer done — check your pan! 🔥");
    if (typeof navigator !== "undefined") navigator.vibrate?.([200, 100, 200]);
    speak("Timer finished.");
  }, [seconds, running]);

  // ---- voice guide ----
  const speak = useCallback(
    (text: string) => {
      if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
      const u = new SpeechSynthesisUtterance(text);
      u.rate = 0.95;
      u.lang = "en-IN";
      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(u);
    },
    [],
  );

  useEffect(() => {
    if (!voiceOn || finished) return;
    speak(`Step ${index + 1}. ${step}`);
  }, [voiceOn, index, step, finished, speak]);

  useEffect(() => {
    return () => {
      if (typeof window !== "undefined" && "speechSynthesis" in window) window.speechSynthesis.cancel();
    };
  }, []);

  function toggleVoice() {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) {
      toast.error("Voice guide isn't supported on this browser.");
      return;
    }
    if (voiceOn) {
      window.speechSynthesis.cancel();
      setVoiceOn(false);
    } else {
      setVoiceOn(true);
    }
  }

  const markDone = useCallback(
    (i: number) => setDone((d) => d.map((v, idx) => (idx === i ? true : v))),
    [],
  );

  const next = useCallback(() => {
    markDone(index);
    if (index < steps.length - 1) {
      setIndex(index + 1);
      return;
    }
    setFinished(true);
    recordCooked({ id: recipe.id, name: recipe.name }, steps.length);
    if (typeof window !== "undefined" && "speechSynthesis" in window) window.speechSynthesis.cancel();
  }, [index, steps.length, markDone, recipe.id, recipe.name]);

  const prev = useCallback(() => setIndex((i) => Math.max(0, i - 1)), []);

  // keyboard + scroll lock
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") next();
      if (e.key === "ArrowLeft") prev();
    };
    window.addEventListener("keydown", onKey);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prevOverflow;
    };
  }, [next, prev, onClose]);

  const progress = ((done.filter(Boolean).length + (finished ? 0 : 0)) / steps.length) * 100;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      role="dialog"
      aria-modal="true"
      aria-label={`Cooking mode for ${recipe.name}`}
      className="fixed inset-0 z-[80] overflow-y-auto bg-[oklch(0.16_0.02_40)] text-[oklch(0.97_0.01_88)]"
    >
      <div className="mx-auto flex min-h-full w-full max-w-3xl flex-col px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-[max(1rem,env(safe-area-inset-top))] min-[390px]:px-5 sm:px-8 sm:py-6">
        <header className="flex items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-[oklch(0.86_0.09_75)]">Cooking mode</p>
            <h2 className="truncate font-display text-2xl">{recipe.name}</h2>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={toggleVoice}
              aria-pressed={voiceOn}
              aria-label={voiceOn ? "Turn voice guide off" : "Turn voice guide on"}
              className={`grid h-11 w-11 place-items-center rounded-full transition ${
                voiceOn ? "bg-[oklch(0.86_0.14_75)] text-[oklch(0.2_0.04_44)]" : "bg-white/10 hover:bg-white/20"
              }`}
            >
              {voiceOn ? <Volume2 className="h-5 w-5" aria-hidden="true" /> : <VolumeX className="h-5 w-5" aria-hidden="true" />}
            </button>
            <button
              onClick={onClose}
              aria-label="Exit cooking mode"
              className="grid h-11 w-11 place-items-center rounded-full bg-white/10 transition hover:bg-white/20"
            >
              <X className="h-5 w-5" aria-hidden="true" />
            </button>
          </div>
        </header>

        <div className="mt-5">
          <div className="flex items-center justify-between text-xs text-white/70">
            <span>
              Step {Math.min(index + 1, steps.length)} of {steps.length}
            </span>
            <span>{Math.round(progress)}% complete</span>
          </div>
          <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/12">
            <motion.div
              className="h-full rounded-full bg-[linear-gradient(90deg,oklch(0.78_0.16_58),oklch(0.88_0.14_88))]"
              animate={{ width: `${progress}%` }}
              transition={{ type: "spring", stiffness: 120, damping: 20 }}
            />
          </div>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {steps.map((_, i) => (
              <button
                key={i}
                onClick={() => { setFinished(false); setIndex(i); }}
                aria-label={`Go to step ${i + 1}`}
                aria-current={i === index && !finished ? "step" : undefined}
                className={`h-2 w-6 rounded-full transition ${
                  i === index && !finished
                    ? "bg-[oklch(0.86_0.14_75)]"
                    : done[i]
                      ? "bg-[oklch(0.72_0.14_150)]"
                      : "bg-white/15"
                }`}
              />
            ))}
          </div>
        </div>

        <AnimatePresence mode="wait">
          {finished ? (
            <motion.section
              key="finished"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="mt-6 flex flex-1 flex-col items-center justify-center rounded-2xl border border-white/10 bg-white/5 p-5 text-center sm:mt-8 sm:rounded-3xl sm:p-8"
            >
              <CheckCircle2 className="h-14 w-14 text-[oklch(0.78_0.15_150)]" aria-hidden="true" />
              <h3 className="mt-4 font-display text-3xl">Shabaash, chef!</h3>
              <p className="mt-2 max-w-sm text-sm text-white/70">
                You finished {recipe.name}. It's added to your streak and cooking stats.
              </p>
              <div className="mt-6 flex flex-wrap justify-center gap-3">
                <button
                  onClick={() => { setDone(steps.map(() => false)); setIndex(0); setFinished(false); }}
                  className="inline-flex items-center gap-2 rounded-full bg-white/10 px-5 py-3 text-sm font-semibold transition hover:bg-white/20"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" /> Cook again
                </button>
                <button
                  onClick={onClose}
                  className="inline-flex items-center gap-2 rounded-full bg-[oklch(0.86_0.14_75)] px-5 py-3 text-sm font-semibold text-[oklch(0.2_0.04_44)]"
                >
                  Done
                </button>
              </div>
            </motion.section>
          ) : (
            <motion.section
              key={index}
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.25 }}
              className="mt-8 flex-1"
            >
              <p className="font-display text-4xl leading-none text-[oklch(0.86_0.12_78)] sm:text-5xl">
                {String(index + 1).padStart(2, "0")}
              </p>
              <p className="mt-3 text-lg leading-relaxed min-[390px]:text-xl sm:mt-4 sm:text-2xl">{step}</p>

              {stepIngredients.length > 0 && (
                <div className="mt-7 rounded-3xl border border-white/10 bg-white/5 p-5">
                  <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-white/60">
                    Ingredients for this step
                  </p>
                  <ul className="mt-3 grid gap-2 sm:grid-cols-2">
                    {stepIngredients.map((ing) => (
                      <li key={ing} className="flex items-start gap-2 text-sm text-white/85">
                        <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-[oklch(0.86_0.14_75)]" />
                        {ing}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="mt-6 rounded-3xl border border-white/10 bg-white/5 p-5">
                <div className="grid grid-cols-1 gap-4 min-[390px]:grid-cols-[minmax(0,1fr)_auto] min-[390px]:items-center">
                  <div>
                    <p className="inline-flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.18em] text-white/60">
                      <TimerIcon className="h-3.5 w-3.5" aria-hidden="true" /> Step timer
                    </p>
                    <p className="mt-1 font-display text-4xl tabular-nums" aria-live="polite">
                      {mmss(seconds)}
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    {[1, 5, 10].map((m) => (
                      <button
                        key={m}
                        onClick={() => setSeconds((s) => s + m * 60)}
                        className="rounded-full bg-white/10 px-3 py-2 text-xs font-semibold transition hover:bg-white/20"
                      >
                        +{m}m
                      </button>
                    ))}
                    <button
                      onClick={() => { beeped.current = false; setRunning((r) => !r); }}
                      className="inline-flex items-center gap-2 rounded-full bg-[oklch(0.86_0.14_75)] px-4 py-2 text-sm font-semibold text-[oklch(0.2_0.04_44)]"
                    >
                      {running ? <Pause className="h-4 w-4" aria-hidden="true" /> : <Play className="h-4 w-4" aria-hidden="true" />}
                      {running ? "Pause" : "Start"}
                    </button>
                    <button
                      onClick={() => { setRunning(false); beeped.current = false; setSeconds(suggested ?? 300); }}
                      aria-label="Reset timer"
                      className="grid h-10 w-10 place-items-center rounded-full bg-white/10 transition hover:bg-white/20"
                    >
                      <RotateCcw className="h-4 w-4" aria-hidden="true" />
                    </button>
                  </div>
                </div>
                {suggested && <p className="mt-3 text-xs text-white/55">Suggested from this step: {mmss(suggested)}</p>}
              </div>
            </motion.section>
          )}
        </AnimatePresence>

        {!finished && (
          <div className="sticky bottom-0 mt-6 grid grid-cols-[auto_minmax(0,1fr)] items-center gap-2 bg-[oklch(0.16_0.02_40)] py-3 sm:mt-8 sm:gap-3 sm:py-4">
            <button
              onClick={prev}
              disabled={index === 0}
              className="inline-flex min-h-12 items-center gap-1 rounded-full bg-white/10 px-3 py-3 text-sm font-semibold transition hover:bg-white/20 disabled:opacity-35 min-[390px]:gap-2 min-[390px]:px-5"
            >
              <ChevronLeft className="h-4 w-4" aria-hidden="true" /> <span className="hidden min-[370px]:inline">Previous</span>
            </button>
            <button
              onClick={next}
              className="inline-flex flex-1 items-center justify-center gap-2 rounded-full bg-[linear-gradient(90deg,oklch(0.72_0.17_48),oklch(0.86_0.14_78))] px-6 py-3 text-sm font-bold text-[oklch(0.2_0.04_44)]"
            >
              {index === steps.length - 1 ? "Finish cooking" : "Next step"}
              <ChevronRight className="h-4 w-4" aria-hidden="true" />
            </button>
          </div>
        )}
      </div>
    </motion.div>
  );
}
