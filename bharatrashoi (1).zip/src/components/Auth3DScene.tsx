import { useEffect, useRef, useState, type ReactNode } from "react";
import { motion, useMotionValue, useSpring, useTransform, useReducedMotion } from "framer-motion";

/** Floating 3D spice orbs + pointer-driven tilt card for the login page. */
export function Auth3DScene({ children }: { children: ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();
  // Lightweight mode for phones / touch: fewer orbs, no glare layer, no tilt.
  const [lite, setLite] = useState(true);
  useEffect(() => {
    const mq = window.matchMedia("(max-width: 767px), (pointer: coarse)");
    const update = () => setLite(mq.matches);
    update();
    mq.addEventListener("change", update);
    return () => mq.removeEventListener("change", update);
  }, []);
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const sx = useSpring(mx, { stiffness: 120, damping: 18 });
  const sy = useSpring(my, { stiffness: 120, damping: 18 });
  const rotY = useTransform(sx, [-0.5, 0.5], [-7, 7]);
  const rotX = useTransform(sy, [-0.5, 0.5], [6, -6]);
  const glowX = useTransform(sx, [-0.5, 0.5], ["20%", "80%"]);
  const glowY = useTransform(sy, [-0.5, 0.5], ["15%", "85%"]);

  function onMove(e: React.PointerEvent) {
    if (reduce || lite || e.pointerType !== "mouse" || !ref.current) return;
    const r = ref.current.getBoundingClientRect();
    mx.set((e.clientX - r.left) / r.width - 0.5);
    my.set((e.clientY - r.top) / r.height - 0.5);
  }
  function onLeave() { mx.set(0); my.set(0); }

  const allOrbs = [
    { c: "var(--saffron)", s: 120, x: "6%", y: "8%", d: 7 },
    { c: "var(--gold)", s: 70, x: "88%", y: "14%", d: 9 },
    { c: "var(--spice)", s: 90, x: "82%", y: "78%", d: 8 },
    { c: "var(--saffron)", s: 50, x: "12%", y: "84%", d: 6 },
  ];
  const orbs = lite ? allOrbs.slice(0, 2) : allOrbs;
  const glare = useTransform(
    [glowX, glowY] as never,
    ([x, y]: string[]) => `radial-gradient(500px circle at ${x} ${y}, color-mix(in oklab, var(--gold) 30%, transparent), transparent 60%)`,
  );

  return (
    <div
      ref={ref}
      onPointerMove={onMove}
      onPointerLeave={onLeave}
      className="auth-focus relative mx-auto flex min-h-[70vh] max-w-6xl items-center px-1 py-6 sm:py-10"
      style={{ perspective: lite ? undefined : 1400 }}
    >
      <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
        {orbs.map((o, i) => (
          <motion.div
            key={i}
            className={`absolute rounded-full ${lite ? "" : "blur-[1px]"}`}
            style={{
              left: o.x, top: o.y, width: o.s, height: o.s,
              background: `radial-gradient(circle at 30% 28%, color-mix(in oklab, ${o.c} 35%, var(--foreground)) 0%, ${o.c} 38%, color-mix(in oklab, ${o.c} 40%, var(--background)) 100%)`,
              boxShadow: lite ? undefined : `0 30px 60px -20px color-mix(in oklab, ${o.c} 55%, transparent)`,
              opacity: lite ? 0.4 : 0.55,
              willChange: reduce ? undefined : "transform",
            }}
            animate={reduce ? undefined : lite ? { y: [0, -12, 0] } : { y: [0, -22, 0], rotate: [0, 12, 0] }}
            transition={{ duration: o.d, repeat: Infinity, ease: "easeInOut" }}
          />
        ))}
      </div>

      <motion.div
        initial={reduce ? { opacity: 0 } : lite ? { opacity: 0, y: 20 } : { opacity: 0, rotateX: 18, y: 40, scale: 0.96 }}
        animate={reduce ? { opacity: 1 } : lite ? { opacity: 1, y: 0 } : { opacity: 1, rotateX: 0, y: 0, scale: 1 }}
        transition={{ duration: reduce ? 0.2 : lite ? 0.45 : 0.8, ease: [0.22, 1, 0.36, 1] }}
        style={lite || reduce ? undefined : { rotateX: rotX, rotateY: rotY, transformStyle: "preserve-3d" }}
        className="relative w-full"
      >
        {!lite && !reduce && (
          <motion.div
            aria-hidden
            className="pointer-events-none absolute -inset-px z-20 rounded-[1.75rem] mix-blend-soft-light"
            style={{ background: glare }}
          />
        )}
        <div
          className="grid w-full overflow-hidden rounded-[1.75rem] border border-[color-mix(in_oklab,var(--gold)_22%,transparent)] lg:grid-cols-2"
          style={{
            transform: lite || reduce ? undefined : "translateZ(30px)",
            boxShadow: "0 50px 100px -30px color-mix(in oklab, var(--saffron) 35%, transparent), var(--shadow-card)",
          }}
        >
          {children}
        </div>
      </motion.div>
    </div>
  );
}
