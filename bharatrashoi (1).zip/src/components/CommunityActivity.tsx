import { useEffect } from 'react';
import { useServerFn } from '@tanstack/react-start';
import { useAuth } from '@/lib/auth';
import { recordLogin, recordVisit } from '@/lib/community.functions';
export function CommunityActivity() {
  const { user } = useAuth(); const login = useServerFn(recordLogin); const visit = useServerFn(recordVisit);
  useEffect(() => { try { let visitor = localStorage.getItem('rasoi:visitor'); if (!visitor) { visitor = crypto.randomUUID(); localStorage.setItem('rasoi:visitor', visitor); } void visit({ data: { visitor, path: window.location.pathname } }).catch(() => {}); } catch { /* Storage can be disabled. */ } }, [visit]);
  useEffect(() => { if (!user) return; void login().catch(() => {}); }, [user?.id, login]);
  return null;
}
