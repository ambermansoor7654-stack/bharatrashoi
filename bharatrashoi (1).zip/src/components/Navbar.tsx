import { Link } from "@tanstack/react-router";
import { Crown, LogIn, ShieldCheck, UserRound } from "lucide-react";
import { isAmberAdminEmail, useAuth } from "@/lib/auth";
import { BharatLogo } from "@/components/BharatLogo";
import { AdminNotificationBell } from "@/components/AdminNotificationBell";

const LINKS = [
  { to: "/" as const, label: "Home" },
  { to: "/states" as const, label: "States" },
  { to: "/chef" as const, label: "AI Chef" },
  { to: "/favorites" as const, label: "Favorites" },
  { to: "/channels" as const, label: "Channels" },
  { to: "/premium" as const, label: "Premium" },
];

export function Navbar() {
  const { user, isAdmin } = useAuth();
  const displayName =
    (user?.user_metadata?.full_name as string | undefined) ??
    (user?.user_metadata?.name as string | undefined) ??
    user?.email ??
    "Profile";

  return (
    <header className="sticky top-0 z-40 border-b border-[color-mix(in_oklab,var(--gold)_16%,transparent)] bg-[color-mix(in_oklab,var(--cream)_88%,transparent)] pt-[env(safe-area-inset-top)] backdrop-blur-2xl">
      <div className="mx-auto grid max-w-[1400px] grid-cols-[minmax(0,1fr)_auto] items-center gap-2 px-3.5 py-2.5 min-[390px]:px-4 sm:px-6 sm:py-3 lg:px-10">
        <Link
          to="/"
          aria-label="Bharat Rasoi — home"
          className="flex min-w-0 touch-manipulation items-center gap-2 rounded-2xl sm:gap-2.5"
        >
          <BharatLogo className="h-9 w-9 shrink-0 sm:h-10 sm:w-10" />
          <div className="min-w-0">
            <div className="truncate font-display text-lg leading-none sm:text-xl">Bharat Rasoi</div>
            <div className="mt-0.5 hidden text-[9px] font-medium uppercase tracking-[0.2em] text-muted-foreground min-[370px]:block sm:tracking-[0.28em]">Swaad Ghar Jaisa</div>
          </div>
        </Link>

        <nav aria-label="Primary" className="hidden items-center gap-1 md:flex">
          {[...LINKS, { to: (user ? "/profile" : "/auth") as "/profile" | "/auth", label: "Profile" }].map(l => (
            <Link
              key={l.to}
              to={l.to}
              activeOptions={{ exact: l.to === "/" }}
              activeProps={{ className: "text-foreground after:scale-x-100", "aria-current": "page" }}
              className="relative touch-manipulation rounded-lg px-3.5 py-2 text-[13px] font-medium text-muted-foreground transition after:absolute after:inset-x-3.5 after:bottom-1 after:h-[1.5px] after:origin-left after:scale-x-0 after:bg-[var(--gradient-gold)] after:transition-transform after:duration-300 hover:text-foreground hover:after:scale-x-100"
            >
              {l.label}
            </Link>
          ))}
          {isAdmin && (
            <Link
              to="/admin"
              activeProps={{ className: "bg-[color-mix(in_oklab,var(--gold)_20%,transparent)]", "aria-current": "page" }}
              className="ml-1 inline-flex touch-manipulation items-center gap-1.5 rounded-full border border-[color-mix(in_oklab,var(--gold)_35%,transparent)] px-3.5 py-1.5 text-[12px] font-semibold text-[color-mix(in_oklab,var(--gold)_75%,var(--foreground))] transition hover:bg-[color-mix(in_oklab,var(--gold)_14%,transparent)]"
            >
              <ShieldCheck className="h-3.5 w-3.5" aria-hidden="true" /> Admin
            </Link>
          )}
        </nav>

        <div className="flex shrink-0 items-center gap-1.5 sm:gap-2">
          {user ? (
            <>
              <AdminNotificationBell />
              <Link
                to="/premium"
                aria-label="Bharat Rasoi Premium"
                className="btn-gold hidden touch-manipulation items-center gap-1.5 rounded-full px-4 py-2 text-[12px] font-semibold sm:inline-flex"
              >
                <Crown className="h-3.5 w-3.5" aria-hidden="true" /> Premium
              </Link>
              {isAmberAdminEmail(user.email) && (
                <span className="hidden items-center rounded-full border border-[color-mix(in_oklab,var(--gold)_35%,transparent)] px-3 py-1.5 text-[12px] font-medium text-foreground/80 lg:inline-flex">
                  <span aria-hidden="true" className="mr-1.5">👑</span> Welcome Amber
                </span>
              )}
              <Link
                to="/profile"
                aria-label={`Open profile for ${displayName}`}
                className="grid h-10 w-10 shrink-0 touch-manipulation place-items-center overflow-hidden rounded-full border border-[color-mix(in_oklab,var(--gold)_30%,transparent)] bg-card shadow-[var(--shadow-soft)] transition hover:shadow-[var(--shadow-glow)] active:scale-95"
              >
                {user.user_metadata?.avatar_url || user.user_metadata?.picture ? (
                  <img
                    src={user.user_metadata.avatar_url || user.user_metadata.picture}
                    alt=""
                    className="h-full w-full object-cover"
                    loading="lazy"
                  />
                ) : (
                  <UserRound className="h-[18px] w-[18px] text-primary" aria-hidden="true" />
                )}
              </Link>
            </>
          ) : (
            <Link
              to="/auth"
              className="btn-ink inline-flex min-h-10 touch-manipulation items-center gap-1.5 rounded-full px-3.5 text-[12px] font-semibold min-[390px]:px-5"
            >
              <LogIn className="h-3.5 w-3.5" aria-hidden="true" /> Sign in
            </Link>
          )}
        </div>
      </div>
    </header>
  );
}
