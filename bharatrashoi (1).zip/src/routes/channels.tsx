import { createFileRoute, Link, Outlet, useRouterState } from '@tanstack/react-router';
import { useSuspenseQuery, queryOptions, useQueryClient } from '@tanstack/react-query';
import { useEffect, useState } from 'react';
import { Video, Upload, Trash2, Plus, CheckCircle, ImagePlus, Pencil, X } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/lib/auth';
import { supabase } from '@/integrations/supabase/client';
import { listCommunity } from '@/lib/community.functions';
import { validateChannelVideo } from '@/lib/community-rules';
import { pageMeta } from '@/lib/page-meta';
import { ChannelSubscribe } from '@/components/ChannelSubscribe';
import { useChannelSubscriptions } from '@/lib/channel-subscriptions';

const communityQuery = queryOptions({ queryKey: ['community'], queryFn: () => listCommunity(), staleTime: 30000 });

export const Route = createFileRoute('/channels')({
  head: () => pageMeta('Cooking channels', 'Watch community dish videos and share your own cooking on Bharat Rasoi.'),
  loader: ({ context }) => context.queryClient.ensureQueryData(communityQuery),
  component: ChannelsLayout,
});

function ChannelsLayout() {
  const pathname = useRouterState({ select: state => state.location.pathname });
  return pathname.replace(/\/$/, '') === '/channels' ? <Channels /> : <Outlet />;
}

const IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
const MAX_IMAGE_BYTES = 5 * 1024 * 1024;

function validateChannelImage(file: File, label: string) {
  if (!IMAGE_TYPES.includes(file.type)) throw new Error(`${label} must be a JPG, PNG or WebP image`);
  if (file.size > MAX_IMAGE_BYTES) throw new Error(`${label} must be under 5 MB`);
}

async function uploadChannelImage(userId: string, file: File, kind: 'banner' | 'logo') {
  const extension = file.type === 'image/png' ? 'png' : file.type === 'image/webp' ? 'webp' : 'jpg';
  const path = `${userId}/${kind}-${crypto.randomUUID()}.${extension}`;
  const { error } = await supabase.storage.from('channel-images').upload(path, file, { contentType: file.type });
  if (error) throw error;
  return path;
}

function imageFrom(form: FormData, name: string) {
  const value = form.get(name);
  return value instanceof File && value.size > 0 ? value : null;
}

function Channels() {
  const { data } = useSuspenseQuery(communityQuery);
  const { user } = useAuth();
  const qc = useQueryClient();
  const [creating, setCreating] = useState(false);
  const [editing, setEditing] = useState(false);
  const [busy, setBusy] = useState(false);
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState('');
  const [subscribedOnly, setSubscribedOnly] = useState(false);
  const subscriptions = useChannelSubscriptions();
  const mine = data.channels.find(c => c.owner_id === user?.id);

  useEffect(() => {
    const sub = supabase.channel('community-feed').on('postgres_changes', { event: '*', schema: 'public', table: 'channel_videos' }, () => { void qc.invalidateQueries({ queryKey: ['community'] }); }).subscribe();
    const timer = setInterval(() => { void qc.invalidateQueries({ queryKey: ['community'] }); }, 60000);
    return () => { void supabase.removeChannel(sub); clearInterval(timer); };
  }, [qc]);

  async function create(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!user) return;
    const form = new FormData(e.currentTarget);
    setBusy(true);
    try {
      const banner = imageFrom(form, 'banner');
      const logo = imageFrom(form, 'logo');
      if (banner) validateChannelImage(banner, 'Banner');
      if (logo) validateChannelImage(logo, 'Logo');
      const { data: inserted, error } = await supabase.from('channels').insert({ owner_id: user.id, name: String(form.get('name')).trim(), handle: String(form.get('handle')).trim().toLowerCase(), description: String(form.get('description')).trim() }).select('id').single();
      if (error) throw error;
      const paths: { banner_path?: string; avatar_path?: string } = {};
      if (banner) paths.banner_path = await uploadChannelImage(user.id, banner, 'banner');
      if (logo) paths.avatar_path = await uploadChannelImage(user.id, logo, 'logo');
      if (paths.banner_path || paths.avatar_path) {
        const { error: updateError } = await supabase.from('channels').update(paths).eq('id', inserted.id);
        if (updateError) throw updateError;
      }
      await qc.invalidateQueries({ queryKey: ['community'] });
      setCreating(false);
      toast.success('Channel created');
    } catch (e) { toast.error(e instanceof Error ? e.message : 'Could not create channel'); } finally { setBusy(false); }
  }

  async function saveEdit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!user || !mine) return;
    const form = new FormData(e.currentTarget);
    setBusy(true);
    try {
      const banner = imageFrom(form, 'banner');
      const logo = imageFrom(form, 'logo');
      if (banner) validateChannelImage(banner, 'Banner');
      if (logo) validateChannelImage(logo, 'Logo');
      const update: { name: string; description: string; banner_path?: string; avatar_path?: string } = {
        name: String(form.get('name')).trim(),
        description: String(form.get('description')).trim(),
      };
      if (banner) update.banner_path = await uploadChannelImage(user.id, banner, 'banner');
      if (logo) update.avatar_path = await uploadChannelImage(user.id, logo, 'logo');
      const { error } = await supabase.from('channels').update(update).eq('id', mine.id);
      if (error) throw error;
      await qc.invalidateQueries({ queryKey: ['community'] });
      setEditing(false);
      toast.success('Channel updated');
    } catch (e) { toast.error(e instanceof Error ? e.message : 'Could not update channel'); } finally { setBusy(false); }
  }

  async function upload(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!user || !mine) return;
    const element = e.currentTarget;
    const form = new FormData(element);
    const file = form.get('video');
    if (!(file instanceof File)) return;
    setBusy(true);
    let path: string | null = null;
    try {
      validateChannelVideo(file);
      const extension = file.type === 'video/quicktime' ? 'mov' : file.type === 'video/webm' ? 'webm' : 'mp4';
      path = `${user.id}/${crypto.randomUUID()}.${extension}`;
      const result = await supabase.storage.from('channel-videos').upload(path, file, { contentType: file.type });
      if (result.error) throw result.error;
      const { error } = await supabase.from('channel_videos').insert({ channel_id: mine.id, owner_id: user.id, title: String(form.get('title')).trim(), description: String(form.get('description')).trim(), state: String(form.get('state')).trim() || 'Other', video_path: path });
      if (error) { await supabase.storage.from('channel-videos').remove([path]); throw error; }
      element.reset();
      await qc.invalidateQueries({ queryKey: ['community'] });
      toast.success('Video published for everyone');
    } catch (e) { toast.error(e instanceof Error ? e.message : 'Upload failed; please try again'); } finally { setBusy(false); }
  }

  const input = 'mt-2 min-h-11 w-full min-w-0 rounded-md border border-input bg-background px-3 py-2 text-base';
  const fileInput = 'mt-2 block w-full min-w-0 text-sm file:mr-2 file:rounded-md file:border-0 file:bg-secondary file:px-3 file:py-2 file:text-secondary-foreground';
  const q = query.trim().toLowerCase();
  const channelOf = (id: string) => data.channels.find(c => c.id === id);
  const filteredChannels = data.channels.filter(c => (!subscribedOnly || subscriptions.ids.includes(c.id)) && (!q || `${c.name} ${c.handle} ${c.description}`.toLowerCase().includes(q)));
  const filteredVideos = data.videos.filter(v => (!subscribedOnly || subscriptions.ids.includes(v.channel_id)) && (!selected || v.channel_id === selected) && `${v.title} ${v.state} ${channelOf(v.channel_id)?.name ?? ''} ${channelOf(v.channel_id)?.handle ?? ''}`.toLowerCase().includes(q));

  return (
    <div className="space-y-8">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm text-primary">From our kitchens</p>
          <h1 className="mt-2 font-display text-4xl">Cooking channels</h1>
        </div>
        {!user ? (
          <Button asChild variant="outline"><Link to="/auth">Sign in to create channel</Link></Button>
        ) : !mine ? (
          <Button onClick={() => setCreating(!creating)}><Plus /> Create channel</Button>
        ) : (
          <div className="flex flex-wrap items-center gap-2">
            <Button asChild variant="outline"><Link to="/channels/$handle" params={{ handle: mine.handle }}><Video /> @{mine.handle}</Link></Button>
            <Button variant="ghost" size="sm" onClick={() => setEditing(!editing)}>{editing ? <X /> : <Pencil />} {editing ? 'Cancel' : 'Edit channel'}</Button>
          </div>
        )}
      </header>

      {creating && user && !mine && (
        <form onSubmit={create} className="grid max-w-xl gap-4 border-y border-border py-6">
          <h2 className="font-display text-2xl">Your channel</h2>
          <label>Channel name<input className={input} name="name" minLength={2} maxLength={60} required /></label>
          <label>Handle<input className={input} name="handle" pattern="[a-z0-9_]{3,30}" minLength={3} maxLength={30} required placeholder="your_kitchen" /></label>
          <label>Description<textarea className={input} name="description" maxLength={500} /></label>
          <label className="flex items-center gap-2 text-sm"><ImagePlus className="h-4 w-4 text-primary" /> Channel logo (JPG, PNG, WebP · up to 5 MB)<input name="logo" type="file" accept="image/jpeg,image/png,image/webp" className={fileInput} /></label>
          <label className="flex items-center gap-2 text-sm"><ImagePlus className="h-4 w-4 text-primary" /> Channel banner (optional)<input name="banner" type="file" accept="image/jpeg,image/png,image/webp" className={fileInput} /></label>
          <Button disabled={busy} type="submit">{busy ? 'Creating…' : 'Create channel'}</Button>
        </form>
      )}

      {editing && mine && (
        <form onSubmit={saveEdit} className="grid max-w-xl gap-4 border-y border-border py-6">
          <h2 className="font-display text-2xl">Edit channel</h2>
          <label>Channel name<input className={input} name="name" minLength={2} maxLength={60} required defaultValue={mine.name} /></label>
          <label>Description<textarea className={input} name="description" maxLength={500} defaultValue={mine.description} /></label>
          <label className="flex items-center gap-2 text-sm"><ImagePlus className="h-4 w-4 text-primary" /> New logo (leave empty to keep current)<input name="logo" type="file" accept="image/jpeg,image/png,image/webp" className={fileInput} /></label>
          <label className="flex items-center gap-2 text-sm"><ImagePlus className="h-4 w-4 text-primary" /> New banner (leave empty to keep current)<input name="banner" type="file" accept="image/jpeg,image/png,image/webp" className={fileInput} /></label>
          <Button disabled={busy} type="submit">{busy ? 'Saving…' : 'Save changes'}</Button>
        </form>
      )}

      {mine && (
        <form onSubmit={upload} className="grid gap-4 border-y border-border py-6 sm:grid-cols-2">
          <h2 className="font-display text-2xl sm:col-span-2">Publish a dish video</h2>
          <label>Dish title<input name="title" className={input} minLength={2} maxLength={100} required /></label>
          <label>State<input name="state" className={input} maxLength={60} placeholder="Other" /></label>
          <label className="sm:col-span-2">Description<textarea name="description" className={input} maxLength={1000} /></label>
          <label className="min-w-0">Video (MP4, MOV, WebM · up to 50 MB)<input name="video" type="file" accept="video/mp4,video/quicktime,video/webm" required className={fileInput} /></label>
          <label className="flex items-center gap-2 text-sm"><input required type="checkbox" />I own this video or have permission to publish it.</label>
          <Button type="submit" disabled={busy} className="w-fit"><Upload />{busy ? 'Uploading…' : 'Publish video'}</Button>
        </form>
      )}

      <div className="grid gap-3 sm:grid-cols-2">
        <input aria-label="Search videos and channels" value={query} onChange={e => setQuery(e.target.value)} placeholder="Search channels or dishes…" className={input} />
        <select aria-label="Filter channel" value={selected} onChange={e => setSelected(e.target.value)} className={input}>
          <option value="">All channels</option>
          {data.channels.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </div>
      {user && <div className="flex flex-wrap gap-2" aria-label="Channel views">
        <Button variant={subscribedOnly ? 'outline' : 'default'} onClick={() => setSubscribedOnly(false)}>All channels</Button>
        <Button variant={subscribedOnly ? 'default' : 'outline'} onClick={() => setSubscribedOnly(true)}>Subscribed channels</Button>
      </div>}
      {subscribedOnly && subscriptions.error && <p role="alert" className="text-destructive">Could not load your subscriptions.</p>}
      {subscribedOnly && !subscriptions.loading && !subscriptions.error && !filteredChannels.length && <p className="text-muted-foreground">No subscribed channels found.</p>}

      {!data.channels.length && <p className="py-8 text-center text-muted-foreground">The first kitchen is waiting.</p>}

      {filteredChannels.length > 0 && (
        <section>
          <h2 className="font-display text-2xl">Channels</h2>
          <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {filteredChannels.map(c => (
              <article key={c.id} className="group min-w-0 overflow-hidden rounded-lg border border-border bg-card transition hover:shadow-[var(--shadow-card)]">
                <Link to="/channels/$handle" params={{ handle: c.handle }}>
                <div className="relative h-20 bg-muted">
                  {c.bannerUrl ? <img src={c.bannerUrl} alt="" className="h-full w-full object-cover" loading="lazy" /> : <div className="h-full w-full bg-[var(--gradient-gold)] opacity-20" />}
                  <div className="absolute -bottom-5 left-4 h-12 w-12 overflow-hidden rounded-full border-2 border-card bg-muted">
                    {c.avatarUrl ? <img src={c.avatarUrl} alt="" className="h-full w-full object-cover" loading="lazy" /> : <Video className="m-3 h-6 w-6 text-muted-foreground" aria-hidden="true" />}
                  </div>
                </div>
                <div className="space-y-1 px-4 pb-4 pt-7">
                  <h3 className="truncate break-words font-display text-xl">{c.name}</h3>
                  <p className="truncate text-sm text-primary">@{c.handle}</p>
                  {c.monetized && <span className="flex items-center gap-1 text-xs text-primary"><CheckCircle className="h-3 w-3" /> Monetization eligible</span>}
                  <p className="line-clamp-2 break-words text-sm text-muted-foreground">{c.description}</p>
                </div>
                </Link>
                <div className="px-4 pb-4"><ChannelSubscribe channelId={c.id} ownerId={c.owner_id} count={c.subscriberCount} /></div>
              </article>
            ))}
          </div>
        </section>
      )}

      <section>
        <h2 className="font-display text-2xl">Latest dish videos</h2>
        <div className="mt-4 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {filteredVideos.map(v => {
            const c = channelOf(v.channel_id);
            return (
              <article key={v.id} className="min-w-0 overflow-hidden rounded-lg border border-border bg-card">
                <div className="aspect-video bg-muted">
                  {v.url ? <video className="h-full w-full object-contain" controls playsInline preload="metadata" src={v.url} /> : <p className="p-4 text-sm text-muted-foreground">Video unavailable</p>}
                </div>
                <div className="space-y-2 p-4">
                  <h2 className="break-words font-display text-2xl">{v.title}</h2>
                  {c && (
                    <Button asChild variant="link" className="h-auto max-w-full whitespace-normal p-0">
                      <Link to="/channels/$handle" params={{ handle: c.handle }}>{c.name} · @{c.handle}</Link>
                    </Button>
                  )}
                  {c?.monetized && <span className="flex items-center gap-1 text-xs text-primary"><CheckCircle className="h-3 w-3" /> Monetization eligible</span>}
                  <p className="text-xs text-muted-foreground">{v.state}</p>
                  <p className="break-words text-sm text-muted-foreground">{v.description}</p>
                  {v.owner_id === user?.id && (
                    <Button variant="ghost" size="sm" onClick={async () => {
                      if (!confirm('Delete this video?')) return;
                      const { error } = await supabase.from('channel_videos').delete().eq('id', v.id);
                      if (error) return toast.error('Could not delete video');
                      await supabase.storage.from('channel-videos').remove([v.video_path]);
                      await qc.invalidateQueries({ queryKey: ['community'] });
                    }}><Trash2 /> Delete</Button>
                  )}
                </div>
              </article>
            );
          })}
        </div>
        {data.channels.length > 0 && filteredVideos.length === 0 && <p className="py-8 text-center text-muted-foreground">No dish videos found.</p>}
      </section>
    </div>
  );
}
