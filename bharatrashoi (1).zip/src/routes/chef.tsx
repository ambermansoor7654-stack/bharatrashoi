import { createFileRoute } from "@tanstack/react-router";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport, type UIMessage } from "ai";
import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowUp, ChefHat, Globe2, Square, Trash2, Zap } from "lucide-react";
import { toast } from "sonner";

import { supabase } from "@/integrations/supabase/client";
import { getSessionToken } from "@/lib/session";
import { FoodCard } from "@/components/FoodCard";
import type { FoodCard as FoodCardType } from "@/lib/food-schema";
import { usePremium } from "@/lib/use-premium";
import { AdSlot } from "@/components/AdSlot";

export const Route = createFileRoute("/chef")({
  head: () => ({
    meta: [
      { title: "Rasoi AI Chef — Bharat Rasoi" },
      { name: "description", content: "Chat with an AI chef about any Indian dish — nutrition, history, ingredients and more." },
      { property: "og:title", content: "Rasoi AI Chef — Bharat Rasoi" },
      { property: "og:description", content: "Cooking inspiration without an app-level daily quota." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ChefPage,
});

type Lang = "en" | "hi";

const SUGGESTIONS_EN = [
  "Tell me about Biryani",
  "Is Butter Chicken healthy?",
  "Ingredients of Samosa",
  "Foods for weight loss",
];
const SUGGESTIONS_HI = [
  "Biryani ke baare mein batao",
  "Butter Chicken healthy hai?",
  "Samose mein kya hota hai",
  "Weight loss ke liye khana",
];

function ChefPage() {
  const [lang, setLang] = useState<Lang>("en");
  const [input, setInput] = useState("");
  const sessionToken = useMemo(() => getSessionToken(), []);
  const [initialMessages, setInitialMessages] = useState<UIMessage[] | null>(null);
  const premium = usePremium();
  const [authToken, setAuthToken] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    supabase
      .from("chat_messages")
      .select("*")
      .eq("session_token", sessionToken)
      .order("created_at")
      .then(({ data }) => {
        const msgs: UIMessage[] = (data ?? []).map(row => ({
          id: row.id,
          role: row.role as UIMessage["role"],
          parts: row.parts as UIMessage["parts"],
        }));
        setInitialMessages(msgs);
      });
  }, [sessionToken]);


  // Bearer token lets the server verify Premium for priority responses.
  useEffect(() => {
    let active = true;
    supabase.auth.getSession().then(({ data }) => {
      if (active) setAuthToken(data.session?.access_token ?? null);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      setAuthToken(session?.access_token ?? null);
    });
    return () => { active = false; sub.subscription.unsubscribe(); };
  }, []);

  const transport = useMemo(
    () =>
      new DefaultChatTransport({
        api: "/api/chat",
        headers: authToken ? { Authorization: `Bearer ${authToken}` } : undefined,
      }),
    [authToken],
  );

  const { messages, sendMessage, status, stop, setMessages } = useChat({
    id: sessionToken,
    messages: initialMessages ?? [],
    transport,
    onError: (err) => toast.error(err.message || "AI request failed"),
    onFinish: async ({ message }) => {
      await supabase.from("chat_messages").insert({
        session_token: sessionToken,
        role: "assistant",
        parts: message.parts as never,
      });
    },
  });

  useEffect(() => {
    if (initialMessages && messages.length === 0 && initialMessages.length > 0) {
      setMessages(initialMessages);
    }
  }, [initialMessages, messages.length, setMessages]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, status]);

  useEffect(() => { inputRef.current?.focus(); }, [status]);

  // Auto-grow textarea
  useEffect(() => {
    const el = inputRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = Math.min(el.scrollHeight, 200) + "px";
  }, [input]);

  const send = async (text: string) => {
    const trimmed = text.trim();
    if (!trimmed || status === "streaming" || status === "submitted") return;
    setInput("");
    // Fire-and-forget persistence so streaming starts on the FIRST paint.
    void supabase.from("chat_messages").insert({
      session_token: sessionToken,
      role: "user",
      parts: [{ type: "text", text: trimmed }] as never,
    });
    void sendMessage({ text: trimmed });
  };

  const clear = async () => {
    await supabase.from("chat_messages").delete().eq("session_token", sessionToken);
    setMessages([]);
    toast("Chat cleared");
  };

  const suggestions = lang === "hi" ? SUGGESTIONS_HI : SUGGESTIONS_EN;
  const isLoading = status === "submitted" || status === "streaming";
  const empty = messages.length === 0;

  return (
    <div className="mx-auto flex h-[calc(100dvh-10.5rem-env(safe-area-inset-top)-env(safe-area-inset-bottom))] min-h-[520px] max-w-3xl flex-col md:h-[calc(100dvh-9rem)]">
      {/* Top bar */}
      <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2 border-b border-[color-mix(in_oklab,var(--gold)_16%,transparent)] pb-3">
        <div className="flex min-w-0 items-center gap-2">
          <div className="grid h-8 w-8 place-items-center rounded-full gradient-gold text-[oklch(0.24_0.05_46)]">
            <ChefHat className="h-4 w-4" />
          </div>
          <h1 className="truncate font-display text-xl leading-none">Rasoi</h1>
          <span className="eyebrow hidden rounded-full border border-[color-mix(in_oklab,var(--gold)_20%,transparent)] px-2 py-0.5 min-[390px]:inline-flex">AI Chef</span>
          {premium.isPremium && <span className="inline-flex items-center gap-1 text-xs text-primary"><Zap className="h-3 w-3" /> Priority</span>}
        </div>
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setLang(lang === "en" ? "hi" : "en")}
            className="inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium text-muted-foreground transition hover:bg-[color-mix(in_oklab,var(--gold)_10%,transparent)] hover:text-foreground"
          >
            <Globe2 className="h-3.5 w-3.5" /> {lang === "en" ? "EN" : "हिं"}
          </button>
          {messages.length > 0 && (
            <button
              onClick={clear}
              className="grid h-7 w-7 place-items-center rounded-full text-muted-foreground transition hover:bg-[color-mix(in_oklab,var(--spice)_10%,transparent)] hover:text-[var(--spice)]"
              aria-label="Clear chat"
            >
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Transcript */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto py-6">
        {empty ? (
          <EmptyState lang={lang} suggestions={suggestions} onPick={send} />
        ) : (
          <div className="space-y-6">
            <AnimatePresence initial={false}>
              {messages.map(m => <MessageRow key={m.id} message={m} />)}
            </AnimatePresence>
            {isLoading && <Thinking lang={lang} />}
          </div>
        )}
      </div>

      {/* Composer */}
      <div className="pb-[max(0.5rem,env(safe-area-inset-bottom))] pt-2">
        <AdSlot className="mb-3" label="Sponsored" />
        <form
          onSubmit={e => { e.preventDefault(); void send(input); }}
          className="relative flex items-end gap-1 rounded-[1.75rem] border border-[color-mix(in_oklab,var(--gold)_18%,transparent)] bg-card/90 shadow-[var(--shadow-soft)] backdrop-blur-xl transition focus-within:border-[color-mix(in_oklab,var(--gold)_45%,transparent)] focus-within:shadow-[var(--shadow-glow)]"
        >
          <textarea
            ref={inputRef}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                void send(input);
              }
            }}
            rows={1}
            placeholder={lang === "hi" ? "Message Rasoi…" : "Message Rasoi…"}
            className="min-h-[52px] max-h-[200px] flex-1 resize-none bg-transparent px-5 py-4 text-base outline-none placeholder:text-muted-foreground"
          />
          <div className="shrink-0 p-2">
            {isLoading ? (
              <button
                type="button"
                onClick={() => stop()}
                className="grid h-10 w-10 shrink-0 place-items-center rounded-full btn-ink transition"
                aria-label="Stop"
              >
                <Square className="h-3.5 w-3.5 fill-current" />
              </button>
            ) : (
              <button
                type="submit"
                disabled={!input.trim()}
                className="grid h-10 w-10 shrink-0 place-items-center rounded-full gradient-gold text-[oklch(0.24_0.05_46)] shadow-[var(--shadow-glow)] transition disabled:cursor-not-allowed disabled:bg-none disabled:bg-muted disabled:text-muted-foreground disabled:shadow-none"
                aria-label="Send"
              >
                <ArrowUp className="h-4 w-4" />
              </button>
            )}
          </div>
        </form>
        <p className="mt-2 text-center text-[11px] text-muted-foreground">
          {lang === "hi" ? "AI galat ho sakta hai. Zaruri baatein verify karein." : "AI can make mistakes. Verify important details."}
        </p>
      </div>
    </div>
  );
}

function EmptyState({ lang, suggestions, onPick }: { lang: Lang; suggestions: string[]; onPick: (s: string) => void }) {
  return (
    <div className="flex h-full min-h-[50vh] flex-col items-center justify-center gap-8 text-center">
      <div className="grid h-14 w-14 place-items-center rounded-2xl gradient-gold shadow-[var(--shadow-glow)] text-[oklch(0.24_0.05_46)]">
        <ChefHat className="h-7 w-7" />
      </div>
      <div>
        <p className="eyebrow mb-2">Bharat Rasoi</p>
        <h2 className="font-display text-4xl leading-tight sm:text-5xl">
          {lang === "hi" ? "Kya banana hai aaj?" : "What's cooking today?"}
        </h2>
      </div>
      <div className="grid w-full max-w-xl grid-cols-1 gap-2.5 sm:grid-cols-2">
        {suggestions.map(s => (
          <button
            key={s}
            onClick={() => onPick(s)}
            className="card-lift rounded-2xl border border-[color-mix(in_oklab,var(--gold)_16%,transparent)] bg-card/70 px-4 py-3.5 text-left text-sm text-foreground/85 shadow-[var(--shadow-soft)] backdrop-blur transition hover:border-[color-mix(in_oklab,var(--gold)_38%,transparent)] hover:bg-card"
          >
            {s}
          </button>
        ))}
      </div>
    </div>
  );
}

function MessageRow({ message }: { message: UIMessage }) {
  const isUser = message.role === "user";
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.32, ease: "easeOut" }}
      className={`flex ${isUser ? "justify-end" : "justify-start"}`}
    >
      <div className={`flex min-w-0 flex-col gap-2 ${isUser ? "items-end" : "w-full items-start"}`}>
        {message.parts.map((part, i) => {
          if (part.type === "text") {
            if (!part.text) return null;
            if (isUser) {
              return (
                <div key={i} className="max-w-[85%] rounded-3xl rounded-br-lg bg-[var(--ink)] px-4 py-2.5 text-[15px] leading-relaxed text-[var(--cream)] shadow-[var(--shadow-soft)]">
                  <Markdown text={part.text} />
                </div>
              );
            }
            return (
              <div key={i} className="max-w-full text-[15px] leading-relaxed text-foreground">
                <Markdown text={part.text} />
              </div>
            );
          }
          if (part.type === "tool-render_food_card") {
            const state = (part as { state?: string }).state;
            const output = (part as { output?: FoodCardType; input?: FoodCardType }).output
              ?? (part as { input?: FoodCardType }).input;
            if (state === "input-streaming" || !output) {
              return <ToolPending key={i} name={(output as Partial<FoodCardType> | undefined)?.food_name} />;
            }
            return (
              <div key={i} className="w-full max-w-xl">
                <FoodCard food={output} />
              </div>
            );
          }
          return null;
        })}
      </div>
    </motion.div>
  );
}

function ToolPending({ name }: { name?: string }) {
  return (
    <div className="inline-flex items-center gap-2 rounded-full border border-[color-mix(in_oklab,var(--gold)_18%,transparent)] bg-card/60 px-3.5 py-1.5 text-xs text-muted-foreground backdrop-blur">
      <div className="h-1.5 w-1.5 animate-pulse rounded-full bg-[var(--saffron)]" />
      Preparing card{name ? ` for ${name}` : ""}…
    </div>
  );
}

function Thinking({ lang }: { lang: Lang }) {
  return (
    <div className="flex items-center gap-1.5 text-sm">
      <span className="loading-shimmer bg-clip-text font-display text-base text-transparent" style={{ WebkitTextFillColor: "transparent" }}>
        {lang === "hi" ? "Soch raha hoon…" : "Thinking…"}
      </span>
    </div>
  );
}

function Markdown({ text }: { text: string }) {
  const lines = text.split("\n");
  return (
    <div className="space-y-2">
      {lines.map((line, i) => {
        const bullet = /^\s*[-*]\s+(.*)/.exec(line);
        if (bullet) {
          return (
            <div key={i} className="flex gap-2">
              <span className="opacity-60">•</span>
              <span dangerouslySetInnerHTML={{ __html: formatInline(bullet[1]) }} />
            </div>
          );
        }
        if (!line.trim()) return <div key={i} className="h-1" />;
        return <p key={i} dangerouslySetInnerHTML={{ __html: formatInline(line) }} />;
      })}
    </div>
  );
}

function formatInline(s: string) {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/\*(.+?)\*/g, "<em>$1</em>")
    .replace(/`([^`]+)`/g, '<code class="rounded bg-muted px-1">$1</code>');
}
