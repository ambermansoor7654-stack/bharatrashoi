import { useEffect, useState } from "react";
import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { Mail, Lock, Loader2, Phone, Timer, ShieldCheck } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { BharatLogo } from "@/components/BharatLogo";
import { isAmberAdminEmail } from "@/lib/auth";
import { requestPhoneOtp, verifyPhoneOtp } from "@/lib/phone-otp.functions";
import heroThali from "@/assets/hero-thali.jpg";
import { EmailOtp } from '@/components/EmailOtp';
import { Button } from '@/components/ui/button';
import { pageMeta } from '@/lib/page-meta';
import { Auth3DScene } from '@/components/Auth3DScene';

export const Route = createFileRoute("/auth")({
  head: () => pageMeta('Sign in', 'Sign in to Bharat Rasoi with Google, email or phone to save recipes and share cooking videos.'),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const requestOtp = useServerFn(requestPhoneOtp);
  const verifyOtp = useServerFn(verifyPhoneOtp);

  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [authTab, setAuthTab] = useState<"email" | "phone">("email");
  const [emailMethod, setEmailMethod] = useState<'password' | 'otp'>('password');
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [resendIn, setResendIn] = useState(0); // seconds until user can request another OTP
  const [rateLimitedUntil, setRateLimitedUntil] = useState(0); // ms epoch when 10-min window resets

  // Tick down the resend cooldown once per second
  useEffect(() => {
    if (resendIn <= 0) return;
    const t = setInterval(() => setResendIn((s) => (s > 0 ? s - 1 : 0)), 1000);
    return () => clearInterval(t);
  }, [resendIn]);

  const rateLimitLeftSec = Math.max(0, Math.ceil((rateLimitedUntil - Date.now()) / 1000));

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === "signup") {
        const { error, data } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: `${window.location.origin}/` },
        });
        if (error) throw error;
        if (!data.session) {
          toast.success('Check your email to confirm your account before signing in.');
          return;
        }
        toast.success(
          isAmberAdminEmail(email) ? "Welcome Amber 👑" : "Account created — you're signed in.",
        );
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        toast.success(isAmberAdminEmail(email) ? "Welcome Amber 👑" : "Welcome back!");
      }
      navigate({ to: "/" });
    } catch (err: any) {
      toast.error(err.message ?? "Something went wrong");
    } finally {
      setBusy(false);
    }
  }

  async function sendPhoneOtpHandler() {
    const trimmed = phone.trim();
    if (!trimmed) return toast.error("Phone number add karo, country code ke saath (e.g. +91...)");
    if (!/^\+\d{8,15}$/.test(trimmed.replace(/[\s\-()]/g, ""))) {
      return toast.error("Country code laga ke number do, e.g. +9198XXXXXXXX");
    }
    if (resendIn > 0) {
      return toast.error(`Thodi der ruko — ${resendIn}s baad resend kar sakte ho`);
    }
    setBusy(true);
    try {
      await requestOtp({ data: { phone: trimmed } });
      setOtpSent(true);
      setResendIn(60); // 1 min cooldown before user can request another
      toast.success("OTP bhej diya — apne SMS mai check karo (5 min mai expire)");
    } catch (err: any) {
      const msg = err?.message ?? "OTP bhejne mai dikkat";
      // Server ka rate-limit ("Bahut jaldi jaldi requests — 10 min baad try karo") pakdo
      if (/10 min|jaldi jaldi/i.test(msg)) {
        setRateLimitedUntil(Date.now() + 10 * 60_000);
        setResendIn(10 * 60);
      }
      toast.error(msg);
    } finally {
      setBusy(false);
    }
  }

  async function verifyPhoneOtpHandler() {
    if (!otp.trim()) return toast.error("OTP code enter karo");
    setBusy(true);
    try {
      const { email: surrogateEmail, password: ephemeral } = await verifyOtp({
        data: { phone: phone.trim(), code: otp.trim() },
      });
      const { error } = await supabase.auth.signInWithPassword({
        email: surrogateEmail,
        password: ephemeral,
      });
      if (error) throw error;
      toast.success("Phone se login ho gaya 🎉");
      navigate({ to: "/" });
    } catch (err: any) {
      toast.error(err.message ?? "OTP verify failed");
    } finally {
      setBusy(false);
    }
  }


  return (
    <Auth3DScene>
        {/* Left: cinematic visual panel — desktop only */}
        <div className="relative hidden min-h-[620px] overflow-hidden lg:block">
          <img
            src={heroThali}
            alt=""
            aria-hidden="true"
            className="absolute inset-0 h-full w-full object-cover"
          />
          <div className="scrim absolute inset-0" />
          <div className="absolute inset-0 bg-[linear-gradient(160deg,oklch(0.22_0.035_42/0.55),transparent_55%)]" />
          <div className="relative z-10 flex h-full flex-col justify-between p-10 text-[oklch(0.98_0.01_88)]">
            <div className="flex items-center gap-3">
              <BharatLogo className="h-12 w-12" />
              <div>
                <div className="font-display text-2xl leading-none">Bharat Rasoi</div>
                <div className="mt-1 eyebrow text-[oklch(0.94_0.03_86)]">Taste of India</div>
              </div>
            </div>
            <div>
              <h2 className="font-display text-4xl leading-[1.05] xl:text-5xl">
                A thousand kitchens,
                <br /> one login away.
              </h2>
              <p className="mt-4 max-w-sm text-sm text-[oklch(0.94_0.02_86)]/85">
                Save your favourite recipes, chat with the AI Chef, and pick up right where you left off — every time you sign in.
              </p>
              <div className="mt-6 inline-flex items-center gap-2 rounded-full bg-[oklch(0.14_0.02_38/0.45)] px-4 py-2 text-xs font-medium backdrop-blur">
                <ShieldCheck className="h-4 w-4 text-[var(--saffron)]" /> Secure sign-in, no spam, ever.
              </div>
            </div>
          </div>
        </div>

        {/* Right: form panel */}
        <div className="panel flex items-center justify-center rounded-none border-0 p-6 sm:p-10">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            className="w-full max-w-sm"
          >
            <div className="mb-6 flex items-center gap-3 lg:hidden">
              <BharatLogo className="h-12 w-12" />
              <div>
                <div className="font-display text-lg leading-none">Bharat Rasoi</div>
                <div className="mt-0.5 eyebrow">Taste of India</div>
              </div>
            </div>

            <h1 className="font-display text-3xl">
              {mode === "signin" ? "Welcome back" : "Join Bharat Rasoi"}
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">
              {mode === "signin" ? "Sign in to your kitchen" : "Create your account in seconds"}
            </p>

            {/* Tabs */}
            <div role="tablist" aria-label="Login method" className="mt-6 grid grid-cols-2 gap-1 rounded-full border border-[color-mix(in_oklab,var(--gold)_18%,transparent)] bg-[color-mix(in_oklab,var(--muted)_45%,transparent)] p-1">
              <button
                type="button"
                role="tab"
                aria-selected={authTab === "email"}
                onClick={() => setAuthTab("email")}
                className={`rounded-full px-3 py-2 text-xs font-semibold transition ${
                  authTab === "email" ? "bg-card text-foreground shadow-[var(--shadow-soft)]" : "text-muted-foreground"
                }`}
              >
                Email
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={authTab === "phone"}
                onClick={() => setAuthTab("phone")}
                className={`rounded-full px-3 py-2 text-xs font-semibold transition ${
                  authTab === "phone" ? "bg-card text-foreground shadow-[var(--shadow-soft)]" : "text-muted-foreground"
                }`}
              >
                Phone OTP
              </button>
            </div>

            {authTab === "email" && (
              <>
                <div className="mt-4 flex gap-2" role="group" aria-label="Email login type">
                  <Button aria-pressed={emailMethod === 'password'} type="button" size="sm" variant={emailMethod === 'password' ? 'default' : 'outline'} onClick={() => setEmailMethod('password')}>Password</Button>
                  <Button aria-pressed={emailMethod === 'otp'} type="button" size="sm" variant={emailMethod === 'otp' ? 'default' : 'outline'} onClick={() => setEmailMethod('otp')}>Email OTP</Button>
                </div>
                {emailMethod === 'otp' ? <EmailOtp /> : (
                <form onSubmit={onSubmit} className="mt-5 space-y-3.5">
                  <label className="block">
                    <span className="mb-1.5 block text-xs font-medium text-muted-foreground">Email</span>
                    <div className="relative">
                      <Mail aria-hidden className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <input
                        required
                        type="email"
                        autoComplete="email"
                        value={email}
                        onChange={e => setEmail(e.target.value)}
                        className="w-full rounded-2xl border border-[color-mix(in_oklab,var(--gold)_18%,transparent)] bg-card/70 py-3 pl-10 pr-3.5 text-sm outline-none transition focus:border-[var(--gold)] focus:shadow-[0_0_0_4px_color-mix(in_oklab,var(--gold)_18%,transparent)]"
                        placeholder="you@kitchen.com"
                      />
                    </div>
                  </label>

                  <label className="block">
                    <span className="mb-1.5 block text-xs font-medium text-muted-foreground">Password</span>
                    <div className="relative">
                      <Lock aria-hidden className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <input
                        required
                        minLength={6}
                        type="password"
                        autoComplete={mode === "signin" ? "current-password" : "new-password"}
                        value={password}
                        onChange={e => setPassword(e.target.value)}
                        className="w-full rounded-2xl border border-[color-mix(in_oklab,var(--gold)_18%,transparent)] bg-card/70 py-3 pl-10 pr-3.5 text-sm outline-none transition focus:border-[var(--gold)] focus:shadow-[0_0_0_4px_color-mix(in_oklab,var(--gold)_18%,transparent)]"
                        placeholder="••••••••"
                      />
                    </div>
                  </label>

                  <button
                    type="submit"
                    disabled={busy}
                    aria-busy={busy}
                    className="btn-gold mt-1 flex w-full items-center justify-center gap-2 rounded-2xl px-4 py-3 text-sm font-semibold disabled:opacity-60"
                  >
                    {busy && <Loader2 aria-hidden className="h-4 w-4 animate-spin" />}
                    {mode === "signin" ? "Sign in" : "Create account"}
                  </button>
                </form>
                )}

                <div className="my-5 flex items-center gap-3 text-[10px] uppercase tracking-widest text-muted-foreground">
                  <div className="hairline h-px flex-1" /> or <div className="hairline h-px flex-1" />
                </div>

                <button
                  onClick={async () => {
                    setBusy(true);
                    try {
                      const result = await lovable.auth.signInWithOAuth("google", {
                        redirect_uri: window.location.origin,
                      });
                      if (result.error) throw result.error;
                      if (result.redirected) return;
                      const { data } = await supabase.auth.getUser();
                      if (!data.user) throw new Error('Google sign-in did not complete. Please try again.');
                      const em = data.user?.email?.toLowerCase();
                      toast.success(isAmberAdminEmail(em) ? "Welcome Amber 👑" : "Signed in with Google");
                      navigate({ to: "/" });
                    } catch (err: any) {
                      toast.error(err.message ?? "Google sign-in failed");
                    } finally {
                      setBusy(false);
                    }
                  }}
                  disabled={busy}
                  type="button"
                  aria-busy={busy}
                  className="btn-quiet flex w-full items-center justify-center gap-3 rounded-2xl px-4 py-3 text-sm font-semibold disabled:opacity-60"
                >
                  <svg className="h-5 w-5" viewBox="0 0 48 48" aria-hidden>
                    <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.4 29.3 35.5 24 35.5c-6.4 0-11.5-5.1-11.5-11.5S17.6 12.5 24 12.5c2.9 0 5.6 1.1 7.6 2.9l5.7-5.7C33.6 6.3 29 4.5 24 4.5 13.2 4.5 4.5 13.2 4.5 24S13.2 43.5 24 43.5 43.5 34.8 43.5 24c0-1.2-.1-2.4-.4-3.5z"/>
                    <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 16 19 12.5 24 12.5c2.9 0 5.6 1.1 7.6 2.9l5.7-5.7C33.6 6.3 29 4.5 24 4.5 16.3 4.5 9.7 8.8 6.3 14.7z"/>
                    <path fill="#4CAF50" d="M24 43.5c5.2 0 9.9-2 13.4-5.2l-6.2-5.2c-2 1.4-4.5 2.3-7.2 2.3-5.3 0-9.7-3.1-11.3-7.4l-6.5 5C9.6 39.1 16.2 43.5 24 43.5z"/>
                    <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.3-2.3 4.3-4.1 5.6l6.2 5.2c-.4.4 6.6-4.8 6.6-14.8 0-1.2-.1-2.4-.4-3.5z"/>
                  </svg>
                  Continue with Google
                </button>
              </>
            )}

            {authTab === "phone" && (
              <div className="mt-5 rounded-3xl border border-[color-mix(in_oklab,var(--gold)_16%,transparent)] bg-card/55 p-4 shadow-[var(--shadow-soft)]">
                <div className="mb-3 flex items-center gap-2 text-xs font-semibold text-muted-foreground">
                  <Phone aria-hidden className="h-3.5 w-3.5 text-[var(--spice)]" /> Phone login / signup
                </div>
                <div className="flex gap-2">
                  <input
                    type="tel"
                    aria-label="Phone number with country code"
                    autoComplete="tel"
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                    placeholder="+91 phone number"
                    className="min-w-0 flex-1 rounded-2xl border border-[color-mix(in_oklab,var(--gold)_18%,transparent)] bg-background/70 px-3.5 py-3 text-sm outline-none transition focus:border-[var(--gold)] focus:shadow-[0_0_0_4px_color-mix(in_oklab,var(--gold)_18%,transparent)]"
                  />
                  <button
                    type="button"
                    onClick={sendPhoneOtpHandler}
                    disabled={busy || resendIn > 0}
                    aria-label={resendIn > 0 ? `Resend OTP available in ${resendIn} seconds` : otpSent ? "Resend OTP" : "Send OTP"}
                    className="btn-ink shrink-0 rounded-2xl px-4 py-3 text-xs font-semibold disabled:opacity-60"
                  >
                    {resendIn > 0 ? `${resendIn}s` : otpSent ? "Resend" : "Send OTP"}
                  </button>
                </div>

                {/* Countdown / rate-limit banner */}
                {otpSent && !rateLimitLeftSec && resendIn > 0 && (
                  <div role="status" className="mt-3 flex items-center gap-2 rounded-2xl bg-[color-mix(in_oklab,var(--gold)_12%,transparent)] px-3 py-2 text-[11px] text-muted-foreground">
                    <Timer aria-hidden className="h-3.5 w-3.5 text-[var(--gold)]" />
                    Next OTP <span className="font-semibold text-foreground">{resendIn}s</span> mai bhej sakte ho. SMS 5 min mai expire hota hai.
                  </div>
                )}
                {rateLimitLeftSec > 0 && (
                  <div role="alert" className="mt-3 flex items-start gap-2 rounded-2xl bg-[color-mix(in_oklab,var(--spice)_12%,transparent)] px-3 py-2 text-[11px] text-[var(--spice)]">
                    <Timer aria-hidden className="mt-0.5 h-3.5 w-3.5" />
                    <div>
                      <div className="font-semibold">Rate limit hit — 3 OTP / 10 min</div>
                      <div className="opacity-80">
                        Naya OTP {Math.floor(rateLimitLeftSec / 60)}m {rateLimitLeftSec % 60}s baad milega.
                      </div>
                    </div>
                  </div>
                )}

                {otpSent && (
                  <div className="mt-3 flex gap-2">
                    <input
                      value={otp}
                      onChange={e => setOtp(e.target.value)}
                      inputMode="numeric"
                      autoComplete="one-time-code"
                      aria-label="6-digit OTP code"
                      maxLength={6}
                      placeholder="Enter 6-digit OTP"
                      className="min-w-0 flex-1 rounded-2xl border border-[color-mix(in_oklab,var(--gold)_18%,transparent)] bg-background/70 px-3.5 py-3 text-center text-sm tracking-[0.5em] outline-none transition focus:border-[var(--gold)] focus:shadow-[0_0_0_4px_color-mix(in_oklab,var(--gold)_18%,transparent)]"
                    />
                    <button
                      type="button"
                      onClick={verifyPhoneOtpHandler}
                      disabled={busy}
                      className="btn-gold shrink-0 rounded-2xl px-4 py-3 text-xs font-semibold disabled:opacity-60"
                    >
                      Verify
                    </button>
                  </div>
                )}
              </div>
            )}

            <div className="mt-6 text-center text-xs text-muted-foreground">
              {mode === "signin" ? "New here?" : "Already cooking with us?"}{" "}
              <button
                type="button"
                onClick={() => setMode(mode === "signin" ? "signup" : "signin")}
                className="font-semibold text-[color-mix(in_oklab,var(--gold)_75%,var(--foreground))] hover:underline"
              >
                {mode === "signin" ? "Create an account" : "Sign in"}
              </button>
            </div>

            <Link to="/" className="mt-4 block text-center text-xs text-muted-foreground hover:text-foreground">
              ← Back to home
            </Link>
          </motion.div>
        </div>
    </Auth3DScene>
  );
}
