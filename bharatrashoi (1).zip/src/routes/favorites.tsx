import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Heart, ChefHat, WifiOff, CheckCircle2, Sparkles, Search, Trash2, HardDriveDownload } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { RECIPES } from "@/lib/data";
import { useFavorites } from "@/lib/favorites";
import { RecipeCard } from "@/components/RecipeCard";
import { FoodCard } from "@/components/FoodCard";
import type { FoodCard as FoodCardType } from "@/lib/food-schema";
import { supabase } from "@/integrations/supabase/client";
import { getSessionToken } from "@/lib/session";
import { removeOfflineRecipe, useOfflineRecipes, useOnlineStatus } from "@/lib/offline-recipes";
import { AdSlot } from "@/components/AdSlot";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export const Route = createFileRoute("/favorites")({
  head: () => ({
    meta: [
      { title: "Favorites — Bharat Rasoi" },
      { name: "description", content: "Your saved Indian recipes and AI food cards." },
    ],
  }),
  component: FavoritesPage,
});

function formatBytes(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(bytes < 10 * 1024 ? 1 : 0)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(1)} GB`;
}

function FavoritesPage() {
  const { favorites } = useFavorites();
  const savedRecipes = RECIPES.filter(r => favorites.includes(r.id));
  const [savedFoods, setSavedFoods] = useState<FoodCardType[]>([]);
  const { offlineRecipes, storageInfo } = useOfflineRecipes();
  const online = useOnlineStatus();
  const [offlineSearch, setOfflineSearch] = useState("");
  const [offlineCategory, setOfflineCategory] = useState("All");

  const offlineCategories = useMemo(
    () => ["All", ...Array.from(new Set(offlineRecipes.map((recipe) => recipe.category).filter((value): value is string => Boolean(value))))],
    [offlineRecipes],
  );
  const filteredOfflineRecipes = useMemo(() => {
    const query = offlineSearch.trim().toLowerCase();
    return offlineRecipes.filter((recipe) => {
      const matchesCategory = offlineCategory === "All" || recipe.category === offlineCategory;
      const searchable = [recipe.name, recipe.description, recipe.state, recipe.category, ...recipe.ingredients, ...(recipe.tags ?? [])]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();
      return matchesCategory && (!query || searchable.includes(query));
    });
  }, [offlineCategory, offlineRecipes, offlineSearch]);

  useEffect(() => {
    const token = getSessionToken();

    const load = () => {
      supabase
        .from("food_favorites")
        .select("food_data")
        .eq("session_token", token)
        .order("created_at", { ascending: false })
        .then(({ data }) => {
          setSavedFoods((data ?? []).map(r => r.food_data as unknown as FoodCardType));
        });
    };
    load();

    const channel = supabase
      .channel("food_favorites_changes")
      .on("postgres_changes", { event: "*", schema: "public", table: "food_favorites" }, load)
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, []);

  const total = savedRecipes.length + savedFoods.length;

  return (
    <div className="space-y-10">
      <div className="reveal">
        <p className="eyebrow inline-flex items-center gap-1.5">
          <Heart className="h-3.5 w-3.5 text-[var(--spice)]" aria-hidden="true" /> Your collection
        </p>
        {!online && (
          <p className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-amber-500/15 px-3 py-1 text-xs font-semibold text-amber-700">
            <WifiOff className="h-3.5 w-3.5" aria-hidden="true" /> Offline — {offlineRecipes.length} recipe(s) saved for offline cooking
          </p>
        )}
        <h1 className="mt-3 font-display text-4xl leading-tight sm:text-6xl">
          Saved <span className="text-gradient">flavors</span>
        </h1>
        <p className="mt-2 max-w-xl text-sm text-muted-foreground">
          Every dish you've fallen for, gathered in one warm little book.
        </p>
      </div>

      <AdSlot />

      {offlineRecipes.length > 0 && (
        <section className="reveal space-y-4">
          <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3">
            <div className="min-w-0">
              <h2 className="flex items-center gap-2 font-display text-2xl">
                <CheckCircle2 className="h-5 w-5 shrink-0 text-[var(--india-green)]" aria-hidden="true" /> Offline downloads
              </h2>
              <p className="mt-1 text-xs text-muted-foreground">{offlineRecipes.length} recipes · {formatBytes(storageInfo.recipeBytes)} recipe data</p>
            </div>
            <div className="shrink-0 text-right text-[11px] text-muted-foreground">
              <HardDriveDownload className="ml-auto h-4 w-4 text-primary" aria-hidden="true" />
              <span className="mt-1 block">{storageInfo.usedBytes === null ? "Device storage varies" : `${formatBytes(storageInfo.usedBytes)} used`}</span>
              {storageInfo.quotaBytes !== null && <span className="block">of {formatBytes(storageInfo.quotaBytes)}</span>}
            </div>
          </div>

          <div className="relative">
            <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
            <input
              value={offlineSearch}
              onChange={(event) => setOfflineSearch(event.target.value)}
              placeholder="Search downloaded recipes or ingredients"
              aria-label="Search downloaded recipes"
              className="min-h-12 w-full rounded-full border border-input bg-card pl-11 pr-4 text-base shadow-[var(--shadow-soft)] outline-none transition focus:border-primary"
            />
          </div>

          <div className="rail -mx-3 px-3 sm:mx-0 sm:px-0" aria-label="Filter downloaded recipes">
            {offlineCategories.map((category) => (
              <Button
                key={category}
                type="button"
                variant={offlineCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setOfflineCategory(category)}
                className="shrink-0 rounded-full"
              >
                {category}
              </Button>
            ))}
          </div>

          {filteredOfflineRecipes.length > 0 ? (
            <ul className="grid gap-2.5 sm:grid-cols-2">
              {filteredOfflineRecipes.map((r) => (
                <li key={r.id} className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2 rounded-2xl border border-[color-mix(in_oklab,var(--gold)_16%,transparent)] bg-card p-2 shadow-[var(--shadow-soft)]">
                  <Link to="/recipes/$id" params={{ id: r.id }} className="min-w-0 rounded-xl px-2 py-2 text-sm transition hover:bg-accent/50">
                    <span className="block truncate font-display text-base leading-tight">{r.name}</span>
                    <span className="block truncate text-[11px] font-medium uppercase tracking-[0.1em] text-muted-foreground">{r.state ?? "India"} · {r.category ?? "Recipe"}</span>
                  </Link>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    aria-label={`Remove ${r.name} from offline downloads`}
                    title="Remove download"
                    onClick={() => {
                      removeOfflineRecipe(r.id);
                      toast.success(`${r.name} removed from offline downloads`);
                    }}
                    className="h-11 w-11 shrink-0 rounded-full text-destructive hover:bg-destructive/10 hover:text-destructive"
                  >
                    <Trash2 aria-hidden="true" />
                  </Button>
                </li>
              ))}
            </ul>
          ) : (
            <div className="rounded-2xl border border-dashed border-input px-5 py-8 text-center text-sm text-muted-foreground">No offline recipes match this search.</div>
          )}
        </section>
      )}

      {total === 0 && offlineRecipes.length === 0 ? (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="panel mx-auto max-w-xl p-10 text-center sm:p-14"
        >
          <div className="mx-auto grid h-16 w-16 place-items-center rounded-full gradient-gold shadow-[var(--shadow-glow)]">
            <Heart className="h-7 w-7 text-[oklch(0.24_0.05_46)]" aria-hidden="true" />
          </div>
          <h2 className="mt-5 font-display text-2xl">Nothing saved yet</h2>
          <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
            Tap the heart on any recipe or ask the AI Chef about a dish to add it to your collection.
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Link to="/" className="btn-gold rounded-full px-6 py-2.5 text-sm font-semibold">Browse recipes</Link>
            <Link to="/chef" className="btn-quiet inline-flex items-center gap-1.5 rounded-full px-6 py-2.5 text-sm font-semibold">
              <ChefHat className="h-4 w-4" aria-hidden="true" /> Ask AI Chef
            </Link>
          </div>
        </motion.div>
      ) : (
        <>
          {savedFoods.length > 0 && (
            <section className="reveal space-y-4">
              <h2 className="flex items-center gap-2 font-display text-2xl">
                <Sparkles className="h-5 w-5 text-[var(--saffron)]" aria-hidden="true" /> AI Chef cards
              </h2>
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                {savedFoods.map(f => <FoodCard key={f.food_name} food={f} />)}
              </div>
            </section>
          )}

          {savedRecipes.length > 0 && (
            <section className="reveal space-y-4">
              <h2 className="font-display text-2xl">Saved recipes</h2>
              <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
                {savedRecipes.map((r, i) => <RecipeCard key={r.id} recipe={r} index={i} />)}
              </div>
            </section>
          )}
        </>
      )}
    </div>
  );
}
