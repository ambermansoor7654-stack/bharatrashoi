import { createFileRoute, Link } from '@tanstack/react-router';
import { useSuspenseQuery, queryOptions } from '@tanstack/react-query';
import { CheckCircle, Video, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { listCommunity } from '@/lib/community.functions';
import { pageMeta } from '@/lib/page-meta';
import { ChannelSubscribe } from '@/components/ChannelSubscribe';

const communityQuery = queryOptions({ queryKey: ['community'], queryFn: () => listCommunity(), staleTime: 30000 });

export const Route = createFileRoute('/channels/$handle')({
  head: ({ params }) => pageMeta(`@${params.handle} cooking channel`, `Watch @${params.handle}’s dish videos on Bharat Rasoi.`),
  loader: ({ context }) => context.queryClient.ensureQueryData(communityQuery),
  component: ChannelPage,
});

function ChannelPage() {
  const { handle } = Route.useParams();
  const { data } = useSuspenseQuery(communityQuery);
  const channel = data.channels.find(c => c.handle.toLowerCase() === handle.toLowerCase());

  if (!channel) {
    return (
      <div className="py-16 text-center">
        <h1 className="font-display text-3xl">Channel not found</h1>
        <p className="mt-2 text-muted-foreground">This kitchen may have moved or closed.</p>
        <Button asChild variant="outline" className="mt-6"><Link to="/channels"><ArrowLeft /> All channels</Link></Button>
      </div>
    );
  }

  const videos = data.videos.filter(v => v.channel_id === channel.id);

  return (
    <div className="space-y-8">
      <Button asChild variant="ghost" size="sm" className="-ml-2"><Link to="/channels"><ArrowLeft /> All channels</Link></Button>

      <header>
        <div className="relative h-36 overflow-hidden rounded-xl border border-border bg-muted sm:h-48">
          {channel.bannerUrl ? (
            <img src={channel.bannerUrl} alt="" className="h-full w-full object-cover" />
          ) : (
            <div className="h-full w-full bg-[var(--gradient-gold)] opacity-20" />
          )}
        </div>
        <div className="mt-4 flex flex-wrap items-start gap-4">
          <div className="-mt-12 ml-4 h-20 w-20 shrink-0 overflow-hidden rounded-full border-4 border-background bg-muted sm:h-24 sm:w-24">
            {channel.avatarUrl ? (
              <img src={channel.avatarUrl} alt="" className="h-full w-full object-cover" />
            ) : (
              <Video className="m-6 h-8 w-8 text-muted-foreground sm:m-7" aria-hidden="true" />
            )}
          </div>
          <div className="min-w-0 flex-1 pt-1">
            <h1 className="break-words font-display text-3xl sm:text-4xl">{channel.name}</h1>
            <p className="mt-1 break-all text-primary">@{channel.handle}</p>
            {channel.monetized && (
              <span className="mt-2 inline-flex items-center gap-1 text-xs font-medium text-primary"><CheckCircle className="h-3.5 w-3.5" /> Monetization eligible</span>
            )}
            {channel.description && <p className="mt-3 max-w-2xl break-words text-sm leading-6 text-muted-foreground">{channel.description}</p>}
            <p className="mt-2 text-xs text-muted-foreground">{videos.length} video{videos.length === 1 ? '' : 's'}</p>
            <div className="mt-3"><ChannelSubscribe channelId={channel.id} ownerId={channel.owner_id} count={channel.subscriberCount} /></div>
          </div>
        </div>
      </header>

      <section>
        <h2 className="font-display text-2xl">Videos</h2>
        {videos.length === 0 ? (
          <p className="py-8 text-center text-muted-foreground">No dish videos published yet.</p>
        ) : (
          <div className="mt-4 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {videos.map(v => (
              <article key={v.id} className="min-w-0 overflow-hidden rounded-lg border border-border bg-card">
                <div className="aspect-video bg-muted">
                  {v.url ? (
                    <video className="h-full w-full object-contain" controls playsInline preload="metadata" src={v.url} />
                  ) : (
                    <p className="p-4 text-sm text-muted-foreground">Video unavailable</p>
                  )}
                </div>
                <div className="space-y-2 p-4">
                  <h3 className="break-words font-display text-2xl">{v.title}</h3>
                  <p className="text-xs text-muted-foreground">{v.state}</p>
                  <p className="break-words text-sm text-muted-foreground">{v.description}</p>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
