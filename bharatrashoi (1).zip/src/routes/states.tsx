import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MapPin, Search, Languages, Building2, UtensilsCrossed, X, ChefHat, ArrowUpRight } from "lucide-react";
import { STATES, RECIPES, REGIONS, type IndianState } from "@/lib/data";
import { RecipeCard } from "@/components/RecipeCard";
import { IndiaMap } from "@/components/IndiaMap";

export const Route = createFileRoute("/states")({
  head: () => ({
    meta: [
      { title: "States — Bharat Rasoi" },
      { name: "description", content: "Explore the food, language and culture of Indian states and union territories including Jammu & Kashmir." },
    ],
  }),
  component: StatesPage,
});

type RegionFilter = "All" | (typeof REGIONS)[number];
const REGION_FILTERS: RegionFilter[] = ["All", ...REGIONS];

function StatesPage() {
  const [query, setQuery] = useState("");
  const [region, setRegion] = useState<RegionFilter>("All");
  const [selected, setSelected] = useState<IndianState | null>(null);

  const states = useMemo(() => {
    const q = query.trim().toLowerCase();
    return STATES.filter(s => {
      if (region !== "All" && s.region !== region) return false;
      if (!q) return true;
      return (
        s.name.toLowerCase().includes(q) ||
        s.capital.toLowerCase().includes(q) ||
        s.language.toLowerCase().includes(q) ||
        s.signature.toLowerCase().includes(q) ||
        s.foodCategories.some(c => c.toLowerCase().includes(q))
      );
    });
  }, [query, region]);

  const stateRecipes = useMemo(
    () => selected ? RECIPES.filter(r => r.state === selected.name) : [],
    [selected]
  );

  return (
    <div className="space-y-8 sm:space-y-10">
      <div>
        <div className="eyebrow flex items-center gap-2">
          <MapPin className="h-3.5 w-3.5 text-[var(--saffron)]" aria-hidden="true" /> Bharat ka Swaad
        </div>
        <h1 className="mt-3 font-display text-4xl leading-tight sm:text-6xl">
          Every <span className="text-gradient">state & UT</span>, one kitchen
        </h1>
        <p className="mt-3 max-w-xl text-sm text-muted-foreground sm:text-base">
          Search by state, capital, language or dish. Tap any card to dive into its culture and recipes.
        </p>
      </div>

      {/* Interactive India map */}
      <IndiaMap states={STATES} selected={selected} onSelect={setSelected} />

      {/* Search */}
      <div className="glass flex items-center gap-2 rounded-2xl border border-[color-mix(in_oklab,var(--gold)_16%,transparent)] p-2 pl-4 shadow-[var(--shadow-soft)]">
        <Search className="h-4.5 w-4.5 shrink-0 text-muted-foreground" aria-hidden="true" />
        <input
          value={query}
          onChange={e => setQuery(e.target.value)}
          placeholder="Try 'Bengaluru', 'Tamil', 'biryani'…"
          className="min-w-0 flex-1 bg-transparent py-1.5 text-sm outline-none placeholder:text-muted-foreground"
        />
        {query && (
          <button onClick={() => setQuery("")} className="grid h-9 w-9 shrink-0 touch-manipulation place-items-center rounded-xl btn-quiet" aria-label="Clear search">
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      {/* Region chips */}
      <div className="rail -mx-1 px-1 pb-1">
        {REGION_FILTERS.map(r => {
          const active = region === r;
          return (
            <button
              key={r}
              onClick={() => setRegion(r)}
              aria-pressed={active}
              className={`shrink-0 touch-manipulation rounded-full px-5 py-2 text-[13px] font-medium transition active:scale-95 ${active ? "btn-ink" : "btn-quiet"}`}
            >
              {r}
            </button>
          );
        })}
      </div>

      <div className="text-xs text-muted-foreground">
        Showing <span className="font-semibold text-foreground">{states.length}</span> of {STATES.length} states
      </div>

      {/* State grid */}
      {states.length === 0 ? (
        <div className="panel p-12 text-center">
          <Search className="mx-auto h-6 w-6 text-[var(--gold)]" aria-hidden="true" />
          <h3 className="mt-3 font-display text-xl">No states match your search</h3>
          <p className="mt-1.5 text-sm text-muted-foreground">Try clearing filters or a different keyword.</p>
        </div>
      ) : (
        <motion.div
          layout
          className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3"
        >
          <AnimatePresence mode="popLayout">
            {states.map((s, i) => (
              <motion.button
                key={s.id}
                layout
                initial={{ opacity: 0, y: 24, scale: 0.96 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ delay: Math.min(i * 0.03, 0.3), type: "spring", stiffness: 220, damping: 24 }}
                whileHover={{ y: -6 }}
                onClick={() => setSelected(s)}
                className="group card-lift relative h-[300px] overflow-hidden rounded-[1.5rem] border border-[color-mix(in_oklab,var(--gold)_16%,transparent)] text-left shadow-[var(--shadow-soft)]"
              >
                <div className="media-frame absolute inset-0">
                  <img
                    src={s.image}
                    alt={s.name}
                    loading="lazy"
                    className="h-full w-full object-cover"
                  />
                </div>
                <div aria-hidden="true" className={`absolute inset-0 bg-gradient-to-br ${s.color} opacity-50 mix-blend-multiply`} />
                <div aria-hidden="true" className="scrim absolute inset-0" />

                <div className="absolute right-3 top-3 rounded-full border border-[oklch(1_0_0/0.25)] bg-[oklch(0.14_0.02_38/0.45)] px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.16em] text-[oklch(0.98_0.01_88)] backdrop-blur">
                  {s.region}
                </div>

                <div className="absolute inset-x-0 bottom-0 p-5 text-[oklch(0.98_0.01_88)]">
                  <div className="flex items-end justify-between gap-2">
                    <div className="min-w-0 font-display text-3xl leading-tight">{s.name}</div>
                    <span className="mb-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-full border border-[oklch(1_0_0/0.3)] bg-[oklch(0.14_0.02_38/0.4)] text-[var(--saffron)] backdrop-blur transition group-hover:translate-x-0.5 group-hover:-translate-y-0.5">
                      <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                    </span>
                  </div>
                  <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] font-medium opacity-80">
                    <span className="inline-flex items-center gap-1"><Building2 className="h-3 w-3" aria-hidden="true" />{s.capital}</span>
                    <span className="inline-flex items-center gap-1"><Languages className="h-3 w-3" aria-hidden="true" />{s.language}</span>
                  </div>
                  <div className="mt-3 inline-flex items-center gap-1.5 rounded-full border border-[oklch(1_0_0/0.2)] bg-[oklch(1_0_0/0.12)] px-2.5 py-1 text-[11px] font-semibold backdrop-blur">
                    <UtensilsCrossed className="h-3 w-3 text-[var(--saffron)]" aria-hidden="true" />{s.signature}
                  </div>
                </div>
              </motion.button>
            ))}
          </AnimatePresence>
        </motion.div>
      )}

      {/* Detail modal */}
      <AnimatePresence>
        {selected && (
          <StateModal
            state={selected}
            recipes={stateRecipes}
            onClose={() => setSelected(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function StateModal({
  state, recipes, onClose,
}: { state: IndianState; recipes: typeof RECIPES; onClose: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-end justify-center bg-[oklch(0.1_0.02_38/0.66)] pt-[max(1rem,env(safe-area-inset-top))] backdrop-blur-sm sm:items-center sm:p-6"
    >
      <motion.div
        onClick={e => e.stopPropagation()}
        initial={{ y: 40, opacity: 0, scale: 0.96 }}
        animate={{ y: 0, opacity: 1, scale: 1 }}
        exit={{ y: 40, opacity: 0, scale: 0.96 }}
        transition={{ type: "spring", stiffness: 240, damping: 26 }}
        className="relative max-h-[calc(100dvh-env(safe-area-inset-top))] w-full max-w-3xl overflow-y-auto rounded-t-3xl border border-[color-mix(in_oklab,var(--gold)_18%,transparent)] bg-card pb-[env(safe-area-inset-bottom)] shadow-[var(--shadow-card)] sm:max-h-[92dvh] sm:rounded-3xl sm:pb-0"
      >
        <div className="relative h-56 overflow-hidden sm:h-72">
          <img src={state.image} alt={state.name} className="absolute inset-0 h-full w-full object-cover" />
          <div className={`absolute inset-0 bg-gradient-to-br ${state.color} opacity-55 mix-blend-multiply`} />
          <div aria-hidden="true" className="scrim absolute inset-0" />
          <button
            onClick={onClose}
            className="absolute right-4 top-4 grid h-10 w-10 touch-manipulation place-items-center rounded-full border border-[oklch(1_0_0/0.25)] bg-[oklch(0.14_0.02_38/0.55)] text-[oklch(0.98_0.01_88)] backdrop-blur transition hover:scale-105 active:scale-95"
            aria-label="Close"
          >
            <X className="h-5 w-5" />
          </button>
          <div className="absolute inset-x-0 bottom-0 p-5 text-[oklch(0.98_0.01_88)] sm:p-7">
            <div className="eyebrow !text-[oklch(0.9_0.05_84)]">{state.region} India</div>
            <h2 className="mt-1 font-display text-4xl leading-tight sm:text-6xl">{state.name}</h2>
            <div className="mt-3 flex flex-wrap gap-2 text-xs">
              <span className="inline-flex items-center gap-1 rounded-full border border-[oklch(1_0_0/0.25)] bg-[oklch(0.14_0.02_38/0.45)] px-2.5 py-1 backdrop-blur">
                <Building2 className="h-3 w-3" aria-hidden="true" />{state.capital}
              </span>
              <span className="inline-flex items-center gap-1 rounded-full border border-[oklch(1_0_0/0.25)] bg-[oklch(0.14_0.02_38/0.45)] px-2.5 py-1 backdrop-blur">
                <Languages className="h-3 w-3" aria-hidden="true" />{state.language}
              </span>
            </div>
          </div>
        </div>

        <div className="space-y-6 p-5 sm:p-7">
          <p className="text-sm leading-relaxed text-muted-foreground sm:text-base">{state.culture}</p>

          <div className="hairline pt-5">
            <div className="eyebrow mb-3">Food categories</div>
            <div className="flex flex-wrap gap-2">
              {state.foodCategories.map(c => (
                <span key={c} className="inline-flex items-center gap-1.5 rounded-full border border-[color-mix(in_oklab,var(--gold)_18%,transparent)] bg-[color-mix(in_oklab,var(--card)_92%,transparent)] px-3 py-1.5 text-xs font-semibold shadow-[var(--shadow-soft)]">
                  <UtensilsCrossed className="h-3 w-3 text-[var(--saffron)]" aria-hidden="true" />{c}
                </span>
              ))}
            </div>
          </div>

          <div className="panel flex items-center gap-3 p-4">
            <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl gradient-gold">
              <ChefHat className="h-5 w-5 text-[oklch(0.24_0.05_46)]" aria-hidden="true" />
            </div>
            <div className="min-w-0">
              <div className="eyebrow">Signature dish</div>
              <div className="truncate font-display text-xl">{state.signature}</div>
            </div>
          </div>

          {recipes.length > 0 ? (
            <div className="hairline pt-5">
              <div className="mb-3 font-display text-xl">From this kitchen</div>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                {recipes.map((r, i) => <RecipeCard key={r.id} recipe={r} index={i} />)}
              </div>
            </div>
          ) : (
            <div className="panel p-6 text-center text-sm text-muted-foreground">
              Recipes from {state.name} are simmering. Meanwhile,{" "}
              <Link to="/" className="font-semibold text-primary" onClick={onClose}>browse all dishes</Link>.
            </div>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}
