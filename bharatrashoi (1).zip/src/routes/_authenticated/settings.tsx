import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { toast } from "sonner";
import { Crown, Loader2, RotateCcw, ShieldCheck, XCircle, ArrowRight, LogOut } from "lucide-react";
import { PLANS, daysLeft, formatDate } from "@/lib/premium";
import { cancelSubscription, restorePurchase } from "@/lib/premium.functions";
import { usePremium, useRefreshPremium } from "@/lib/use-premium";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { PremiumBadge, VerifiedBadge } from "@/components/PremiumBadges";

export const Route = createFileRoute("/_authenticated/settings")({
  head: () => ({
    meta: [
      { title: "Settings — Bharat Rasoi" },
      { name: "description", content: "Manage your Bharat Rasoi subscription, verification badge and account." },
      { property: "og:title", content: "Settings — Bharat Rasoi" },
      { property: "og:description", content: "Manage your Bharat Rasoi Premium subscription and account." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: SettingsPage,
});

function SettingsPage() {
  const { user } = useAuth();
  const premium = usePremium();
  const refresh = useRefreshPremium();
  const cancel = useServerFn(cancelSubscription);
  const restore = useServerFn(restorePurchase);
  const [busy, setBusy] = useState<"cancel" | "restore" | null>(null);

  if (premium.loading) {
    return (
      <div className="grid place-items-center py-20">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  async function handleCancel() {
    if (!confirm("Cancel Premium now? You'll lose premium features immediately.")) return;
    setBusy("cancel");
    try {
      await cancel();
      refresh();
      toast.success("Subscription cancelled.");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not cancel.");
    } finally {
      setBusy(null);
    }
  }

  async function handleRestore() {
    setBusy("restore");
    try {
      const res = await restore();
      refresh();
      res.ok ? toast.success(res.message) : toast.error(res.message);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not restore.");
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="mx-auto max-w-2xl space-y-6 pb-6">
      <header className="reveal">
        <p className="eyebrow">Account</p>
        <h1 className="mt-1.5 font-display text-4xl">Settings</h1>
        <p className="mt-2 flex items-center gap-1.5 text-sm text-muted-foreground">
          {user?.email ?? user?.phone}
          {premium.verified && <VerifiedBadge />}
        </p>
      </header>

      <motion.section
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        className="panel-dark relative overflow-hidden rounded-3xl p-6"
      >
        <div
          aria-hidden="true"
          className="absolute inset-0 -z-10 bg-[radial-gradient(120%_120%_at_10%_0%,color-mix(in_oklab,var(--gold)_18%,transparent),transparent_60%)]"
        />
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Crown className="h-5 w-5 text-[var(--gold)]" />
            <h2 className="font-display text-2xl">Subscription</h2>
          </div>
          {premium.isPremium ? <PremiumBadge label={premium.isAdmin ? "Admin · Lifetime" : "Active"} /> : null}
        </div>

        {premium.isAdmin ? (
          <p className="mt-4 text-sm text-[oklch(0.85_0.02_88)]">
            You're the admin — Premium is permanent on this account and cannot expire.
          </p>
        ) : premium.isPremium ? (
          <dl className="mt-5 grid gap-3 sm:grid-cols-3">
            <div className="glass-dark rounded-2xl p-3.5">
              <dt className="eyebrow text-[9px] text-[oklch(0.85_0.02_88)]">Plan</dt>
              <dd className="mt-1 font-display text-lg">{PLANS[premium.plan ?? "monthly"].label}</dd>
            </div>
            <div className="glass-dark rounded-2xl p-3.5">
              <dt className="eyebrow text-[9px] text-[oklch(0.85_0.02_88)]">Renews / expires</dt>
              <dd className="mt-1 font-display text-lg">{formatDate(premium.expiryDate)}</dd>
            </div>
            <div className="glass-dark rounded-2xl p-3.5">
              <dt className="eyebrow text-[9px] text-[oklch(0.85_0.02_88)]">Days left</dt>
              <dd className="mt-1 font-display text-lg">{daysLeft(premium.expiryDate)}</dd>
            </div>
          </dl>
        ) : (
          <div className="mt-4 space-y-3">
            <p className="text-sm text-[oklch(0.85_0.02_88)]">
              You're on the Free plan{premium.pendingPaymentId ? " — a payment is under review." : "."}
            </p>
            <Link to="/premium" className="btn-gold inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold">
              <Crown className="h-4 w-4" /> Upgrade to Premium <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        )}

        <div className="mt-5 flex flex-wrap gap-2 border-t border-[color-mix(in_oklab,var(--gold)_16%,transparent)] pt-5">
          <button
            onClick={handleRestore}
            disabled={busy !== null}
            className="inline-flex items-center gap-2 rounded-full glass-dark px-4 py-2.5 text-sm font-semibold disabled:opacity-60"
          >
            {busy === "restore" ? <Loader2 className="h-4 w-4 animate-spin" /> : <RotateCcw className="h-4 w-4" />} Restore
            purchase
          </button>
          {premium.isPremium && !premium.isAdmin && (
            <button
              onClick={handleCancel}
              disabled={busy !== null}
              className="inline-flex items-center gap-2 rounded-full glass-dark px-4 py-2.5 text-sm font-semibold text-[oklch(0.78_0.14_38)] disabled:opacity-60"
            >
              {busy === "cancel" ? <Loader2 className="h-4 w-4 animate-spin" /> : <XCircle className="h-4 w-4" />} Cancel
              subscription
            </button>
          )}
        </div>
      </motion.section>

      <section className="panel rounded-3xl p-6">
        <div className="flex items-center gap-2">
          <ShieldCheck className="h-5 w-5 text-[#1d9bf0]" />
          <h2 className="font-display text-2xl">Verification</h2>
        </div>
        <p className="mt-2 text-sm text-muted-foreground">
          {premium.verified
            ? "Your account carries the blue verified badge across Bharat Rasoi."
            : "Blue ticks are granted by the admin to trusted home chefs. Keep publishing great dishes!"}
        </p>
      </section>

      <section className="panel rounded-3xl p-6">
        <h2 className="font-display text-2xl">Account</h2>
        <div className="mt-3 flex flex-wrap gap-2">
          <Link to="/profile" className="btn-quiet rounded-full px-4 py-2.5 text-sm font-semibold">
            View profile
          </Link>
          <button
            onClick={() => supabase.auth.signOut()}
            className="btn-quiet inline-flex items-center gap-2 rounded-full px-4 py-2.5 text-sm font-semibold text-[var(--spice)]"
          >
            <LogOut className="h-4 w-4" /> Sign out
          </button>
        </div>
      </section>
    </div>
  );
}
