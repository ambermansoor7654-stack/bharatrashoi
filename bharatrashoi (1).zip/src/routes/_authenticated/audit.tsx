import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import {
  ShieldCheck,
  Crown,
  BadgeCheck,
  XCircle,
  Loader2,
  RefreshCw,
  ArrowLeft,
  ScrollText,
} from "lucide-react";
import { listAuditTrail, type AuditRow } from "@/lib/audit.functions";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/_authenticated/audit")({
  head: () => ({
    meta: [
      { title: "Admin Audit Trail — Bharat Rasoi" },
      {
        name: "description",
        content:
          "Timestamped record of every premium unlock and blue-tick verification action taken by admins on Bharat Rasoi.",
      },
      { property: "og:title", content: "Admin Audit Trail — Bharat Rasoi" },
      {
        property: "og:description",
        content: "Every premium unlock and verification approval, with actor, target and timestamp.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuditPage,
});

const FILTERS = [
  { id: "all", label: "All actions" },
  { id: "premium", label: "Premium unlocks" },
  { id: "verified", label: "Blue tick" },
] as const;

function actionMeta(action: string) {
  if (action === "profile.verified_granted")
    return { label: "Blue tick granted", Icon: BadgeCheck, tone: "text-sky-600 bg-sky-500/10" };
  if (action === "profile.verified_revoked")
    return { label: "Blue tick revoked", Icon: XCircle, tone: "text-rose-600 bg-rose-500/10" };
  if (action === "premium.payment_approved")
    return { label: "Payment approved · premium unlocked", Icon: Crown, tone: "text-amber-600 bg-amber-500/10" };
  if (action === "premium.payment_rejected")
    return { label: "Payment rejected", Icon: XCircle, tone: "text-rose-600 bg-rose-500/10" };
  if (action === "premium.granted_by_admin")
    return { label: "Premium granted by admin", Icon: Crown, tone: "text-amber-600 bg-amber-500/10" };
  if (action === "premium.cancelled")
    return { label: "Premium cancelled by user", Icon: XCircle, tone: "text-muted-foreground bg-muted" };
  return { label: action, Icon: ScrollText, tone: "text-muted-foreground bg-muted" };
}

const fmt = (iso: string) =>
  new Date(iso).toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

const who = (p: AuditRow["actor"]) => p?.name || (p?.username ? `@${p.username}` : null);

function AuditPage() {
  const { isAdmin, loading } = useAuth();
  const [filter, setFilter] = useState<(typeof FILTERS)[number]["id"]>("all");
  const fetchTrail = useServerFn(listAuditTrail);

  const { data, isFetching, refetch, error } = useQuery({
    queryKey: ["audit-trail", filter],
    queryFn: () => fetchTrail({ data: { filter, limit: 150 } }),
    enabled: isAdmin,
  });

  if (loading) {
    return (
      <div className="grid place-items-center py-24">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="mx-auto max-w-md px-4 py-24 text-center">
        <ShieldCheck className="mx-auto mb-4 h-10 w-10 text-muted-foreground" />
        <h1 className="font-serif text-2xl">Admins only</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          This audit trail is restricted to the Bharat Rasoi admin account.
        </p>
        <Link to="/" className="mt-6 inline-block rounded-full bg-primary px-5 py-2 text-sm text-primary-foreground">
          Back home
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-4xl px-4 pb-28 pt-6 sm:pt-10">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <Link
            to="/admin"
            className="mb-2 inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-3.5 w-3.5" /> Admin dashboard
          </Link>
          <h1 className="font-serif text-2xl sm:text-3xl">Audit trail</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Every premium unlock and blue-tick decision, with who did it and when.
          </p>
        </div>
        <button
          type="button"
          onClick={() => refetch()}
          className="inline-flex items-center gap-2 rounded-full border border-border/70 px-4 py-2 text-sm hover:bg-muted/60"
        >
          <RefreshCw className={`h-4 w-4 ${isFetching ? "animate-spin" : ""}`} /> Refresh
        </button>
      </div>

      <div className="mt-5 flex flex-wrap gap-2" role="tablist" aria-label="Filter audit actions">
        {FILTERS.map((f) => (
          <button
            key={f.id}
            role="tab"
            aria-selected={filter === f.id}
            onClick={() => setFilter(f.id)}
            className={`rounded-full px-4 py-1.5 text-sm transition ${
              filter === f.id
                ? "bg-primary text-primary-foreground"
                : "border border-border/70 text-muted-foreground hover:bg-muted/60"
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {error ? (
        <p className="mt-8 rounded-2xl border border-rose-500/30 bg-rose-500/5 p-4 text-sm text-rose-600">
          Could not load the audit trail. {(error as Error).message}
        </p>
      ) : null}

      {isFetching && !data ? (
        <div className="mt-8 space-y-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="h-20 animate-pulse rounded-2xl bg-muted/60" />
          ))}
        </div>
      ) : null}

      {data && data.length === 0 ? (
        <p className="mt-10 rounded-2xl border border-border/60 bg-card/60 p-8 text-center text-sm text-muted-foreground">
          No premium or verification actions recorded yet.
        </p>
      ) : null}

      <ol className="mt-6 space-y-3">
        {(data ?? []).map((row, i) => {
          const { label, Icon, tone } = actionMeta(row.action);
          const actor = who(row.actor);
          const target = who(row.targetUser);
          return (
            <motion.li
              key={row.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: Math.min(i * 0.02, 0.3) }}
              className="rounded-2xl border border-border/60 bg-card/70 p-4 backdrop-blur"
            >
              <div className="flex items-start gap-3">
                <span className={`grid h-9 w-9 shrink-0 place-items-center rounded-xl ${tone}`}>
                  <Icon className="h-4.5 w-4.5" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium">{label}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">
                    {actor ? <>By {actor}</> : <>By admin</>}
                    {target ? <> · for {target}</> : null}
                    {row.metadata["plan"] ? <> · plan {String(row.metadata["plan"])}</> : null}
                  </p>
                  <p className="mt-1 font-mono text-[11px] text-muted-foreground/80">
                    {fmt(row.created_at)}
                    {row.ip ? ` · ${row.ip}` : ""}
                  </p>
                </div>
              </div>
            </motion.li>
          );
        })}
      </ol>
    </div>
  );
}
