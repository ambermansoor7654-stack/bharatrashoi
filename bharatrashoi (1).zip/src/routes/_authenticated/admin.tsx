import { useMemo, useState } from "react";
import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { motion, AnimatePresence } from "framer-motion";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import {
  Plus,
  Pencil,
  Trash2,
  Star,
  Eye,
  EyeOff,
  Upload,
  Sparkles,
  X,
  Search,
  LogOut,
  Loader2,
  Database,
  Save,
  ScrollText,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { isAmberAdminEmail, useAuth } from "@/lib/auth";
import { useRecipes, RAJASTHAN_CATEGORIES, type DbRecipe } from "@/lib/recipes";
import { generateRecipeWithAI } from "@/lib/ai-recipe.functions";
import { generateRecipeImage } from "@/lib/ai-image.functions";
import { RecipeImage } from "@/components/RecipeImage";
import { STATES } from "@/lib/data";
import { Film, Wand2 } from "lucide-react";
import { PremiumAdminPanel } from "@/components/PremiumAdminPanel";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({ meta: [{ title: "Admin — Bharat Rasoi" }] }),
  component: AdminPage,
});

const slugify = (s: string) =>
  s
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");

const emptyRecipe: Partial<DbRecipe> = {
  name: "",
  slug: "",
  state: "Other",
  region: "Other",
  category: "Main Course",
  description: "",
  prep_time: "15 mins",
  cook_time: "30 mins",
  difficulty: "Medium",
  ingredients: [],
  steps: [],
  nutrition: { calories: 0, protein_g: 0, carbs_g: 0, fat_g: 0, fiber_g: 0 },
  tags: [],
  featured: false,
  published: true,
  image_url: null,
  video_url: null,
};

function AdminPage() {
  const navigate = useNavigate();
  const { user, isAdmin, loading } = useAuth();
  const { data: recipes, isLoading: recipesLoading } = useRecipes({ includeUnpublished: true });
  const [query, setQuery] = useState("");
  const [stateFilter, setStateFilter] = useState<string>("All");
  const [editing, setEditing] = useState<Partial<DbRecipe> | null>(null);
  const [bulkOpen, setBulkOpen] = useState(false);

  const filtered = useMemo(() => {
    const q = query.toLowerCase();
    return (recipes ?? []).filter(
      r =>
        (stateFilter === "All" || r.state === stateFilter) &&
        (!q || r.name.toLowerCase().includes(q) || r.category.toLowerCase().includes(q) || r.state.toLowerCase().includes(q)),
    );
  }, [recipes, query, stateFilter]);

  if (loading) {
    return (
      <div className="grid place-items-center py-20">
        <Loader2 className="h-8 w-8 animate-spin text-[var(--gold)]" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="panel mx-auto max-w-md p-10 text-center">
        <h1 className="font-display text-2xl">Admin access only</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Signed in as <strong>{user?.email}</strong>. This account doesn't have admin privileges.
        </p>
        <p className="mt-3 text-xs text-muted-foreground">
          Admin access is granted automatically to the workspace owner email on sign-up.
        </p>
        <button
          onClick={async () => {
            await supabase.auth.signOut();
            navigate({ to: "/auth" });
          }}
          className="btn-quiet mt-6 inline-flex touch-manipulation items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold"
        >
          <LogOut className="h-4 w-4" /> Sign out
        </button>
      </div>
    );
  }

  async function quickToggle(r: DbRecipe, field: "featured" | "published") {
    const { error } = await supabase.from("recipes").update({ [field]: !r[field] } as any).eq("id", r.id);
    if (error) toast.error(error.message);
    else toast.success(`${field} updated`);
  }

  async function deleteRecipe(r: DbRecipe) {
    if (!confirm(`Delete "${r.name}"? This cannot be undone.`)) return;
    const { error } = await supabase.from("recipes").delete().eq("id", r.id);
    if (error) toast.error(error.message);
    else toast.success("Recipe deleted");
  }

  return (
    <div className="space-y-6">
      <header className="panel flex flex-wrap items-center justify-between gap-4 p-5 sm:p-6">
        <div>
          <div className="eyebrow">Bharat Rasoi · CMS</div>
          <h1 className="mt-1 font-display text-3xl text-gradient">
            {isAmberAdminEmail(user?.email) ? "Welcome Amber 👑" : "Admin Dashboard"}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Signed in as <strong>{user?.email}</strong> · {(recipes ?? []).length} recipes across all states
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Link to="/community-admin" className="btn-quiet inline-flex items-center rounded-full px-5 py-2.5 text-sm font-semibold">Channels & activity</Link>
          <Link
            to="/audit"
            className="btn-quiet inline-flex touch-manipulation items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold"
          >
            <ScrollText className="h-4 w-4" /> Audit trail
          </Link>
          <button
            onClick={() => setBulkOpen(true)}
            className="btn-quiet inline-flex touch-manipulation items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold"
          >
            <Database className="h-4 w-4" /> Bulk import
          </button>

          <button
            onClick={() => setEditing({ ...emptyRecipe })}
            className="btn-gold inline-flex touch-manipulation items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold"
          >
            <Plus className="h-4 w-4" /> New recipe
          </button>
          <button
            onClick={async () => {
              await supabase.auth.signOut();
              navigate({ to: "/" });
            }}
            className="btn-quiet grid h-10 w-10 touch-manipulation place-items-center rounded-full"
            title="Sign out"
          >
            <LogOut className="h-4 w-4" />
          </button>
        </div>
      </header>

      <PremiumAdminPanel />

      <div className="panel flex flex-wrap gap-3 p-3">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search recipes by name, state, category..."
            className={`${inputCls} pl-11`}
          />
        </div>
        <select
          value={stateFilter}
          onChange={e => setStateFilter(e.target.value)}
          className={inputCls + " sm:w-56"}
        >
          <option value="All">All states</option>
          {STATES.map(s => (
            <option key={s.id} value={s.name}>{s.name}</option>
          ))}
        </select>
      </div>

      {recipesLoading ? (
        <div className="grid place-items-center py-12">
          <Loader2 className="h-6 w-6 animate-spin text-[var(--gold)]" />
        </div>
      ) : (
        <div className="panel overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="hairline border-t-0 text-left text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                <tr>
                  <th className="px-4 py-3">Recipe</th>
                  <th className="px-4 py-3">State</th>
                  <th className="px-4 py-3">Category</th>
                  <th className="px-4 py-3">Times</th>
                  <th className="px-4 py-3 text-center">Featured</th>
                  <th className="px-4 py-3 text-center">Published</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(r => (
                  <tr key={r.id} className="hairline transition hover:bg-[color-mix(in_oklab,var(--gold)_6%,transparent)]">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="h-12 w-12 shrink-0 overflow-hidden rounded-xl border border-[color-mix(in_oklab,var(--gold)_16%,transparent)]">
                          <RecipeImage src={r.image_url} alt={r.name} className="h-full w-full object-cover" />
                        </div>
                        <div className="min-w-0">
                          <div className="truncate font-semibold">{r.name}</div>
                          <div className="truncate text-xs text-muted-foreground">{r.slug}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-xs"><span className="rounded-full bg-[color-mix(in_oklab,var(--gold)_16%,transparent)] px-2 py-1 font-medium text-[color-mix(in_oklab,var(--gold)_75%,var(--foreground))]">{r.state}</span></td>
                    <td className="px-4 py-3 text-muted-foreground">{r.category}</td>
                    <td className="px-4 py-3 text-xs text-muted-foreground">
                      {r.prep_time} prep · {r.cook_time} cook
                    </td>
                    <td className="px-4 py-3 text-center">
                      <button
                        onClick={() => quickToggle(r, "featured")}
                        className={`inline-grid h-8 w-8 touch-manipulation place-items-center rounded-full transition active:scale-90 ${
                          r.featured ? "gradient-gold text-[oklch(0.24_0.05_46)] shadow-[var(--shadow-glow)]" : "btn-quiet"
                        }`}
                        title="Toggle featured"
                      >
                        <Star className={`h-3.5 w-3.5 ${r.featured ? "fill-[oklch(0.24_0.05_46)]" : ""}`} />
                      </button>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <button
                        onClick={() => quickToggle(r, "published")}
                        className={`inline-grid h-8 w-8 touch-manipulation place-items-center rounded-full transition active:scale-90 ${
                          r.published ? "bg-[var(--india-green)] text-[oklch(0.98_0.01_88)]" : "btn-quiet text-muted-foreground"
                        }`}
                        title={r.published ? "Unpublish" : "Publish"}
                      >
                        {r.published ? <Eye className="h-3.5 w-3.5" /> : <EyeOff className="h-3.5 w-3.5" />}
                      </button>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-1">
                        <button
                          onClick={() => setEditing(r)}
                          className="btn-quiet grid h-8 w-8 touch-manipulation place-items-center rounded-full"
                          title="Edit"
                        >
                          <Pencil className="h-3.5 w-3.5" />
                        </button>
                        <button
                          onClick={() => deleteRecipe(r)}
                          className="grid h-8 w-8 touch-manipulation place-items-center rounded-full border border-[color-mix(in_oklab,var(--destructive)_30%,transparent)] text-[var(--destructive)] transition hover:bg-[color-mix(in_oklab,var(--destructive)_10%,transparent)]"
                          title="Delete"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={7} className="px-4 py-14 text-center text-sm text-muted-foreground">
                      No recipes match your search.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <AnimatePresence>
        {editing && <EditorModal recipe={editing} onClose={() => setEditing(null)} />}
        {bulkOpen && <BulkImportModal onClose={() => setBulkOpen(false)} />}
      </AnimatePresence>
    </div>
  );
}

// ──────────────────────────────────────────────────────────────────────
// Editor modal
// ──────────────────────────────────────────────────────────────────────

function EditorModal({ recipe, onClose }: { recipe: Partial<DbRecipe>; onClose: () => void }) {
  const [form, setForm] = useState<Partial<DbRecipe>>(recipe);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadingVideo, setUploadingVideo] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [genImg, setGenImg] = useState(false);
  const aiGen = useServerFn(generateRecipeWithAI);
  const aiImg = useServerFn(generateRecipeImage);

  const isNew = !recipe.id;

  const update = <K extends keyof DbRecipe>(k: K, v: DbRecipe[K]) => setForm(s => ({ ...s, [k]: v }));

  async function onUpload(file: File) {
    setUploading(true);
    try {
      const ext = file.name.split(".").pop() || "jpg";
      const slug = form.slug || slugify(form.name || "untitled");
      const path = `${slug}-${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage.from("recipe-images").upload(path, file, {
        upsert: true,
        contentType: file.type,
      });
      if (upErr) throw upErr;
      update("image_url", path);
      toast.success("Image uploaded");
    } catch (e: any) {
      toast.error(e.message ?? "Upload failed");
    } finally {
      setUploading(false);
    }
  }

  async function onUploadVideo(file: File) {
    setUploadingVideo(true);
    try {
      const ext = file.name.split(".").pop() || "mp4";
      const slug = form.slug || slugify(form.name || "untitled");
      const path = `${slug}-${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage.from("recipe-videos").upload(path, file, {
        upsert: true,
        contentType: file.type,
      });
      if (upErr) throw upErr;
      update("video_url", path);
      toast.success("Video uploaded");
    } catch (e: any) {
      toast.error(e.message ?? "Video upload failed");
    } finally {
      setUploadingVideo(false);
    }
  }

  async function onAIGenerateImage() {
    if (!form.name) {
      toast.error("Enter a dish name first");
      return;
    }
    setGenImg(true);
    try {
      const result = await aiImg({
        data: {
          dish: form.name,
          slug: form.slug || slugify(form.name),
          state: form.state ?? "",
        },
      });
      update("image_url", result.path);
      toast.success("AI image ready");
    } catch (e: any) {
      toast.error(e.message ?? "Image generation failed");
    } finally {
      setGenImg(false);
    }
  }

  async function onAIGenerate() {
    if (!form.name) {
      toast.error("Enter a dish name first");
      return;
    }
    setGenerating(true);
    try {
      const data = await aiGen({ data: { dish: form.name, state: form.state ?? "Other" } });
      setForm(s => ({
        ...s,
        description: data.description ?? s.description,
        category: data.category ?? s.category,
        prep_time: data.prep_time ?? s.prep_time,
        cook_time: data.cook_time ?? s.cook_time,
        difficulty: data.difficulty ?? s.difficulty,
        ingredients: Array.isArray(data.ingredients) ? data.ingredients : s.ingredients,
        steps: Array.isArray(data.steps) ? data.steps : s.steps,
        nutrition: data.nutrition ?? s.nutrition,
        tags: Array.isArray(data.tags) ? data.tags : s.tags,
      }));
      toast.success("AI details generated");
    } catch (e: any) {
      toast.error(e.message ?? "Generation failed");
    } finally {
      setGenerating(false);
    }
  }

  async function save() {
    setSaving(true);
    try {
      let payload: Partial<DbRecipe> = {
        ...form,
        slug: form.slug || slugify(form.name || ""),
      };
      if (!payload.name || !payload.slug) throw new Error("Name is required");

      // Auto-generate AI image on create when admin hasn't supplied one
      if (isNew && !payload.image_url && payload.name) {
        try {
          toast.info("Generating AI image for this dish…");
          const result = await aiImg({
            data: { dish: payload.name, slug: payload.slug, state: payload.state ?? "" },
          });
          payload = { ...payload, image_url: result.path };
          setForm(s => ({ ...s, image_url: result.path }));
        } catch (e: any) {
          toast.warning(`Saved without AI image: ${e.message ?? "generation failed"}`);
        }
      }

      if (isNew) {
        const { error } = await supabase.from("recipes").insert(payload as any);
        if (error) throw error;
        toast.success("Recipe created");
      } else {
        const { error } = await supabase.from("recipes").update(payload as any).eq("id", recipe.id!);
        if (error) throw error;
        toast.success("Recipe updated");
      }
      onClose();
    } catch (e: any) {
      toast.error(e.message ?? "Save failed");
    } finally {
      setSaving(false);
    }
  }


  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-[oklch(0.1_0.02_38/0.66)] p-4 backdrop-blur"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.96, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.96, y: 20 }}
        onClick={e => e.stopPropagation()}
        className="max-h-[92vh] w-full max-w-3xl overflow-y-auto rounded-3xl border border-[color-mix(in_oklab,var(--gold)_18%,transparent)] bg-card p-6 shadow-[var(--shadow-card)]"
      >
        <div className="sticky top-0 -mx-6 -mt-6 mb-4 flex items-center justify-between border-b border-[color-mix(in_oklab,var(--gold)_16%,transparent)] bg-[color-mix(in_oklab,var(--card)_92%,transparent)] px-6 py-4 backdrop-blur">
          <h2 className="font-display text-2xl">{isNew ? "New recipe" : `Edit: ${recipe.name}`}</h2>
          <div className="flex gap-2">
            <button
              onClick={onAIGenerate}
              disabled={generating}
              className="btn-quiet inline-flex touch-manipulation items-center gap-2 rounded-full px-4 py-2 text-xs font-semibold disabled:opacity-60"
            >
              {generating ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5 text-[var(--saffron)]" />}
              AI fill details
            </button>
            <button onClick={onClose} className="btn-quiet grid h-9 w-9 touch-manipulation place-items-center rounded-full">
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Name">
            <input
              value={form.name ?? ""}
              onChange={e => {
                update("name", e.target.value);
                if (isNew) update("slug", slugify(e.target.value));
              }}
              className={inputCls}
            />
          </Field>
          <Field label="Slug (URL)">
            <input value={form.slug ?? ""} onChange={e => update("slug", e.target.value)} className={inputCls} />
          </Field>
          <Field label="Category">
            <select value={form.category ?? "Main Course"} onChange={e => update("category", e.target.value)} className={inputCls}>
              {RAJASTHAN_CATEGORIES.filter(c => c !== "All").map(c => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Difficulty">
            <select value={form.difficulty ?? "Medium"} onChange={e => update("difficulty", e.target.value)} className={inputCls}>
              {["Easy", "Medium", "Hard"].map(d => (
                <option key={d}>{d}</option>
              ))}
            </select>
          </Field>
          <Field label="Prep time">
            <input value={form.prep_time ?? ""} onChange={e => update("prep_time", e.target.value)} className={inputCls} />
          </Field>
          <Field label="Cook time">
            <input value={form.cook_time ?? ""} onChange={e => update("cook_time", e.target.value)} className={inputCls} />
          </Field>
          <Field label="State">
            <select
              value={form.state ?? "Other"}
              onChange={e => {
                const s = STATES.find(x => x.name === e.target.value);
                update("state", e.target.value);
                if (s) update("region", s.region);
              }}
              className={inputCls}
            >
              {STATES.map(s => (
                <option key={s.id} value={s.name}>{s.name}</option>
              ))}
            </select>
          </Field>
          <Field label="Region">
            <input value={form.region ?? "West"} onChange={e => update("region", e.target.value)} className={inputCls} />
          </Field>
        </div>

        <Field label="Description" className="mt-4">
          <textarea
            value={form.description ?? ""}
            onChange={e => update("description", e.target.value)}
            rows={2}
            className={inputCls}
          />
        </Field>

        <Field label="Image" className="mt-4">
          <div className="flex flex-wrap items-center gap-3">
            <label className="btn-gold inline-flex cursor-pointer touch-manipulation items-center gap-2 rounded-2xl px-4 py-2.5 text-sm font-semibold">
              {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
              {uploading ? "Uploading..." : "Upload"}
              <input
                type="file"
                accept="image/*"
                hidden
                onChange={e => {
                  const f = e.target.files?.[0];
                  if (f) onUpload(f);
                }}
              />
            </label>
            <button
              type="button"
              onClick={onAIGenerateImage}
              disabled={genImg || !form.name}
              className="btn-quiet inline-flex touch-manipulation items-center gap-2 rounded-2xl px-4 py-2.5 text-sm font-semibold disabled:opacity-50"
              title="Let AI paint this dish"
            >
              {genImg ? <Loader2 className="h-4 w-4 animate-spin" /> : <Wand2 className="h-4 w-4 text-[var(--saffron)]" />}
              {genImg ? "Painting…" : "AI image"}
            </button>
            {form.image_url && (
              <div className="h-16 w-16 overflow-hidden rounded-xl border-2 border-[var(--gold)]/50 shadow-[var(--shadow-soft)]">
                <RecipeImage src={form.image_url} alt="preview" className="h-full w-full object-cover" />
              </div>
            )}
            <input
              placeholder="…or paste URL / storage path"
              value={form.image_url ?? ""}
              onChange={e => update("image_url", e.target.value || null)}
              className={`${inputCls} flex-1 min-w-[180px]`}
            />
          </div>
          {isNew && !form.image_url && (
            <p className="mt-2 text-[11px] text-muted-foreground">
              Tip: leave empty and we'll auto-generate one when you save.
            </p>
          )}
        </Field>

        <Field label="Video tutorial (optional)" className="mt-4">
          <div className="flex flex-wrap items-center gap-3">
            <label className="inline-flex cursor-pointer touch-manipulation items-center gap-2 rounded-2xl bg-[var(--spice)] px-4 py-2.5 text-sm font-semibold text-[oklch(0.98_0.01_88)] transition hover:brightness-105">
              {uploadingVideo ? <Loader2 className="h-4 w-4 animate-spin" /> : <Film className="h-4 w-4" />}
              {uploadingVideo ? "Uploading…" : "Upload video"}
              <input
                type="file"
                accept="video/*"
                hidden
                onChange={e => {
                  const f = e.target.files?.[0];
                  if (f) onUploadVideo(f);
                }}
              />
            </label>
            {form.video_url && (
              <span className="inline-flex items-center gap-1 rounded-full bg-[color-mix(in_oklab,var(--india-green)_16%,transparent)] px-3 py-1 text-xs font-semibold text-[var(--india-green)]">
                <Film className="h-3 w-3" /> Video attached
                <button
                  type="button"
                  onClick={() => update("video_url", null)}
                  className="ml-1 grid h-4 w-4 touch-manipulation place-items-center rounded-full bg-[color-mix(in_oklab,var(--india-green)_25%,transparent)]"
                  title="Remove video"
                >
                  <X className="h-2.5 w-2.5" />
                </button>
              </span>
            )}
            <input
              placeholder="…or paste video URL / storage path"
              value={form.video_url ?? ""}
              onChange={e => update("video_url", e.target.value || null)}
              className={`${inputCls} flex-1 min-w-[180px]`}
            />
          </div>
        </Field>


        <ListField
          label="Ingredients"
          items={form.ingredients ?? []}
          onChange={v => update("ingredients", v)}
          placeholder="e.g. 1 cup besan"
        />
        <ListField
          label="Steps"
          items={form.steps ?? []}
          onChange={v => update("steps", v)}
          placeholder="Clear instruction step"
          textarea
        />

        <Field label="Nutrition" className="mt-4">
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-5">
            {(["calories", "protein_g", "carbs_g", "fat_g", "fiber_g"] as const).map(k => (
              <label key={k} className="block">
                <span className="mb-1 block text-[10px] uppercase tracking-widest text-muted-foreground">{k}</span>
                <input
                  type="number"
                  value={(form.nutrition as any)?.[k] ?? 0}
                  onChange={e =>
                    update("nutrition", { ...(form.nutrition ?? {}), [k]: Number(e.target.value) } as any)
                  }
                  className={inputCls}
                />
              </label>
            ))}
          </div>
        </Field>

        <Field label="Tags (comma separated)" className="mt-4">
          <input
            value={(form.tags ?? []).join(", ")}
            onChange={e => update("tags", e.target.value.split(",").map(t => t.trim()).filter(Boolean))}
            className={inputCls}
          />
        </Field>

        <div className="hairline mt-6 flex flex-wrap gap-4 pt-4">
          <label className="inline-flex items-center gap-2 text-sm font-medium">
            <input type="checkbox" checked={!!form.featured} onChange={e => update("featured", e.target.checked)} className="h-4 w-4 accent-[var(--gold)]" />
            Featured
          </label>
          <label className="inline-flex items-center gap-2 text-sm font-medium">
            <input type="checkbox" checked={!!form.published} onChange={e => update("published", e.target.checked)} className="h-4 w-4 accent-[var(--india-green)]" />
            Published
          </label>
        </div>

        <div className="sticky bottom-0 -mx-6 -mb-6 mt-6 flex justify-end gap-2 border-t border-[color-mix(in_oklab,var(--gold)_16%,transparent)] bg-[color-mix(in_oklab,var(--card)_92%,transparent)] px-6 py-4 backdrop-blur">
          <button onClick={onClose} className="btn-quiet touch-manipulation rounded-full px-5 py-2.5 text-sm font-semibold">
            Cancel
          </button>
          <button
            onClick={save}
            disabled={saving}
            className="btn-gold inline-flex touch-manipulation items-center gap-2 rounded-full px-6 py-2.5 text-sm font-semibold disabled:opacity-60"
          >
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
            {isNew ? "Create" : "Save changes"}
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

// ──────────────────────────────────────────────────────────────────────
// Bulk import modal
// ──────────────────────────────────────────────────────────────────────

function BulkImportModal({ onClose }: { onClose: () => void }) {
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);

  async function run() {
    setBusy(true);
    try {
      const parsed = JSON.parse(text);
      if (!Array.isArray(parsed)) throw new Error("Expected a JSON array of recipes");
      const rows = parsed.map((r: any) => ({
        slug: r.slug || slugify(r.name || ""),
        name: r.name,
        state: r.state || "Other",
        region: r.region || "Other",
        category: r.category || "Main Course",
        description: r.description || "",
        prep_time: r.prep_time || "15 mins",
        cook_time: r.cook_time || "30 mins",
        difficulty: r.difficulty || "Medium",
        ingredients: r.ingredients || [],
        steps: r.steps || [],
        nutrition: r.nutrition || {},
        tags: r.tags || [],
        featured: !!r.featured,
        published: r.published !== false,
        image_url: r.image_url ?? null,
        video_url: r.video_url ?? null,
      }));
      const { error } = await supabase.from("recipes").upsert(rows, { onConflict: "slug" });
      if (error) throw error;
      toast.success(`Imported ${rows.length} recipes`);
      onClose();
    } catch (e: any) {
      toast.error(e.message ?? "Import failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-[oklch(0.1_0.02_38/0.66)] p-4 backdrop-blur"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.96, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.96, y: 20 }}
        onClick={e => e.stopPropagation()}
        className="w-full max-w-2xl rounded-3xl border border-[color-mix(in_oklab,var(--gold)_18%,transparent)] bg-card p-6 shadow-[var(--shadow-card)]"
      >
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-2xl">Bulk import recipes</h2>
          <button onClick={onClose} className="btn-quiet grid h-9 w-9 touch-manipulation place-items-center rounded-full">
            <X className="h-4 w-4" />
          </button>
        </div>
        <p className="mb-3 text-xs text-muted-foreground">
          Paste a JSON array. Existing slugs are updated; new slugs are inserted.
        </p>
        <textarea
          value={text}
          onChange={e => setText(e.target.value)}
          rows={14}
          placeholder='[{"name":"Dal Bati","category":"Main Course","ingredients":[],"steps":[]}]'
          className="w-full rounded-2xl border border-[color-mix(in_oklab,var(--gold)_18%,transparent)] bg-[color-mix(in_oklab,var(--muted)_45%,var(--card))] p-3 font-mono text-xs outline-none focus:border-primary"
        />
        <div className="mt-4 flex justify-end gap-2">
          <button onClick={onClose} className="btn-quiet touch-manipulation rounded-full px-5 py-2.5 text-sm font-semibold">
            Cancel
          </button>
          <button
            onClick={run}
            disabled={busy || !text.trim()}
            className="btn-gold inline-flex touch-manipulation items-center gap-2 rounded-full px-6 py-2.5 text-sm font-semibold disabled:opacity-60"
          >
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Database className="h-4 w-4" />} Import
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

// ──────────────────────────────────────────────────────────────────────
// Form helpers
// ──────────────────────────────────────────────────────────────────────

const inputCls =
  "w-full rounded-2xl border border-[color-mix(in_oklab,var(--gold)_16%,transparent)] bg-[color-mix(in_oklab,var(--muted)_35%,var(--card))] px-3 py-2.5 text-sm outline-none transition focus:border-[var(--gold)]";

function Field({ label, children, className = "" }: { label: string; children: React.ReactNode; className?: string }) {
  return (
    <label className={`block ${className}`}>
      <span className="mb-1.5 block text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}

function ListField({
  label,
  items,
  onChange,
  placeholder,
  textarea = false,
}: {
  label: string;
  items: string[];
  onChange: (v: string[]) => void;
  placeholder?: string;
  textarea?: boolean;
}) {
  return (
    <div className="mt-4">
      <div className="mb-1 flex items-center justify-between">
        <span className="text-xs font-medium text-muted-foreground">{label}</span>
        <button
          type="button"
          onClick={() => onChange([...items, ""])}
          className="btn-quiet inline-flex touch-manipulation items-center gap-1 rounded-full px-3 py-1 text-[10px] font-semibold"
        >
          <Plus className="h-3 w-3" /> Add
        </button>
      </div>
      <div className="space-y-2">
        {items.map((v, i) => (
          <div key={i} className="flex gap-2">
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl gradient-gold text-xs font-bold text-[oklch(0.24_0.05_46)]">
              {i + 1}
            </span>
            {textarea ? (
              <textarea
                value={v}
                onChange={e => onChange(items.map((x, j) => (j === i ? e.target.value : x)))}
                placeholder={placeholder}
                rows={2}
                className={inputCls}
              />
            ) : (
              <input
                value={v}
                onChange={e => onChange(items.map((x, j) => (j === i ? e.target.value : x)))}
                placeholder={placeholder}
                className={inputCls}
              />
            )}
            <button
              type="button"
              onClick={() => onChange(items.filter((_, j) => j !== i))}
              className="grid h-9 w-9 shrink-0 touch-manipulation place-items-center rounded-xl border border-[color-mix(in_oklab,var(--destructive)_28%,transparent)] text-[var(--destructive)]"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        ))}
        {items.length === 0 && <p className="text-xs text-muted-foreground/70">No items yet — click Add.</p>}
      </div>
    </div>
  );
}
