import { createFileRoute } from "@tanstack/react-router";
import { convertToModelMessages, streamText, tool, stepCountIs, type UIMessage } from "ai";
import { z } from "zod";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway.server";
import { createClient } from "@supabase/supabase-js";

/**
 * Priority AI is a Premium perk. The client cannot claim it: we read the caller's
 * bearer token and check their own profile row through RLS.
 */
async function isPremiumCaller(request: Request): Promise<boolean> {
  const authHeader = request.headers.get("authorization") ?? "";
  const token = authHeader.toLowerCase().startsWith("bearer ") ? authHeader.slice(7).trim() : "";
  if (!token) return false;

  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_PUBLISHABLE_KEY ?? process.env.SUPABASE_ANON_KEY;
  if (!url || !key) return false;

  try {
    const supabase = createClient(url, key, {
      auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
      global: { headers: { Authorization: `Bearer ${token}` } },
    });
    const { data: user } = await supabase.auth.getUser(token);
    if (!user?.user) return false;

    const { data: profile } = await supabase
      .from("profiles")
      .select("is_premium, premium_expiry_date")
      .eq("id", user.user.id)
      .maybeSingle();
    if (profile?.is_premium) {
      const expiry = profile.premium_expiry_date ? new Date(profile.premium_expiry_date).getTime() : 0;
      if (!profile.premium_expiry_date || expiry > Date.now()) return true;
    }

    const { data: adminFlag } = await supabase.rpc("has_role", { _user_id: user.user.id, _role: "admin" });
    return Boolean(adminFlag);
  } catch {
    return false;
  }
}

const FoodCardSchema = z.object({
  food_name: z.string(),
  origin: z.string(),
  category: z.string(),
  diet: z.enum(["Veg", "Non-Veg", "Vegan", "Egg"]),
  main_ingredients: z.array(z.string()),
  cooking_method: z.string(),
  taste_profile: z.array(z.string()),
  calories_per_serving: z.number(),
  nutrition: z.object({
    protein_g: z.number(),
    carbs_g: z.number(),
    fat_g: z.number(),
    fiber_g: z.number(),
  }),
  health_benefits: z.array(z.string()),
  risks_or_allergies: z.array(z.string()),
  best_time_to_eat: z.string(),
  popular_places: z.array(z.string()),
  cultural_background: z.string(),
  similar_foods: z.array(z.string()),
  image_query: z.string(),
});

const SYSTEM_PROMPT = `You are Rasoi AI Chef — an expert on Indian cuisine, nutrition, and food culture.

GUIDELINES:
- Answer warmly, like a knowledgeable Indian home chef.
- When a user asks about ANY specific Indian dish (e.g. "Tell me about Biryani", "Is Butter Chicken healthy?", "What's in Samosa?", "Which state does Dhokla belong to?") you MUST call the \`render_food_card\` tool with a complete structured profile of that dish. After calling the tool, write 1–2 short sentences of context — do not repeat the card's content in prose.
- When the user asks for SUGGESTIONS (weight gain/loss, high-protein, diabetic-friendly, regional sampler), reply with a short markdown list of 4–6 dishes, then call \`render_food_card\` for the TOP 1–2 recommendations.
- When the user picks a state, call \`render_food_card\` for its 1–2 most iconic dishes.
- For general/non-food questions about Indian cuisine (history, festivals, technique), answer in markdown without calling the tool.
- Respond in the same language the user wrote in. If the user writes in Hindi or Hinglish, reply in that language but ALWAYS keep the tool-call fields in English.
- Nutrition values should be realistic per single serving (~150–250g).
- Keep prose concise and friendly. Use markdown for lists.`;

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const { messages } = (await request.json()) as { messages?: UIMessage[] };
          if (!Array.isArray(messages)) {
            return new Response("Messages are required", { status: 400 });
          }

          const key = process.env.LOVABLE_API_KEY;
          if (!key) return new Response("Missing LOVABLE_API_KEY", { status: 500 });

          const gateway = createLovableAiGatewayProvider(key);
          // Premium = priority model (richer + faster tier); free = lite model.
          const priority = await isPremiumCaller(request);
          const model = gateway(priority ? "google/gemini-3-flash-preview" : "google/gemini-3.1-flash-lite");

          const result = streamText({
            model,
            system: SYSTEM_PROMPT,
            messages: await convertToModelMessages(messages),
            // Small step budget = fewer round-trips before streaming resumes.
            stopWhen: stepCountIs(5),
            tools: {
              render_food_card: tool({
                description:
                  "Render a structured food card for a single Indian dish with origin, ingredients, nutrition and culture.",
                inputSchema: FoodCardSchema,
                execute: async (input) => input,
              }),
            },
          });

          return result.toUIMessageStreamResponse({
            originalMessages: messages,
            onError: (error) => {
              console.error("[chat] stream error", error);
              if (error instanceof Error) {
                if (error.message.includes("429")) return "Rate limit reached. Please wait a moment and try again.";
                if (error.message.includes("402")) return "AI credits exhausted. Please add credits to continue.";
                return error.message;
              }
              return "Something went wrong.";
            },
          });
        } catch (err) {
          console.error("[chat] handler error", err);
          return new Response(err instanceof Error ? err.message : "Server error", { status: 500 });
        }
      },
    },
  },
});
