import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import {
  ArrowLeft,
  Clock,
  Flame,
  Heart,
  Share2,
  ChefHat,
  Youtube,
  MapPin,
  Loader2,
  Eye,
  PlayCircle,
  FileDown,
  WifiOff,
  CloudDownload,
  CheckCircle2,
  Crown,
} from "lucide-react";
import { toast } from "sonner";
import { useRecipe, youtubeUrl, type DbRecipe } from "@/lib/recipes";
import { CookingMode } from "@/components/CookingMode";
import { RECIPES } from "@/lib/data";
import { useFavorites } from "@/lib/favorites";
import { RecipeImage, useStorageUrl } from "@/components/RecipeImage";
import { incrementRecipeViews } from "@/lib/views.functions";
import { usePremium } from "@/lib/use-premium";
import { downloadRecipePdf } from "@/lib/recipe-pdf";
import { AdSlot } from "@/components/AdSlot";
import { PremiumGate, PremiumOnlyBadge } from "@/components/PremiumGate";
import {
  cacheRecipeOffline,
  getOfflineRecipe,
  removeOfflineRecipe,
  useOfflineRecipes,
  useOnlineStatus,
  type OfflineRecipe,
} from "@/lib/offline-recipes";

function isPremiumRecipe(recipe: { tags?: string[] }) {
  return (recipe.tags ?? []).some((t) => ["premium", "exclusive", "premium-only"].includes(t.toLowerCase()));
}

function offlineToDb(o: OfflineRecipe): DbRecipe {
  return {
    id: o.id,
    slug: o.slug ?? o.id,
    name: o.name,
    description: o.description,
    state: o.state ?? "India",
    region: "",
    category: o.category ?? "Recipe",
    image_url: o.image_url ?? null,
    prep_time: o.prep_time ?? "—",
    cook_time: o.cook_time ?? "—",
    difficulty: o.difficulty ?? "—",
    ingredients: o.ingredients,
    steps: o.steps,
    nutrition: (o.nutrition ?? {}) as DbRecipe["nutrition"],
    tags: o.tags ?? [],
    featured: false,
    published: true,
    views: 0,
    video_url: null,
  } as unknown as DbRecipe;
}

export const Route = createFileRoute("/recipes/$id")({
  component: RecipeDetail,
  notFoundComponent: () => (
    <div className="panel mx-auto max-w-lg p-10 text-center">
      <h1 className="font-display text-3xl">Recipe not found</h1>
      <Link to="/" className="mt-4 inline-block text-sm font-semibold text-primary">
        Go home
      </Link>
    </div>
  ),
});

function RecipeDetail() {
  const { id } = Route.useParams();
  const { data: dbRecipe, isLoading } = useRecipe(id);
  const staticRecipe = RECIPES.find(r => r.id === id);
  const { isFav, toggle } = useFavorites();
  const online = useOnlineStatus();
  const [cached, setCached] = useState<OfflineRecipe | null>(null);

  useEffect(() => { setCached(getOfflineRecipe(id)); }, [id]);

  // Bump views once per page load (best-effort)
  useEffect(() => {
    if (!dbRecipe?.slug) return;
    const key = `viewed:${dbRecipe.slug}:${Math.floor(Date.now() / (1000 * 60 * 30))}`; // dedupe 30min
    if (sessionStorage.getItem(key)) return;
    sessionStorage.setItem(key, "1");
    incrementRecipeViews({ data: { slug: dbRecipe.slug } }).catch(() => {});
  }, [dbRecipe?.slug]);

  if (!dbRecipe && !staticRecipe && cached) {
    return <DbView recipe={offlineToDb(cached)} fav={isFav(cached.id)} toggle={toggle} offlineCopy />;
  }

  if (isLoading && !staticRecipe) {
    return (
      <div className="space-y-6">
        <div className="skeleton aspect-[16/9] w-full rounded-[1.75rem]" />
        <div className="grid gap-3 sm:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => <div key={i} className="skeleton h-16 rounded-2xl" />)}
        </div>
        <div className="grid gap-6 md:grid-cols-2">
          <div className="skeleton h-64 rounded-3xl" />
          <div className="skeleton h-64 rounded-3xl" />
        </div>
        {!online && (
          <p className="inline-flex items-center gap-1.5 text-sm text-muted-foreground">
            <WifiOff className="h-4 w-4" aria-hidden="true" /> You're offline — only recipes saved for offline use will open.
          </p>
        )}
      </div>
    );
  }

  if (dbRecipe) return <DbView recipe={dbRecipe} fav={isFav(dbRecipe.id)} toggle={toggle} />;
  if (staticRecipe) return <StaticView recipe={staticRecipe} fav={isFav(staticRecipe.id)} toggle={toggle} />;
  throw notFound();
}

function formatViews(n: number) {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}k`;
  return `${n}`;
}

function DbView({
  recipe,
  fav,
  toggle,
  offlineCopy = false,
}: {
  recipe: DbRecipe;
  fav: boolean;
  toggle: (id: string) => void;
  offlineCopy?: boolean;
}) {
  const premium = usePremium();
  const online = useOnlineStatus();
  const { isAvailableOffline } = useOfflineRecipes();
  const savedOffline = offlineCopy || isAvailableOffline(recipe.id);
  const { url: heroUrl } = useStorageUrl(recipe.image_url, "recipe-images");
  const locked = isPremiumRecipe(recipe) && !premium.isPremium;
  const [cooking, setCooking] = useState(false);

  function handlePdf() {
    if (!premium.isPremium) {
      toast.error("Recipe PDF download is a Premium feature.");
      return;
    }
    try {
      downloadRecipePdf(
        {
          name: recipe.name,
          description: recipe.description,
          state: recipe.state,
          category: recipe.category,
          prep_time: recipe.prep_time,
          cook_time: recipe.cook_time,
          difficulty: recipe.difficulty,
          ingredients: recipe.ingredients,
          steps: recipe.steps,
          nutrition: recipe.nutrition as Record<string, number | string | null> | null,
        },
        heroUrl,
      );
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not open the PDF sheet.");
    }
  }

  function handleOffline() {
    if (!premium.isPremium) {
      toast.error("Offline recipe access is a Premium feature.");
      return;
    }
    if (savedOffline) {
      removeOfflineRecipe(recipe.id);
      toast("Removed from offline recipes");
      return;
    }
    cacheRecipeOffline({
      id: recipe.id,
      slug: recipe.slug,
      name: recipe.name,
      description: recipe.description,
      state: recipe.state,
      category: recipe.category,
      image_url: heroUrl ?? recipe.image_url,
      prep_time: recipe.prep_time,
      cook_time: recipe.cook_time,
      difficulty: recipe.difficulty,
      ingredients: recipe.ingredients,
      steps: recipe.steps,
      nutrition: recipe.nutrition as Record<string, number | string | null> | null,
      tags: recipe.tags,
    });
    toast.success("Saved for offline cooking 📶");
  }

  return (
    <div className="space-y-8">
      <Link to="/" className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground transition hover:text-foreground">
        <ArrowLeft className="h-4 w-4" aria-hidden="true" /> Back
      </Link>

      <motion.div
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ type: "spring", stiffness: 200, damping: 26 }}
        className="relative min-h-[440px] overflow-hidden rounded-[1.25rem] shadow-[var(--shadow-lift)] sm:aspect-[21/10] sm:min-h-0 sm:rounded-[1.75rem]"
      >
        <RecipeImage src={recipe.image_url} alt={recipe.name} className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 scrim" />
        <div className="absolute right-4 top-4 inline-flex items-center gap-1.5 rounded-full bg-[oklch(0.14_0.02_38/0.5)] px-3 py-1.5 text-xs font-semibold text-[oklch(0.98_0.01_88)] backdrop-blur-md">
          <Eye className="h-3.5 w-3.5" aria-hidden="true" /> {formatViews(recipe.views)} views
        </div>
        <div className="absolute inset-x-0 bottom-0 p-4 text-[oklch(0.98_0.01_88)] min-[390px]:p-5 sm:p-10">
          <p className="eyebrow !text-[oklch(0.92_0.03_82)]">{recipe.state} · {recipe.category}</p>
          <div className="mt-2 flex flex-wrap items-center gap-2 text-xs">
            {recipe.featured && (
              <span className="rounded-full bg-[var(--saffron)] px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide text-[oklch(0.2_0.04_44)]">Featured</span>
            )}
          </div>
          <motion.h1
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="mt-3 font-display text-3xl leading-[1.02] min-[390px]:text-4xl sm:text-6xl"
          >
            {recipe.name}
          </motion.h1>
          <p className="mt-3 max-w-2xl text-sm opacity-85 sm:text-base">{recipe.description}</p>
        </div>
      </motion.div>

      <div className="flex flex-wrap items-center gap-2">
        {savedOffline && (
          <span className="inline-flex items-center gap-1.5 rounded-full bg-[color-mix(in_oklab,var(--india-green)_16%,transparent)] px-3 py-1 text-xs font-semibold text-[var(--india-green)]">
            <CheckCircle2 className="h-3.5 w-3.5" aria-hidden="true" /> Available offline
          </span>
        )}
        {!online && (
          <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-500/15 px-3 py-1 text-xs font-semibold text-amber-700">
            <WifiOff className="h-3.5 w-3.5" aria-hidden="true" /> Offline mode
          </span>
        )}
        {isPremiumRecipe(recipe) && <PremiumOnlyBadge label="Premium recipe" />}
      </div>

      {recipe.video_url && !locked && <ChefVideo src={recipe.video_url} title={recipe.name} />}

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat icon={<Clock className="h-4 w-4" aria-hidden="true" />} label="Prep" value={recipe.prep_time} />
        <Stat icon={<Clock className="h-4 w-4" aria-hidden="true" />} label="Cook" value={recipe.cook_time} />
        <Stat icon={<Flame className="h-4 w-4" aria-hidden="true" />} label="Difficulty" value={recipe.difficulty} />
        <Stat icon={<ChefHat className="h-4 w-4" aria-hidden="true" />} label="Calories" value={`${recipe.nutrition?.calories ?? "—"} kcal`} />
      </div>

      <div className="grid grid-cols-2 gap-2.5 sm:flex sm:flex-wrap sm:gap-3">
        {!locked && (
          <button
            onClick={() => setCooking(true)}
            className="btn-gold col-span-2 inline-flex min-h-12 items-center justify-center gap-2 rounded-full px-5 py-3 text-sm font-semibold active:scale-95 sm:col-span-1 sm:px-6"
          >
            <ChefHat className="h-4 w-4" aria-hidden="true" /> Start Cooking
          </button>
        )}
        {cooking && (
          <CookingMode
            recipe={{ id: recipe.id, name: recipe.name, steps: recipe.steps ?? [], ingredients: recipe.ingredients ?? [] }}
            onClose={() => setCooking(false)}
          />
        )}
        <button
          onClick={() => toggle(recipe.id)}
          className={`inline-flex min-h-12 items-center justify-center gap-2 rounded-full px-3 py-3 text-center text-sm font-semibold transition active:scale-95 sm:px-6 ${
            fav ? "gradient-warm text-[oklch(0.98_0.01_88)] shadow-[var(--shadow-glow)]" : "btn-quiet"
          }`}
        >
          <Heart className={`h-4 w-4 ${fav ? "fill-current" : ""}`} aria-hidden="true" /> {fav ? "Saved" : "Save recipe"}
        </button>
        <a
          href={youtubeUrl(recipe.name)}
          target="_blank"
          rel="noreferrer noopener"
          className="inline-flex min-h-12 items-center justify-center gap-2 rounded-full bg-red-600 px-3 py-3 text-center text-sm font-semibold text-white shadow-lg transition hover:scale-[1.02] active:scale-95 sm:px-6"
        >
          <Youtube className="h-4 w-4" aria-hidden="true" /> Watch on YouTube
        </a>
        <button
          onClick={() => navigator.share?.({ title: recipe.name, text: recipe.description }).catch(() => {})}
          className="btn-quiet inline-flex min-h-12 items-center justify-center gap-2 rounded-full px-3 py-3 text-sm font-semibold sm:px-6"
        >
          <Share2 className="h-4 w-4" aria-hidden="true" /> Share
        </button>
        <button
          onClick={handlePdf}
          className="btn-quiet inline-flex min-h-12 items-center justify-center gap-2 rounded-full px-3 py-3 text-center text-sm font-semibold sm:px-6"
        >
          {premium.isPremium ? <FileDown className="h-4 w-4" aria-hidden="true" /> : <Crown className="h-4 w-4 text-[var(--gold)]" aria-hidden="true" />} Download PDF
        </button>
        <button
          onClick={handleOffline}
          className="btn-quiet inline-flex min-h-12 items-center justify-center gap-2 rounded-full px-3 py-3 text-center text-sm font-semibold sm:px-6"
        >
          {premium.isPremium ? (
            savedOffline ? <CheckCircle2 className="h-4 w-4 text-[var(--india-green)]" aria-hidden="true" /> : <CloudDownload className="h-4 w-4" aria-hidden="true" />
          ) : (
            <Crown className="h-4 w-4 text-[var(--gold)]" aria-hidden="true" />
          )}{" "}
          {savedOffline ? "Saved offline" : "Save offline"}
        </button>
      </div>

      <AdSlot />

      {locked ? (
        <PremiumGate
          title="This is an exclusive Premium recipe"
          description="Unlock the full ingredient list, step-by-step method, chef video and PDF download with Bharat Rasoi Premium."
        >
          <div />
        </PremiumGate>
      ) : (
      <div className="grid gap-6 md:grid-cols-2">
        <section className="panel p-6 sm:p-8">
          <p className="eyebrow">Recipe</p>
          <div className="mt-1 flex flex-wrap items-center justify-between gap-2">
            <h2 className="font-display text-2xl">Ingredients</h2>

          </div>
          <ul className="mt-5 space-y-3">
            {recipe.ingredients.map((i, idx) => (
              <li key={idx} className="flex items-start gap-3 border-b border-[color-mix(in_oklab,var(--gold)_14%,transparent)] pb-3 text-sm leading-relaxed last:border-0 last:pb-0">
                <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-[var(--gold)]" />
                {i}
              </li>
            ))}
          </ul>
        </section>

        <section className="panel p-6 sm:p-8">
          <p className="eyebrow">Method</p>
          <h2 className="mt-1 font-display text-2xl">Instructions</h2>
          <ol className="mt-5 space-y-5">
            {recipe.steps.map((s, i) => (
              <li key={i} className="flex gap-4 border-b border-[color-mix(in_oklab,var(--gold)_14%,transparent)] pb-5 text-sm leading-relaxed last:border-0 last:pb-0">
                <span className="shrink-0 font-display text-2xl leading-none text-[var(--gold)]">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <span className="pt-1">{s}</span>
              </li>
            ))}
          </ol>
        </section>
      </div>
      )}

      {!locked && recipe.nutrition && Object.keys(recipe.nutrition).length > 0 && (
        <section className="panel p-6 sm:p-8">
          <p className="eyebrow">Per serving</p>
          <h2 className="mt-1 font-display text-2xl">Nutrition</h2>
          <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-5">
            <NutritionStat label="Calories" value={`${recipe.nutrition.calories ?? "—"}`} unit="kcal" />
            <NutritionStat label="Protein" value={`${recipe.nutrition.protein_g ?? "—"}`} unit="g" />
            <NutritionStat label="Carbs" value={`${recipe.nutrition.carbs_g ?? "—"}`} unit="g" />
            <NutritionStat label="Fat" value={`${recipe.nutrition.fat_g ?? "—"}`} unit="g" />
            <NutritionStat label="Fiber" value={`${recipe.nutrition.fiber_g ?? "—"}`} unit="g" />
          </div>
        </section>
      )}

      {recipe.tags.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {recipe.tags.map(t => (
            <span key={t} className="rounded-full border border-[color-mix(in_oklab,var(--gold)_18%,transparent)] bg-card px-3 py-1 text-xs text-muted-foreground">
              #{t}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

function ChefVideo({ src, title }: { src: string; title: string }) {
  const { url, failed } = useStorageUrl(src, "recipe-videos");
  const [ready, setReady] = useState(false);
  if (failed) return null;
  return (
    <motion.section
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      className="panel-dark overflow-hidden p-3 sm:p-4"
    >
      <div className="mb-3 flex items-center gap-2 px-2">
        <span className="grid h-8 w-8 place-items-center rounded-lg bg-red-600 text-white">
          <PlayCircle className="h-4 w-4" aria-hidden="true" />
        </span>
        <h2 className="font-display text-xl">Chef's video tutorial</h2>
      </div>
      <div className="relative aspect-video overflow-hidden rounded-2xl bg-black">
        {!url && (
          <div className="absolute inset-0 grid place-items-center">
            <Loader2 className="h-8 w-8 animate-spin text-white/70" aria-hidden="true" />
          </div>
        )}
        {url && (
          <video
            src={url}
            controls
            playsInline
            onCanPlay={() => setReady(true)}
            className={`absolute inset-0 h-full w-full transition-opacity duration-500 ${ready ? "opacity-100" : "opacity-0"}`}
            aria-label={`${title} video tutorial`}
          />
        )}
      </div>
    </motion.section>
  );
}

function StaticView({ recipe, fav, toggle }: { recipe: (typeof RECIPES)[number]; fav: boolean; toggle: (id: string) => void }) {
  return (
    <div className="space-y-8">
      <Link to="/" className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground transition hover:text-foreground">
        <ArrowLeft className="h-4 w-4" aria-hidden="true" /> Back
      </Link>
      <motion.div
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        className="relative min-h-[420px] overflow-hidden rounded-[1.25rem] shadow-[var(--shadow-lift)] sm:aspect-[21/10] sm:min-h-0 sm:rounded-[1.75rem]"
      >
        <img src={recipe.image} alt={recipe.name} className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 scrim" />
        <div className="absolute inset-x-0 bottom-0 p-4 text-[oklch(0.98_0.01_88)] min-[390px]:p-5 sm:p-10">
          <p className="eyebrow !text-[oklch(0.92_0.03_82)]">{recipe.state}</p>
          <h1 className="mt-2 font-display text-3xl leading-[1.02] min-[390px]:text-4xl sm:text-6xl">{recipe.name}</h1>
          <p className="mt-3 max-w-2xl text-sm opacity-85 sm:text-base">{recipe.description}</p>
        </div>
      </motion.div>
      <div className="flex flex-wrap gap-3">
        <button
          onClick={() => toggle(recipe.id)}
          className={`inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-semibold transition active:scale-95 ${fav ? "gradient-warm text-[oklch(0.98_0.01_88)] shadow-[var(--shadow-glow)]" : "btn-quiet"}`}
        >
          <Heart className={`h-4 w-4 ${fav ? "fill-current" : ""}`} aria-hidden="true" /> {fav ? "Saved" : "Save recipe"}
        </button>
        <a
          href={youtubeUrl(recipe.name)}
          target="_blank"
          rel="noreferrer noopener"
          className="inline-flex items-center gap-2 rounded-full bg-red-600 px-6 py-3 text-sm font-semibold text-white shadow-lg"
        >
          <Youtube className="h-4 w-4" aria-hidden="true" /> YouTube
        </a>
      </div>
      <div className="grid gap-6 md:grid-cols-2">
        <section className="panel p-6 sm:p-8">
          <p className="eyebrow">Recipe</p>
          <h2 className="mt-1 font-display text-2xl">Ingredients</h2>
          <ul className="mt-5 space-y-3">
            {recipe.ingredients.map(i => (
              <li key={i} className="flex items-start gap-3 border-b border-[color-mix(in_oklab,var(--gold)_14%,transparent)] pb-3 text-sm leading-relaxed last:border-0 last:pb-0">
                <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-[var(--gold)]" />
                {i}
              </li>
            ))}
          </ul>
        </section>
        <section className="panel p-6 sm:p-8">
          <p className="eyebrow">Method</p>
          <h2 className="mt-1 font-display text-2xl">Instructions</h2>
          <ol className="mt-5 space-y-5">
            {recipe.steps.map((s, i) => (
              <li key={i} className="flex gap-4 border-b border-[color-mix(in_oklab,var(--gold)_14%,transparent)] pb-5 text-sm leading-relaxed last:border-0 last:pb-0">
                <span className="shrink-0 font-display text-2xl leading-none text-[var(--gold)]">{String(i + 1).padStart(2, "0")}</span>
                <span className="pt-1">{s}</span>
              </li>
            ))}
          </ol>
        </section>
      </div>
    </div>
  );
}

function Stat({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-[color-mix(in_oklab,var(--gold)_16%,transparent)] bg-card p-3.5 shadow-[var(--shadow-soft)]">
      <div className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
        {icon}
        {label}
      </div>
      <div className="mt-1 font-display text-xl">{value}</div>
    </div>
  );
}

function NutritionStat({ label, value, unit }: { label: string; value: string; unit: string }) {
  return (
    <div className="rounded-2xl border border-[color-mix(in_oklab,var(--gold)_14%,transparent)] bg-background/50 p-3 text-center">
      <div className="font-display text-2xl text-gradient">
        {value} <span className="text-xs font-medium text-muted-foreground">{unit}</span>
      </div>
      <div className="mt-1 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">{label}</div>
    </div>
  );
}
