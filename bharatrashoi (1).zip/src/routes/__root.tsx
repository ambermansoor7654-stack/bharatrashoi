import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { Navbar } from "@/components/Navbar";
import { BottomNav } from "@/components/BottomNav";
import { RouteProgress } from "@/components/RouteProgress";
import { Toaster } from "@/components/ui/sonner";
import { AuthProvider } from "@/lib/auth";
import { CommunityActivity } from "@/components/CommunityActivity";
import { setupPwa } from "@/lib/pwa";

function NotFoundComponent() {
  return (
    <div className="flex min-h-[70vh] items-center justify-center px-4">
      <div className="panel reveal max-w-md p-10 text-center">
        <span className="eyebrow">Off the menu</span>
        <h1 className="mt-3 font-display text-7xl text-gradient">404</h1>
        <p className="mt-3 text-sm text-muted-foreground">We couldn&apos;t plate this page. Let&apos;s head back to the kitchen.</p>
        <a href="/" className="btn-gold mt-7 inline-flex min-h-11 items-center rounded-full px-6 py-2.5 text-sm font-semibold">Back to kitchen</a>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: unknown; reset: () => void }) {
  const router = useRouter();
  const normalizedError = error instanceof Error ? error : new Error(String(error));
  useEffect(() => { reportLovableError(normalizedError, { boundary: "tanstack_root_error_component" }); }, [normalizedError]);
  return (
    <div className="flex min-h-[70vh] items-center justify-center px-4">
      <div className="panel reveal max-w-md p-10 text-center">
        <span className="eyebrow">Something burnt</span>
        <h1 className="mt-3 font-display text-3xl">A dish didn&apos;t come out right</h1>
        <p className="mt-3 text-sm text-muted-foreground">{normalizedError.message}</p>
        <button
          onClick={() => { router.invalidate(); reset(); }}
          className="btn-gold mt-7 min-h-11 rounded-full px-6 py-2.5 text-sm font-semibold"
        >Try again</button>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { name: "theme-color", content: "#211712" },
      { name: "apple-mobile-web-app-capable", content: "yes" },
      { name: "apple-mobile-web-app-status-bar-style", content: "black-translucent" },
      { name: "apple-mobile-web-app-title", content: "Bharat Rasoi" },
      { name: "google-site-verification", content: "cX3nLyTnWsvp3BKGQq90lUF554CRPVET1a9eMtULwMI" },
      { title: "Bharat Rasoi — Taste of India" },
      { name: "description", content: "Stream and cook authentic recipes from every Indian state." },
      { property: "og:title", content: "Bharat Rasoi — Taste of India" },
      { property: "og:description", content: "Stream and cook authentic recipes from every Indian state." },
      { property: "og:type", content: "website" },
      { name: "twitter:title", content: "Bharat Rasoi — Taste of India" },
      { name: "twitter:description", content: "Stream and cook authentic recipes from every Indian state." },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/manifest.webmanifest" },
      { rel: "icon", href: "/icons/icon-192.png", type: "image/png" },
      { rel: "apple-touch-icon", href: "/icons/apple-touch-icon.png" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Work+Sans:wght@300;400;500;600;700&display=swap" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head><HeadContent /></head>
      <body>{children}<Scripts /></body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  useEffect(() => {
    void setupPwa();
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <CommunityActivity />
        <a href="#main-content" className="skip-link">Skip to content</a>
        <div className="min-h-dvh overflow-x-clip pb-[calc(6.5rem+env(safe-area-inset-bottom))] md:pb-8">
          <RouteProgress />
          <Navbar />
          <main id="main-content" tabIndex={-1} className="mx-auto max-w-[1400px] px-3.5 py-4 focus:outline-none min-[390px]:px-4 sm:px-6 sm:py-6 lg:px-10 lg:py-10">
            <Outlet />
          </main>
          <BottomNav />
          <Toaster position="top-center" />
        </div>
      </AuthProvider>
    </QueryClientProvider>
  );
}
