import { createFileRoute, redirect } from "@tanstack/react-router";
export const Route = createFileRoute("/grocery")({ beforeLoad: () => { throw redirect({ to: "/favorites", replace: true }); } });
