import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Award, BookOpen, Heart, ChevronRight, Flame, Loader2, LogOut, Users, UserPlus, ThumbsUp, ListChecks, Utensils, Video } from "lucide-react";
import { useFavorites } from "@/lib/favorites";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { usePremium } from "@/lib/use-premium";
import { PremiumBadge, VerifiedBadge } from "@/components/PremiumBadges";
import { Crown, Settings2 } from "lucide-react";
import { daysLeft, formatDate } from "@/lib/premium";
import { useProfileStats } from "@/lib/social";
import { useCookingActivity, weekGrid } from "@/lib/cooking-activity";

export const Route = createFileRoute("/profile")({
  head: () => ({
    meta: [
      { title: "Profile — Bharat Rasoi" },
      { name: "description", content: "Your Bharat Rasoi cooking dashboard: stats, streaks and badges." },
      { property: "og:title", content: "Profile — Bharat Rasoi" },
      { property: "og:description", content: "Your cooking streak, badges and stats on Bharat Rasoi." },
      { property: "og:type", content: "profile" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ProfilePage,
});

function ProfilePage() {
  const { favorites } = useFavorites();
  const { user, loading, isAdmin } = useAuth();
  const premium = usePremium();
  const pstats = useProfileStats(user?.id);
  const activity = useCookingActivity({
    saves: pstats.data?.saved_count ?? favorites.length,
    likes: pstats.data?.likes_received ?? 0,
    recipes: pstats.data?.recipes_count ?? 0,
  });

  if (loading) {
    return (
      <div className="grid place-items-center py-20">
        <Loader2 className="h-8 w-8 animate-spin text-[var(--gold)]" />
      </div>
    );
  }

  const displayName =
    user?.user_metadata?.full_name ||
    user?.user_metadata?.name ||
    user?.email?.split("@")[0] ||
    user?.phone ||
    "Bharat Rasoi User";
  const avatar = user?.user_metadata?.avatar_url || user?.user_metadata?.picture;
  const initials = displayName.split(" ").map((p: string) => p[0]).join("").slice(0, 2).toUpperCase();

  const s = pstats.data;
  const stats = [
    { label: "Saved", value: s?.saved_count ?? favorites.length, icon: Heart },
    { label: "Cooked", value: activity.cookedTotal, icon: Flame },
    { label: "Badges", value: activity.earnedCount, icon: Award },
  ];
  const lvl = activity.level;
  const lvlPct = lvl.next ? Math.min(100, Math.round(((activity.points - lvl.min) / (lvl.next - lvl.min)) * 100)) : 100;
  const week = weekGrid(activity.days);
  const cards = [
    { label: "Followers", value: s?.followers ?? 0, icon: Users },
    { label: "Following", value: s?.following ?? 0, icon: UserPlus },
    { label: "Recipes", value: s?.recipes_count ?? 0, icon: BookOpen },
    { label: "Likes received", value: s?.likes_received ?? 0, icon: ThumbsUp },
    { label: "Steps done", value: activity.stepsCompleted, icon: ListChecks },
    { label: "Unique dishes", value: activity.uniqueCooked, icon: Utensils },
  ];

  const menu = [
    { label: "My channel", icon: Video, desc: "Share your cooking videos", to: "/channels" as const },
    { label: "Saved Recipes", icon: Heart, desc: "Your favourite dishes", to: "/favorites" as const },
  ];

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="panel relative overflow-hidden p-4 min-[390px]:p-5 sm:p-8"
      >
        <div className="absolute inset-0 -z-10 opacity-40" style={{ backgroundImage: "var(--gradient-glow)" }} />
        <div className="grid grid-cols-[auto_minmax(0,1fr)] items-center gap-4">
          <div className="relative shrink-0">
            <div className="absolute -inset-1 rounded-full bg-[var(--gradient-gold)] opacity-80 blur-[1px]" aria-hidden />
            <div className="relative grid h-16 w-16 place-items-center overflow-hidden rounded-full border-2 border-card bg-card font-display text-xl text-[var(--spice)] shadow-[var(--shadow-soft)] min-[390px]:h-20 min-[390px]:w-20 min-[390px]:text-2xl">
              {avatar ? (
                <img src={avatar} alt={displayName} className="h-full w-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                initials
              )}
            </div>
          </div>
          <div className="min-w-0">
            <h1 className="flex min-w-0 items-center gap-1.5 font-display text-xl min-[390px]:text-2xl sm:text-3xl">
              <span className="truncate">{displayName}</span>
              {premium.verified && <VerifiedBadge className="h-5 w-5" />}
            </h1>
            <p className="truncate text-sm text-muted-foreground">{user?.email ?? user?.phone ?? "Signed in"}</p>
            <div className="mt-2 inline-flex max-w-full items-center gap-1 rounded-full border border-[color-mix(in_oklab,var(--gold)_18%,transparent)] bg-card/60 px-2.5 py-0.5 text-[10px] font-semibold">
              <Award className="h-3 w-3 shrink-0 text-[var(--saffron)]" /> <span className="truncate">{isAdmin ? "Admin Chef · Welcome Amber" : "Masala Explorer"}</span>
            </div>
            {premium.isPremium && (
              <div className="mt-2">
                <PremiumBadge label={premium.isAdmin ? "Premium · Lifetime" : `Premium · ${daysLeft(premium.expiryDate)}d left`} />
              </div>
            )}
          </div>
        </div>

        <div className="mt-6 grid grid-cols-3 divide-x divide-[color-mix(in_oklab,var(--gold)_14%,transparent)] rounded-2xl border border-[color-mix(in_oklab,var(--gold)_14%,transparent)] bg-card/50">
          {stats.map(s => (
            <div key={s.label} className="min-w-0 p-2 text-center min-[390px]:p-3">
              <s.icon className="mx-auto h-4 w-4 text-[var(--spice)]" />
              <div className="mt-1 font-display text-xl">{s.value}</div>
              <div className="truncate text-[9px] uppercase text-muted-foreground min-[390px]:text-[10px] min-[390px]:tracking-widest">{s.label}</div>
            </div>
          ))}
        </div>
      </motion.div>

      <section className="grid gap-2 sm:grid-cols-2">
        <Link
          to="/premium"
          className="card-lift flex items-center gap-3 rounded-2xl border border-[color-mix(in_oklab,var(--gold)_28%,transparent)] bg-[color-mix(in_oklab,var(--gold)_10%,transparent)] p-4"
        >
          <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-[var(--gradient-gold)]">
            <Crown className="h-5 w-5 text-[oklch(0.24_0.05_46)]" />
          </div>
          <div className="min-w-0">
            <div className="font-semibold">{premium.isPremium ? "Premium active" : "Go Premium"}</div>
            <div className="truncate text-xs text-muted-foreground">
              {premium.isAdmin
                ? "Lifetime access"
                : premium.isPremium
                  ? `Valid till ${formatDate(premium.expiryDate)}`
                  : "Unlimited AI recipes, no ads · from ₹99"}
            </div>
          </div>
        </Link>
        <Link to="/settings" className="card-lift panel flex items-center gap-3 p-4">
          <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl" style={{ backgroundImage: "var(--gradient-warm)" }}>
            <Settings2 className="h-5 w-5 text-[oklch(0.98_0.01_88)]" />
          </div>
          <div className="min-w-0">
            <div className="font-semibold">Settings</div>
            <div className="truncate text-xs text-muted-foreground">Subscription, verification & account</div>
          </div>
        </Link>
      </section>

      <section className="grid gap-4 md:grid-cols-2">
        <div className="panel p-4 min-[390px]:p-5 sm:p-6">
          <p className="eyebrow">Level</p>
          <div className="mt-1 flex items-baseline justify-between">
            <h2 className="font-display text-2xl">{lvl.name}</h2>
            <span className="text-sm font-semibold text-[var(--saffron)]">{activity.points} pts</span>
          </div>
          <div className="mt-3 h-2.5 overflow-hidden rounded-full bg-muted">
            <motion.div className="h-full bg-[var(--gradient-gold)]" initial={{ width: 0 }} animate={{ width: `${lvlPct}%` }} />
          </div>
          <p className="mt-2 text-xs text-muted-foreground">
            {lvl.next ? `${lvl.next - activity.points} pts to next level` : "Top level reached 🎉"}
          </p>
        </div>
        <div className="panel p-4 min-[390px]:p-5 sm:p-6">
          <p className="eyebrow">Cooking streak</p>
          <div className="mt-1 flex items-baseline gap-3">
            <h2 className="font-display text-2xl">{activity.streak} day{activity.streak === 1 ? "" : "s"} 🔥</h2>
            <span className="text-xs text-muted-foreground">Best: {activity.longestStreak}</span>
          </div>
          <div className="mt-4 grid grid-cols-7 gap-1 min-[390px]:gap-2">
            {week.map((d) => (
              <div key={d.key} className="text-center">
                <div
                  title={d.key}
                  className={`mx-auto aspect-square w-full max-w-9 rounded-lg border min-[390px]:rounded-xl ${d.active ? "border-transparent bg-[var(--gradient-warm)] shadow-[var(--shadow-glow)]" : "border-[color-mix(in_oklab,var(--gold)_20%,transparent)] bg-card/50"}`}
                  style={d.active ? { backgroundImage: "var(--gradient-warm)" } : undefined}
                  aria-label={`${d.key}: ${d.active ? "cooked" : "not cooked"}`}
                />
                <div className="mt-1 text-[10px] text-muted-foreground">{d.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {cards.map((c) => (
          <div key={c.label} className="panel min-w-0 p-3 min-[390px]:p-4">
            <c.icon className="h-4 w-4 text-[var(--spice)]" aria-hidden="true" />
            <div className="mt-2 font-display text-2xl">{c.value}</div>
            <div className="break-words text-[11px] leading-tight text-muted-foreground min-[390px]:text-xs">{c.label}</div>
          </div>
        ))}
      </section>

      <section className="panel p-6">
        <div className="flex items-baseline justify-between">
          <h2 className="font-display text-2xl">Badges</h2>
          <span className="text-xs text-muted-foreground">{activity.earnedCount}/{activity.badges.length} earned</span>
        </div>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          {activity.badges.map((b) => (
            <div
              key={b.id}
              className={`flex items-center gap-3 rounded-2xl border p-3 ${b.earned ? "border-[color-mix(in_oklab,var(--gold)_45%,transparent)] bg-[color-mix(in_oklab,var(--gold)_10%,transparent)]" : "border-[color-mix(in_oklab,var(--gold)_14%,transparent)] opacity-80"}`}
            >
              <div className={`grid h-10 w-10 shrink-0 place-items-center rounded-full ${b.earned ? "bg-[var(--gradient-gold)]" : "bg-muted"}`} style={b.earned ? { backgroundImage: "var(--gradient-gold)" } : undefined}>
                <Award className={`h-5 w-5 ${b.earned ? "text-[oklch(0.24_0.05_46)]" : "text-muted-foreground"}`} aria-hidden="true" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-sm font-semibold">{b.label}</div>
                <div className="truncate text-[11px] text-muted-foreground">{b.desc}</div>
                <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-muted">
                  <div className="h-full bg-[var(--saffron)]" style={{ width: `${Math.min(100, (b.progress / b.target) * 100)}%` }} />
                </div>
              </div>
              <span className="text-[11px] font-semibold tabular-nums">{Math.min(b.progress, b.target)}/{b.target}</span>
            </div>
          ))}
        </div>
      </section>

      {activity.recent.length > 0 && (
        <section className="panel p-6">
          <h2 className="font-display text-2xl">Recently cooked</h2>
          <ul className="mt-3 space-y-2">
            {activity.recent.map((r) => (
              <li key={r.at}>
                <Link to="/recipes/$id" params={{ id: r.id }} className="flex items-center justify-between rounded-xl px-3 py-2 text-sm hover:bg-[color-mix(in_oklab,var(--gold)_6%,transparent)]">
                  <span className="truncate">{r.name}</span>
                  <span className="text-xs text-muted-foreground">{new Date(r.at).toLocaleDateString()}</span>
                </Link>
              </li>
            ))}
          </ul>
        </section>
      )}

      <section className="panel divide-y divide-[color-mix(in_oklab,var(--gold)_14%,transparent)] overflow-hidden p-0">
        {menu.map((m) => (
          <Link
            key={m.label}
            to={m.to}
            className="flex w-full items-center gap-4 p-4 text-left transition hover:bg-[color-mix(in_oklab,var(--gold)_6%,transparent)]"
          >
            <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl" style={{ backgroundImage: "var(--gradient-warm)" }}>
              <m.icon className="h-5 w-5 text-[oklch(0.98_0.01_88)]" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="font-semibold">{m.label}</div>
              <div className="truncate text-xs text-muted-foreground">{m.desc}</div>
            </div>
            <ChevronRight className="h-4 w-4 text-muted-foreground" />
          </Link>
        ))}
      </section>

      <button
        onClick={() => supabase.auth.signOut()}
        className="inline-flex w-full items-center justify-center gap-2 rounded-full border border-[color-mix(in_oklab,var(--spice)_30%,transparent)] bg-[color-mix(in_oklab,var(--spice)_8%,transparent)] px-6 py-3 text-sm font-semibold text-[var(--spice)] transition hover:bg-[color-mix(in_oklab,var(--spice)_14%,transparent)]"
      >
        <LogOut className="h-4 w-4" /> Sign out
      </button>
    </div>
  );
}
