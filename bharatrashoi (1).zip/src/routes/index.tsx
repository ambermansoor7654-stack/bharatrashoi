import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import { HomeFooter } from "@/components/HomeFooter";
import { Hero } from "@/components/Hero";
import { SearchBar } from "@/components/SearchBar";
import { RecipeCard } from "@/components/RecipeCard";
import { RecipeImage } from "@/components/RecipeImage";
import { RECIPES, STATES } from "@/lib/data";
import { useRecipeFeed, type RecipeFeedItem } from "@/lib/recipes";
import { useAuth } from "@/lib/auth";
import { useFavorites } from "@/lib/favorites";
import { ChevronRight, Clock, Eye, Flame, Heart, IndianRupee, Leaf, MapPin, PlayCircle, Salad, Soup, Sparkles, TrendingUp, Wheat } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Bharat Rasoi — Premium Indian Recipe Discovery" },
      { name: "description", content: "Discover authentic recipes from every Indian state, plated like fine dining, with a live kitchen feed and an AI chef." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:title", content: "Bharat Rasoi — Premium Indian Recipe Discovery" },
      { property: "og:description", content: "Discover authentic recipes from every Indian state, plated like fine dining, with a live kitchen feed and an AI chef." },
    ],
  }),
  component: Home,
});

const CATEGORIES = ["All", "Veg", "Non-Veg", "Dessert", "Snack"] as const;

const QUICK_FILTERS = [
  { label: "Under 30 min", keyword: "min", icon: Clock },
  { label: "Pure Veg", keyword: "veg", icon: Leaf },
  { label: "Curries", keyword: "curry", icon: Soup },
  { label: "Breads", keyword: "roti", icon: Wheat },
  { label: "Light & healthy", keyword: "salad", icon: Salad },
  { label: "Budget friendly", keyword: "dal", icon: IndianRupee },
] as const;

function greeting() {
  const h = new Date().getHours();
  if (h < 5) return "Late night cravings";
  if (h < 12) return "Good morning";
  if (h < 17) return "Good afternoon";
  return "Good evening";
}

function formatViews(n: number) {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}k`;
  return `${n}`;
}

function Home() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<(typeof CATEGORIES)[number]>("All");
  const [quick, setQuick] = useState<string | null>(null);
  const { data: feed } = useRecipeFeed(28);
  const { user } = useAuth();
  const { favorites } = useFavorites();
  const [salutation, setSalutation] = useState("Welcome back");

  useEffect(() => setSalutation(greeting()), []);

  const firstName = ((user?.user_metadata?.["full_name"] as string | undefined) ?? user?.email?.split("@")[0] ?? "Chef")
    .split(" ")[0];

  const filtered = useMemo(() => {
    const ql = q.trim().toLowerCase();
    return RECIPES.filter(r => {
      const haystack = `${r.name} ${r.state} ${r.category} ${r.time} ${r.description} ${r.ingredients.join(" ")}`.toLowerCase();
      return (
        (cat === "All" || r.category === cat) &&
        (!quick || haystack.includes(quick)) &&
        (!ql || haystack.includes(ql))
      );
    });
  }, [q, cat, quick]);

  const popular = useMemo(() => [...(feed ?? [])].sort((a, b) => b.views - a.views).slice(0, 8), [feed]);
  const fresh = useMemo(() => [...(feed ?? [])].slice(0, 8), [feed]);
  const featured = useMemo(() => (feed ?? []).filter(r => r.featured).slice(0, 5), [feed]);

  const recommended = useMemo(() => {
    const list = feed ?? [];
    if (!list.length) return [];
    const likedStates = new Set(
      favorites.map(id => RECIPES.find(r => r.id === id)?.state).filter((s): s is string => Boolean(s)),
    );
    if (!likedStates.size) return list.filter(r => r.featured || r.views > 0).slice(0, 8);
    const matching = list.filter(r => likedStates.has(r.state));
    return [...matching, ...list.filter(r => !likedStates.has(r.state))].slice(0, 8);
  }, [feed, favorites]);

  return (
    <div className="space-y-9 sm:space-y-16">
      <Hero />

      {/* Greeting + AI Chef */}
      <section aria-label="Your kitchen today" className="grid gap-4 lg:grid-cols-[1.2fr_1fr]">
        <div className="panel p-5 sm:p-7">
          <div className="eyebrow">{salutation}</div>
          <h2 className="mt-1.5 font-display text-3xl sm:text-4xl">
            Namaste, {firstName} <span aria-hidden="true">👋</span>
          </h2>
          <p className="mt-2 max-w-md text-sm text-muted-foreground">
            Swaad ghar jaisa, app hamara — pick a state, a mood or a leftover ingredient and we&apos;ll plate the rest.
          </p>
          <div className="mt-5 flex flex-wrap gap-2.5">
            <Link to="/states" className="btn-quiet inline-flex min-h-11 items-center gap-2 rounded-full px-5 text-[13px] font-semibold">
              <MapPin className="h-4 w-4" aria-hidden="true" /> Explore India
            </Link>
            <Link to="/favorites" className="btn-quiet inline-flex min-h-11 items-center gap-2 rounded-full px-5 text-[13px] font-semibold">
              <Heart className="h-4 w-4" aria-hidden="true" /> My collection
            </Link>
          </div>
        </div>

        <Link
          to="/chef"
          className="panel-dark card-lift group relative flex flex-col justify-between overflow-hidden rounded-[1.5rem] p-5 sm:p-7"
        >
          <div>
            <div className="eyebrow !text-[oklch(0.9_0.05_84)]">Rasoi AI Chef</div>
            <h2 className="mt-1.5 font-display text-2xl leading-tight text-[oklch(0.97_0.01_88)] sm:text-3xl">
              Ask anything about Indian food
            </h2>
            <p className="mt-2 text-[13px] leading-relaxed text-[oklch(0.93_0.01_88/0.68)]">
              &ldquo;What can I cook with paneer and peas?&rdquo; — get steps, swaps and nutrition in seconds.
            </p>
          </div>
          <span className="btn-gold mt-6 inline-flex min-h-11 w-fit items-center gap-2 rounded-full px-5 text-[13px] font-semibold">
            <Sparkles className="h-4 w-4" aria-hidden="true" /> Start chatting
          </span>
        </Link>
      </section>

      {/* Search + category filter — the discovery bar */}
      <section aria-label="Search and filter recipes" className="space-y-4">
        <SearchBar value={q} onChange={setQ} placeholder="Search dish, ingredient, state or cuisine…" />
        <div role="group" aria-label="Quick filters" className="rail -mx-1 px-1 pb-1">
          {QUICK_FILTERS.map(({ label, keyword, icon: Icon }) => {
            const active = quick === keyword;
            return (
              <button
                key={label}
                type="button"
                onClick={() => setQuick(active ? null : keyword)}
                aria-pressed={active}
                className={`inline-flex shrink-0 touch-manipulation items-center gap-2 rounded-full px-4 py-2 text-[12.5px] font-medium transition active:scale-95 ${active ? "btn-gold" : "btn-quiet"}`}
              >
                <Icon className="h-3.5 w-3.5" aria-hidden="true" /> {label}
              </button>
            );
          })}
        </div>
        <div role="group" aria-label="Filter by category" className="rail -mx-1 px-1 pb-1">
          {CATEGORIES.map(c => {
            const active = cat === c;
            return (
              <button
                key={c}
                type="button"
                onClick={() => setCat(c)}
                aria-pressed={active}
                className={`shrink-0 touch-manipulation rounded-full px-5 py-2 text-[13px] font-medium transition active:scale-95 ${
                  active
                    ? "btn-ink"
                    : "btn-quiet"
                }`}
              >
                {c}
              </button>
            );
          })}
        </div>
      </section>

      {featured.length > 0 && (
        <section className="panel-dark relative overflow-hidden rounded-[1.75rem] p-5 sm:rounded-[2rem] sm:p-8">
          <SectionHeader dark icon={<Flame className="h-3.5 w-3.5" />} title="Chef's spotlight" subtitle="Featured dishes from the live kitchen" />
          <div className="rail relative -mx-5 px-5 pb-2 sm:-mx-8 sm:px-8">
            {featured.map((r, i) => <CinemaCard key={r.id} recipe={r} rank={i + 1} />)}
          </div>
        </section>
      )}

      <section>
        <SectionHeader icon={<TrendingUp className="h-3.5 w-3.5" />} title="Popular right now" subtitle="Ranked by live views" />
        {popular.length > 0 ? (
          <div className="rail -mx-4 px-4 pb-2 sm:-mx-6 sm:px-6">
            {popular.map((r, i) => <PopularCard key={r.id} recipe={r} rank={i + 1} />)}
          </div>
        ) : (
          <SkeletonRail />
        )}
      </section>

      <section>
        <SectionHeader icon={<Sparkles className="h-3.5 w-3.5" />} title="Fresh from the kitchen" subtitle="New dishes appear here the moment they're published" />
        {fresh.length > 0 ? (
          <div className="grid grid-cols-2 gap-2.5 min-[390px]:gap-3.5 sm:grid-cols-3 sm:gap-4 lg:grid-cols-4 lg:gap-6">
            {fresh.map(r => <FreshCard key={r.id} recipe={r} />)}
          </div>
        ) : (
          <SkeletonGrid />
        )}
      </section>

      {recommended.length > 0 && (
        <section>
          <SectionHeader icon={<Heart className="h-3.5 w-3.5" />} title="Recommended for you" subtitle={favorites.length ? "Picked from the states you keep coming back to" : "Loved by the Bharat Rasoi kitchen"} />
          <div className="rail -mx-4 px-4 pb-2 sm:-mx-6 sm:px-6">
            {recommended.map(r => (
              <div key={r.id} className="w-[224px] shrink-0">
                <FreshCard recipe={r} />
              </div>
            ))}
          </div>
        </section>
      )}

      <section>
        <SectionHeader icon={<MapPin className="h-3.5 w-3.5" />} title="Explore by state" subtitle="28 states, one Other shelf" link="/states" />
        <div className="grid grid-cols-2 gap-2.5 min-[390px]:gap-3 sm:grid-cols-5 sm:gap-4">
          {[...STATES.slice(0, 4), STATES[STATES.length - 1]].map(s => (
            <Link
              key={s.id}
              to="/states"
              className="group card-lift relative h-36 overflow-hidden rounded-[1.25rem] border border-[color-mix(in_oklab,var(--gold)_16%,transparent)] shadow-[var(--shadow-soft)] sm:h-40"
            >
              <div className="media-frame absolute inset-0">
                <img src={s.image} alt={s.name} loading="lazy" className="h-full w-full object-cover" />
              </div>
              <div aria-hidden="true" className={`absolute inset-0 bg-gradient-to-br ${s.color} opacity-40 mix-blend-multiply`} />
              <div aria-hidden="true" className="scrim absolute inset-0" />
              <div className="absolute inset-x-0 bottom-0 p-3.5 text-[oklch(0.98_0.01_88)]">
                <div className="font-display text-lg leading-tight">{s.name}</div>
                <div className="mt-0.5 truncate text-[10px] font-medium uppercase tracking-[0.14em] opacity-80">{s.signature}</div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section>
        <SectionHeader title={q ? `Results for “${q}”` : "Browse the classics"} subtitle={q ? `${filtered.length} dish${filtered.length === 1 ? "" : "es"} found` : "Timeless dishes every Indian kitchen knows"} />
        {filtered.length === 0 ? (
          <div className="panel p-12 text-center">
            <Sparkles className="mx-auto h-6 w-6 text-[var(--gold)]" aria-hidden="true" />
            <h3 className="mt-3 font-display text-xl">Nothing on this shelf</h3>
            <p className="mt-1.5 text-sm text-muted-foreground">Try another dish name or clear the category filter.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2.5 min-[390px]:gap-3.5 sm:grid-cols-3 sm:gap-4 lg:grid-cols-4 lg:gap-6">
            {filtered.map((r, i) => <RecipeCard key={r.id} recipe={r} index={i} />)}
          </div>
        )}
      </section>
      <HomeFooter />
    </div>
  );
}

function CinemaCard({ recipe, rank }: { recipe: RecipeFeedItem; rank: number }) {
  return (
    <Link
      to="/recipes/$id"
      params={{ id: recipe.slug }}
      className="group card-lift relative h-[315px] w-[232px] shrink-0 overflow-hidden rounded-[1.375rem] border border-[oklch(1_0_0/0.12)] sm:h-[340px] sm:w-[252px]"
    >
      <div className="media-frame absolute inset-0">
        <RecipeImage src={recipe.image_url} alt={recipe.name} className="h-full w-full object-cover" />
      </div>
      <div aria-hidden="true" className="scrim absolute inset-0" />
      <div className="absolute left-3.5 top-3.5 grid h-9 w-9 place-items-center rounded-full border border-[oklch(1_0_0/0.3)] bg-[oklch(0.14_0.02_38/0.5)] font-display text-lg text-[oklch(0.95_0.06_84)] backdrop-blur">
        {rank}
      </div>
      <div className="absolute inset-x-0 bottom-0 p-4 text-[oklch(0.98_0.01_88)]">
        <div className="eyebrow !text-[oklch(0.9_0.05_84)]">{recipe.state}</div>
        <h3 className="mt-1.5 font-display text-2xl leading-tight">{recipe.name}</h3>
        <p className="mt-2 line-clamp-2 text-xs leading-relaxed opacity-75">{recipe.description}</p>
      </div>
    </Link>
  );
}

function PopularCard({ recipe, rank }: { recipe: RecipeFeedItem; rank: number }) {
  return (
    <Link
      to="/recipes/$id"
      params={{ id: recipe.slug }}
      className="group card-lift relative block h-[270px] w-[204px] shrink-0 overflow-hidden rounded-[1.25rem] border border-[color-mix(in_oklab,var(--gold)_16%,transparent)] shadow-[var(--shadow-soft)] sm:h-[296px] sm:w-[224px]"
    >
      <div className="media-frame absolute inset-0">
        <RecipeImage src={recipe.image_url} alt={recipe.name} className="h-full w-full object-cover" />
      </div>
      <div aria-hidden="true" className="scrim absolute inset-0" />
      <div className="absolute left-3 top-3 grid h-8 w-8 place-items-center rounded-full bg-[oklch(0.98_0.01_88/0.92)] font-display text-base text-[var(--ink)]">{rank}</div>
      {recipe.video_url && (
        <div className="absolute right-3 top-3 inline-flex items-center gap-1 rounded-full bg-[oklch(0.14_0.02_38/0.6)] px-2 py-1 text-[10px] font-semibold uppercase tracking-[0.12em] text-[oklch(0.98_0.01_88)] backdrop-blur">
          <PlayCircle className="h-3 w-3" aria-hidden="true" /> Video
        </div>
      )}
      <div className="absolute inset-x-0 bottom-0 p-3.5 text-[oklch(0.98_0.01_88)]">
        <div className="text-[10px] font-medium uppercase tracking-[0.16em] opacity-75">{recipe.state}</div>
        <div className="mt-0.5 font-display text-lg leading-tight">{recipe.name}</div>
        <div className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-[oklch(1_0_0/0.14)] px-2.5 py-0.5 text-[10px] font-medium backdrop-blur">
          <Eye className="h-3 w-3" aria-hidden="true" /> {formatViews(recipe.views)} views
        </div>
      </div>
    </Link>
  );
}

function FreshCard({ recipe }: { recipe: RecipeFeedItem }) {
  return (
    <Link
      to="/recipes/$id"
      params={{ id: recipe.slug }}
      className="group card-lift relative block aspect-[3/4] overflow-hidden rounded-[1.25rem] border border-[color-mix(in_oklab,var(--gold)_16%,transparent)] shadow-[var(--shadow-soft)]"
    >
      <div className="media-frame absolute inset-0">
        <RecipeImage src={recipe.image_url} alt={recipe.name} className="h-full w-full object-cover" />
      </div>
      <div aria-hidden="true" className="scrim absolute inset-0" />
      <div className="absolute left-3 top-3 rounded-full bg-[oklch(0.14_0.02_38/0.5)] px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.12em] text-[oklch(0.98_0.01_88)] backdrop-blur">{recipe.category}</div>
      <div className="absolute inset-x-0 bottom-0 p-3.5 text-[oklch(0.98_0.01_88)]">
        <div className="font-display text-base leading-tight">{recipe.name}</div>
        <div className="mt-1 flex items-center justify-between text-[10px] font-medium opacity-80">
          <span className="truncate uppercase tracking-[0.14em]">{recipe.state}</span>
          <span className="inline-flex shrink-0 items-center gap-1"><Eye className="h-3 w-3" aria-hidden="true" /> {formatViews(recipe.views)}</span>
        </div>
      </div>
    </Link>
  );
}

function SkeletonRail() {
  return (
    <div className="-mx-4 flex gap-4 overflow-hidden px-4 pb-2 sm:-mx-6 sm:px-6">
      {Array.from({ length: 4 }).map((_, i) => <div key={i} className="skeleton h-[296px] w-[224px] shrink-0 rounded-[1.25rem]" />)}
    </div>
  );
}

function SkeletonGrid() {
  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 lg:gap-6">
      {Array.from({ length: 8 }).map((_, i) => <div key={i} className="skeleton aspect-[3/4] rounded-[1.25rem]" />)}
    </div>
  );
}

function SectionHeader({ icon, title, subtitle, link, dark }: { icon?: ReactNode; title: string; subtitle?: string; link?: "/states"; dark?: boolean }) {
  return (
    <div className="relative mb-5 flex items-end justify-between gap-4">
      <div className="min-w-0">
        <div className="flex items-center gap-2.5">
          {icon && (
            <span className={`grid h-7 w-7 shrink-0 place-items-center rounded-full ${dark ? "bg-[oklch(1_0_0/0.12)] text-[var(--saffron)]" : "bg-[color-mix(in_oklab,var(--gold)_16%,transparent)] text-[color-mix(in_oklab,var(--gold)_80%,var(--foreground))]"}`}>
              {icon}
            </span>
          )}
          <h2 className={`truncate font-display text-2xl sm:text-[1.75rem] ${dark ? "text-[oklch(0.97_0.01_88)]" : ""}`}>{title}</h2>
        </div>
        {subtitle && (
          <p className={`mt-1.5 text-[12.5px] ${dark ? "text-[oklch(0.93_0.01_88/0.6)]" : "text-muted-foreground"}`}>{subtitle}</p>
        )}
      </div>
      {link && (
        <Link to={link} className="inline-flex shrink-0 touch-manipulation items-center gap-1 text-[12.5px] font-medium text-primary transition hover:gap-2 active:scale-95">
          See all <ChevronRight className="h-3.5 w-3.5" aria-hidden="true" />
        </Link>
      )}
    </div>
  );
}
