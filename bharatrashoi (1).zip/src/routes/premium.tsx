import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { motion, AnimatePresence } from "framer-motion";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  Crown,
  Check,
  X,
  Loader2,
  ShieldCheck,
  Clock,
  Copy,
  Sparkles,
  ArrowRight,
  Smartphone,
  RefreshCw,
  AlertTriangle,
} from "lucide-react";
import {
  PLAN_LIST,
  PLANS,
  PREMIUM_BENEFITS,
  UPI_PAYEE_NAME,
  UPI_QR_URL,
  daysLeft,
  formatDate,
  type PlanId,
} from "@/lib/premium";
import { listMyPayments, submitPaymentRequest } from "@/lib/premium.functions";
import { usePremium, useRefreshPremium } from "@/lib/use-premium";
import { useAuth } from "@/lib/auth";
import { PremiumBadge } from "@/components/PremiumBadges";

export const Route = createFileRoute("/premium")({
  head: () => ({
    meta: [
      { title: "Bharat Rasoi Premium — Unlimited AI Recipes, No Ads" },
      {
        name: "description",
        content:
          "Go Premium on Bharat Rasoi: unlimited AI recipes, ad-free cooking, exclusive state-wise dishes, PDF downloads and offline access from ₹99/month.",
      },
      { property: "og:title", content: "Bharat Rasoi Premium" },
      {
        property: "og:description",
        content: "Unlimited AI recipes, no ads, exclusive Indian dishes and offline access from ₹99/month.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PremiumPage,
});

const COMPARISON = [
  { feature: "Ads", free: "Shown", premium: "None" },
  { feature: "AI recipe generation", free: "5 / day", premium: "Unlimited" },
  { feature: "Saved favorites", free: "Up to 10", premium: "Unlimited" },
  { feature: "Exclusive state recipes", free: false, premium: true },
  { feature: "Recipe PDF download", free: false, premium: true },
  { feature: "Offline access", free: false, premium: true },
  { feature: "Priority AI speed", free: false, premium: true },
  { feature: "Early access features", free: false, premium: true },
];

const STATUS_META = {
  approved: { label: "Approved", cls: "bg-[oklch(0.5_0.11_152/0.16)] text-[var(--india-green)]" },
  rejected: { label: "Rejected", cls: "bg-[oklch(0.55_0.19_28/0.14)] text-[var(--destructive)]" },
  pending: {
    label: "Under review",
    cls: "bg-[color-mix(in_oklab,var(--gold)_20%,transparent)] text-[color-mix(in_oklab,var(--gold)_70%,var(--foreground))]",
  },
} as const;

function PremiumPage() {
  const { user } = useAuth();
  const premium = usePremium();
  const refreshPremium = useRefreshPremium();
  const [plan, setPlan] = useState<PlanId>("yearly");
  const [payOpen, setPayOpen] = useState(false);
  const [prefillReference, setPrefillReference] = useState("");

  const fetchMyPayments = useServerFn(listMyPayments);
  const { data: payments, refetch: refetchPayments } = useQuery({
    queryKey: ["my-payments", user?.id ?? "anon"],
    queryFn: () => fetchMyPayments(),
    enabled: Boolean(user),
  });

  return (
    <div className="space-y-12 pb-10">
      {/* Hero */}
      <motion.section
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        className="panel-dark relative overflow-hidden rounded-[1.25rem] p-5 min-[390px]:p-6 sm:rounded-[2rem] sm:p-12"
      >
        <div
          aria-hidden="true"
          className="absolute inset-0 -z-10 bg-[radial-gradient(120%_120%_at_15%_0%,color-mix(in_oklab,var(--gold)_22%,transparent),transparent_55%),radial-gradient(100%_100%_at_100%_100%,color-mix(in_oklab,var(--india-green)_22%,transparent),transparent_60%)]"
        />

        <div className="flex flex-wrap items-center gap-3">
          <PremiumBadge label="Bharat Rasoi Premium" />
          {premium.isPremium && (
            <span className="inline-flex items-center gap-1 rounded-full bg-[oklch(0.5_0.11_152/0.18)] px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-[oklch(0.75_0.13_150)]">
              <ShieldCheck className="h-3 w-3" /> Active
            </span>
          )}
        </div>

        <h1 className="mt-5 max-w-2xl font-display text-3xl leading-[1.05] min-[390px]:text-4xl sm:text-6xl">
          Cook without limits.{" "}
          <span className="text-gradient">Go Premium.</span>
        </h1>
        <p className="mt-4 max-w-xl text-sm text-[oklch(0.85_0.02_88)] sm:text-base">
          Unlimited AI recipes, zero ads, exclusive regional dishes and offline access — powered by UPI, activated by Amber
          herself.
        </p>

        {premium.isAdmin ? (
          <div className="mt-7 inline-flex items-center gap-2 rounded-2xl border border-[color-mix(in_oklab,var(--gold)_35%,transparent)] bg-[oklch(0_0_0/0.2)] px-4 py-3 text-sm">
            <Crown className="h-4 w-4 text-[var(--gold)]" /> Admin account — permanent Premium, no payment needed.
          </div>
        ) : premium.isPremium ? (
          <div className="mt-7 flex flex-wrap items-center gap-3 text-sm">
            <div className="rounded-2xl border border-[oklch(0.5_0.11_152/0.35)] bg-[oklch(0.5_0.11_152/0.14)] px-4 py-3">
              {PLANS[premium.plan ?? "monthly"].label} plan · expires {formatDate(premium.expiryDate)} ·{" "}
              <strong>{daysLeft(premium.expiryDate)} days left</strong>
            </div>
            <Link to="/settings" className="glass-dark inline-flex items-center gap-1 rounded-full px-4 py-2.5 font-semibold">
              Manage subscription <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        ) : (
          <button
            onClick={() => {
              if (!user) return toast.error("Please sign in first to buy Premium.");
              setPrefillReference("");
              setPayOpen(true);
            }}
            className="btn-gold mt-7 inline-flex items-center gap-2 rounded-full px-7 py-3.5 text-sm font-semibold"
          >
            <Crown className="h-4 w-4" /> Upgrade for {PLANS[plan].price === 99 ? "₹99/month" : "₹799/year"}
          </button>
        )}

        {premium.justExpired && (
          <p className="mt-5 text-sm text-[oklch(0.78_0.14_38)]">
            Your Premium expired. Renew below to keep unlimited access.
          </p>
        )}
      </motion.section>

      {/* Plans */}
      <section className="space-y-5">
        <div>
          <p className="eyebrow">Membership</p>
          <h2 className="mt-1 font-display text-3xl">Choose your plan</h2>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          {PLAN_LIST.map((p) => {
            const active = plan === p.id;
            return (
              <motion.button
                key={p.id}
                whileHover={{ y: -4 }}
                onClick={() => setPlan(p.id)}
                aria-pressed={active}
                className={`card-lift relative overflow-hidden rounded-3xl border p-6 text-left transition ${
                  active
                    ? "border-[var(--gold)] bg-[color-mix(in_oklab,var(--gold)_10%,var(--card))] shadow-[var(--shadow-soft)]"
                    : "panel border-transparent"
                }`}
              >
                {p.popular && (
                  <span className="absolute right-4 top-4 rounded-full gradient-gold px-2.5 py-0.5 text-[10px] font-bold uppercase text-[var(--ink)]">
                    Best value
                  </span>
                )}
                <div className="text-sm font-semibold text-muted-foreground">{p.label}</div>
                <div className="mt-2 flex items-end gap-1">
                  <span className="font-display text-5xl">₹{p.price}</span>
                  <span className="pb-1 text-xs text-muted-foreground">{p.cadence}</span>
                </div>
                <div className="mt-1 text-xs text-muted-foreground">
                  {p.perMonth} {p.save ? `· ${p.save}` : ""}
                </div>
                <div
                  className={`mt-4 inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs font-semibold ${
                    active ? "gradient-gold text-[var(--ink)]" : "btn-quiet"
                  }`}
                >
                  {active ? <Check className="h-3.5 w-3.5" /> : null} {active ? "Selected" : "Select"}
                </div>
              </motion.button>
            );
          })}
        </div>

        {!premium.isPremium && (
          <button
            onClick={() => {
              if (!user) return toast.error("Please sign in first to buy Premium.");
              setPrefillReference("");
              setPayOpen(true);
            }}
            className="btn-gold inline-flex w-full items-center justify-center gap-2 rounded-full px-6 py-4 text-sm font-semibold sm:w-auto"
          >
            <Smartphone className="h-4 w-4" /> Pay ₹{PLANS[plan].price} via UPI QR
          </button>
        )}
      </section>

      {/* Benefits */}
      <section className="space-y-5">
        <div>
          <p className="eyebrow">Why upgrade</p>
          <h2 className="mt-1 font-display text-3xl">What you unlock</h2>
        </div>
        <ul className="grid gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
          {PREMIUM_BENEFITS.map((b) => (
            <li key={b} className="panel flex items-center gap-3 rounded-2xl px-4 py-3.5 text-sm">
              <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-[color-mix(in_oklab,var(--gold)_20%,transparent)]">
                <Check className="h-3.5 w-3.5 text-[color-mix(in_oklab,var(--gold)_75%,var(--foreground))]" />
              </span>
              {b}
            </li>
          ))}
        </ul>
      </section>

      {/* Comparison */}
      <section className="space-y-5">
        <div>
          <p className="eyebrow">Compare</p>
          <h2 className="mt-1 font-display text-3xl">Free vs Premium</h2>
        </div>
        <div className="panel overflow-x-auto rounded-3xl">
          <table className="w-full min-w-[560px] text-sm">
            <thead className="bg-[color-mix(in_oklab,var(--muted)_50%,transparent)] text-left text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="px-4 py-3.5">Feature</th>
                <th className="px-4 py-3.5 text-center">Free</th>
                <th className="px-4 py-3.5 text-center text-[color-mix(in_oklab,var(--gold)_75%,var(--foreground))]">Premium</th>
              </tr>
            </thead>
            <tbody>
              {COMPARISON.map((row) => (
                <tr key={row.feature} className="border-t border-[color-mix(in_oklab,var(--gold)_14%,transparent)]">
                  <td className="px-4 py-3.5 font-medium">{row.feature}</td>
                  <td className="px-4 py-3.5 text-center text-muted-foreground">
                    {typeof row.free === "string" ? (
                      row.free
                    ) : row.free ? (
                      <Check className="mx-auto h-4 w-4 text-[var(--india-green)]" />
                    ) : (
                      <X className="mx-auto h-4 w-4 text-muted-foreground" />
                    )}
                  </td>
                  <td className="px-4 py-3.5 text-center">
                    {typeof row.premium === "string" ? (
                      <span className="font-semibold text-[color-mix(in_oklab,var(--gold)_75%,var(--foreground))]">{row.premium}</span>
                    ) : (
                      <Check className="mx-auto h-4 w-4 text-[var(--gold)]" />
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Payment history */}
      {user && (
        <section className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <p className="eyebrow">History</p>
              <h2 className="mt-1 font-display text-3xl">Payment history</h2>
            </div>
            <button
              onClick={() => refetchPayments()}
              className="btn-quiet inline-flex items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-semibold"
            >
              <RefreshCw className="h-3.5 w-3.5" /> Refresh
            </button>
          </div>

          {(payments?.length ?? 0) === 0 ? (
            <p className="panel rounded-2xl px-4 py-8 text-center text-sm text-muted-foreground">
              No payments yet. Your submissions, approvals and failed attempts will appear here.
            </p>
          ) : (
            <ul className="panel divide-y divide-[color-mix(in_oklab,var(--gold)_14%,transparent)] overflow-hidden rounded-3xl">
              {payments!.map((p) => {
                const state = STATUS_META[p.status as keyof typeof STATUS_META] ?? STATUS_META.pending;
                return (
                  <li key={p.id} className="px-4 py-4 text-sm sm:px-5">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="min-w-0">
                        <div className="font-semibold">
                          ₹{p.amount} · {PLANS[(p.plan as PlanId) ?? "monthly"].label}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          Submitted {formatDate(p.created_at)}
                          {p.reviewed_at ? ` · reviewed ${formatDate(p.reviewed_at)}` : ""}
                          {p.reference ? ` · Ref ${p.reference}` : ""}
                        </div>
                        {p.note && <div className="mt-1 text-xs italic text-muted-foreground">“{p.note}”</div>}
                      </div>
                      <span className={`rounded-full px-3 py-1 text-[11px] font-bold uppercase ${state.cls}`}>
                        {state.label}
                      </span>
                    </div>

                    {p.status === "rejected" && (
                      <div className="mt-3 flex flex-wrap items-center gap-3 rounded-xl border border-[oklch(0.55_0.19_28/0.25)] bg-[oklch(0.55_0.19_28/0.08)] px-3.5 py-3 text-xs text-[var(--destructive)]">
                        <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
                        <span className="min-w-0 flex-1 text-[oklch(0.4_0.1_30)]">
                          We couldn't verify this UPI reference. Check the UTR in your payment app and resubmit.
                        </span>
                        <button
                          onClick={() => {
                            setPlan(((p.plan as PlanId) ?? "monthly"));
                            setPrefillReference(p.reference ?? "");
                            setPayOpen(true);
                          }}
                          className="btn-quiet inline-flex items-center gap-1.5 rounded-full px-3.5 py-1.5 font-bold"
                        >
                          <RefreshCw className="h-3.5 w-3.5" /> Retry payment
                        </button>
                      </div>
                    )}

                    {p.status === "pending" && (
                      <p className="mt-2 text-xs text-muted-foreground">
                        Amber verifies payments manually — Premium switches on automatically once approved.
                      </p>
                    )}
                  </li>
                );
              })}
            </ul>
          )}
        </section>
      )}

      <AnimatePresence>
        {payOpen && (
          <PaymentDialog
            plan={plan}
            initialReference={prefillReference}
            onClose={() => setPayOpen(false)}
            onDone={() => {
              refreshPremium();
              void refetchPayments();
            }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function PaymentDialog({
  plan,
  initialReference = "",
  onClose,
  onDone,
}: {
  plan: PlanId;
  initialReference?: string;
  onClose: () => void;
  onDone: () => void;
}) {
  const submit = useServerFn(submitPaymentRequest);
  const [reference, setReference] = useState(initialReference);
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);

  async function handleSubmit() {
    if (reference.trim().replace(/\s+/g, "").length < 6) {
      toast.error("Enter the UPI reference / UTR number from your payment app.");
      return;
    }
    setBusy(true);
    try {
      const res = await submit({ data: { plan, reference, note: note || undefined } });
      if (!res.ok) {
        toast.error(res.message);
        return;
      }
      setDone(true);
      onDone();
      toast.success("Payment submitted — Amber will verify it shortly.");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not submit payment.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="scrim fixed inset-0 z-50 flex items-end justify-center bg-[oklch(0.14_0.02_38/0.72)] pt-[max(1rem,env(safe-area-inset-top))] backdrop-blur-sm sm:grid sm:place-items-center sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-label="UPI payment"
      onClick={onClose}
    >
      <motion.div
        initial={{ y: 30, scale: 0.97 }}
        animate={{ y: 0, scale: 1 }}
        exit={{ y: 20, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
        className="panel max-h-[calc(100dvh-env(safe-area-inset-top))] w-full max-w-md overflow-y-auto rounded-b-none rounded-t-3xl p-5 pb-[max(1.25rem,env(safe-area-inset-bottom))] sm:max-h-[90dvh] sm:rounded-3xl sm:p-6"
      >
        <div className="flex items-start justify-between gap-3">
          <div>
            <h3 className="font-display text-2xl">
              Pay ₹{PLANS[plan].price} · {PLANS[plan].label}
            </h3>
            <p className="text-xs text-muted-foreground">Scan with any UPI app (GPay, PhonePe, Paytm)</p>
          </div>
          <button onClick={onClose} aria-label="Close" className="btn-quiet grid h-9 w-9 place-items-center rounded-full">
            <X className="h-4 w-4" />
          </button>
        </div>

        {done ? (
          <div className="mt-6 space-y-3 text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-[color-mix(in_oklab,var(--gold)_20%,transparent)]">
              <Clock className="h-6 w-6 text-[color-mix(in_oklab,var(--gold)_75%,var(--foreground))]" />
            </div>
            <h4 className="font-display text-xl">Payment under review</h4>
            <p className="text-sm text-muted-foreground">
              Amber will verify your UPI reference and your Premium will activate automatically. You'll see it on this page
              and in Settings.
            </p>
            <button onClick={onClose} className="btn-quiet mt-2 w-full rounded-full px-5 py-3 text-sm font-semibold">
              Done
            </button>
          </div>
        ) : (
          <>
            <div className="media-frame mt-5 rounded-2xl bg-[oklch(0.99_0.005_88)] p-3">
              <img src={UPI_QR_URL} alt={`UPI QR code to pay ${UPI_PAYEE_NAME}`} className="mx-auto w-full max-w-[240px]" />
            </div>
            <div className="glass mt-3 flex items-center justify-between rounded-2xl px-4 py-2.5 text-sm">
              <span className="text-muted-foreground">Paying to</span>
              <span className="font-semibold">{UPI_PAYEE_NAME}</span>
            </div>

            <ol className="mt-4 space-y-1.5 text-xs text-muted-foreground">
              <li>1. Scan the QR and pay exactly ₹{PLANS[plan].price}.</li>
              <li>2. Copy the UPI reference / UTR number from your payment app.</li>
              <li>3. Paste it below and submit for verification.</li>
            </ol>

            <label className="eyebrow mt-4 block text-[10px]">UPI reference / UTR</label>
            <div className="mt-1.5 flex gap-2">
              <input
                value={reference}
                onChange={(e) => setReference(e.target.value)}
                maxLength={40}
                placeholder="e.g. 412345678901"
                className="glass w-full rounded-2xl px-4 py-3 text-sm outline-none focus:border-[var(--gold)]"
              />
              <button
                onClick={async () => {
                  try {
                    const text = await navigator.clipboard.readText();
                    if (text) setReference(text.trim().slice(0, 40));
                  } catch {
                    toast.error("Clipboard blocked — please type it manually.");
                  }
                }}
                aria-label="Paste from clipboard"
                className="glass grid h-12 w-12 shrink-0 place-items-center rounded-2xl"
              >
                <Copy className="h-4 w-4" />
              </button>
            </div>

            <textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              maxLength={300}
              rows={2}
              placeholder="Optional note for Amber"
              className="glass mt-3 w-full rounded-2xl px-4 py-3 text-sm outline-none focus:border-[var(--gold)]"
            />

            <button
              onClick={handleSubmit}
              disabled={busy}
              className="btn-gold mt-4 inline-flex w-full items-center justify-center gap-2 rounded-full px-6 py-3.5 text-sm font-semibold disabled:opacity-60"
            >
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />} Submit for
              verification
            </button>
            <p className="mt-3 text-center text-[11px] text-muted-foreground">
              Premium activates after Amber approves your payment. Duration: {PLANS[plan].days} days.
            </p>
          </>
        )}
      </motion.div>
    </motion.div>
  );
}
