import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Search, Sparkles, Filter } from "lucide-react";
import { useRecipes, RAJASTHAN_CATEGORIES } from "@/lib/recipes";
import { DbRecipeCard } from "@/components/DbRecipeCard";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/rajasthan")({
  head: () => ({
    meta: [
      { title: "Rajasthani Recipes — Bharat Rasoi" },
      {
        name: "description",
        content:
          "Authentic Rajasthani recipes — Dal Baati Churma, Laal Maas, Pyaz Kachori, Ghevar and 50+ more royal Marwari dishes.",
      },
      { property: "og:title", content: "Rajasthani Recipes — Bharat Rasoi" },
      { property: "og:description", content: "Explore 50+ authentic Rajasthani dishes with ingredients, steps and YouTube tutorials." },
    ],
  }),
  component: RajasthanPage,
});

function RajasthanPage() {
  const { data: recipes, isLoading } = useRecipes({ state: "Rajasthan" });
  const { isAdmin } = useAuth();
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<string>("All");
  const [onlyFeatured, setOnlyFeatured] = useState(false);

  const filtered = useMemo(() => {
    const list = recipes ?? [];
    return list.filter(r => {
      if (category !== "All" && r.category !== category) return false;
      if (onlyFeatured && !r.featured) return false;
      if (query) {
        const q = query.toLowerCase();
        const hay = `${r.name} ${r.description} ${r.tags.join(" ")} ${r.category}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [recipes, query, category, onlyFeatured]);

  const featured = useMemo(() => (recipes ?? []).filter(r => r.featured).slice(0, 6), [recipes]);

  return (
    <div className="space-y-10">
      {/* Hero */}
      <motion.section
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        className="panel-dark relative overflow-hidden rounded-[1.75rem] p-6 sm:rounded-[2rem] sm:p-10"
      >
        <div className="eyebrow inline-flex items-center gap-2 !text-[oklch(0.9_0.05_84)]">
          <Sparkles className="h-3.5 w-3.5 text-[var(--saffron)]" aria-hidden="true" /> Royal Marwari Kitchen
        </div>
        <h1 className="mt-4 font-display text-4xl leading-tight text-[oklch(0.97_0.01_88)] sm:text-6xl">
          Rajasthan <span className="text-gradient">on a plate</span>.
        </h1>
        <p className="mt-3 max-w-2xl text-sm text-[oklch(0.93_0.01_88/0.75)] sm:text-base">
          From the fiery <em>Laal Maas</em> of Mewar to the slow-baked <em>Dal Baati Churma</em> and
          Jodhpur's flaky <em>Pyaz Kachori</em> — every desert classic, with ingredients, step-by-step
          method, nutrition and a one-tap YouTube tutorial.
        </p>
        <div className="mt-6 flex flex-wrap items-center gap-6">
          <Stat k={(recipes ?? []).length.toString()} v="Dishes" />
          <Stat k={featured.length.toString()} v="Featured" />
          <Stat k="6" v="Regions" />
          {isAdmin && (
            <Link
              to="/admin"
              className="btn-gold ml-auto inline-flex touch-manipulation items-center gap-2 rounded-full px-5 py-2.5 text-xs font-semibold"
            >
              Admin dashboard
            </Link>
          )}
        </div>
      </motion.section>

      {/* Search + Filters */}
      <section className="space-y-4">
        <div className="flex flex-col gap-3 sm:flex-row">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
            <input
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search Dal Baati, Laal Maas, Ghevar..."
              className="glass w-full rounded-2xl border border-[color-mix(in_oklab,var(--gold)_16%,transparent)] py-3 pl-11 pr-4 text-sm outline-none focus:border-primary"
            />
          </div>
          <button
            onClick={() => setOnlyFeatured(v => !v)}
            aria-pressed={onlyFeatured}
            className={`inline-flex touch-manipulation items-center justify-center gap-2 rounded-2xl px-5 py-3 text-sm font-semibold transition active:scale-95 ${
              onlyFeatured ? "btn-ink" : "btn-quiet"
            }`}
          >
            <Filter className="h-4 w-4" aria-hidden="true" /> Featured only
          </button>
        </div>

        <div className="rail -mx-1 px-1 pb-1">
          {RAJASTHAN_CATEGORIES.map(c => {
            const active = category === c;
            return (
              <button
                key={c}
                onClick={() => setCategory(c)}
                aria-pressed={active}
                className={`shrink-0 touch-manipulation rounded-full px-4 py-1.5 text-xs font-semibold transition active:scale-95 ${
                  active ? "btn-ink" : "btn-quiet"
                }`}
              >
                {c}
              </button>
            );
          })}
        </div>
      </section>

      {/* Featured rail */}
      {!query && category === "All" && !onlyFeatured && featured.length > 0 && (
        <section className="space-y-4">
          <h2 className="font-display text-2xl">⭐ Featured</h2>
          <div className="rail -mx-1 px-1 pb-3">
            {featured.map((r, i) => (
              <div key={r.id} className="w-72 shrink-0">
                <DbRecipeCard recipe={r} index={i} />
              </div>
            ))}
          </div>
        </section>
      )}

      {/* All recipes grid */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-2xl">
            {filtered.length} {filtered.length === 1 ? "Recipe" : "Recipes"}
          </h2>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {Array.from({ length: 8 }).map((_, i) => <div key={i} className="skeleton aspect-[3/4] rounded-[1.25rem]" />)}
          </div>
        ) : filtered.length === 0 ? (
          <div className="panel p-12 text-center">
            <Sparkles className="mx-auto h-6 w-6 text-[var(--gold)]" aria-hidden="true" />
            <p className="mt-3 text-sm text-muted-foreground">No dishes match your search.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filtered.map((r, i) => (
              <DbRecipeCard key={r.id} recipe={r} index={i} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

function Stat({ k, v }: { k: string; v: string }) {
  return (
    <div>
      <div className="font-display text-3xl text-gradient">{k}</div>
      <div className="eyebrow mt-0.5 !text-[oklch(0.85_0.03_84)]">{v}</div>
    </div>
  );
}
