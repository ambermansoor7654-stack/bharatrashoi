// Server-only premium helpers. Never import from client code.
import { PLANS, type PlanId } from "@/lib/premium";

type ProfileRow = {
  id: string;
  name: string | null;
  email: string | null;
  avatar_url: string | null;
  is_premium: boolean;
  premium_plan: string | null;
  premium_start_date: string | null;
  premium_expiry_date: string | null;
  payment_id: string | null;
  verified: boolean;
};

async function admin() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

export async function ensureProfile(
  userId: string,
  claims: Record<string, unknown>,
): Promise<ProfileRow> {
  const db = await admin();
  const { data, error } = await db.from("profiles").select("*").eq("id", userId).maybeSingle();
  if (error) throw new Error(error.message);
  if (data) return data as ProfileRow;

  const meta = (claims["user_metadata"] ?? {}) as Record<string, unknown>;
  const insert = {
    id: userId,
    email: typeof claims["email"] === "string" ? (claims["email"] as string) : null,
    name:
      (typeof meta["full_name"] === "string" && meta["full_name"]) ||
      (typeof meta["name"] === "string" && meta["name"]) ||
      null,
    avatar_url:
      (typeof meta["avatar_url"] === "string" && meta["avatar_url"]) ||
      (typeof meta["picture"] === "string" && meta["picture"]) ||
      null,
  };
  const { data: created, error: insertError } = await db
    .from("profiles")
    .upsert(insert, { onConflict: "id" })
    .select("*")
    .single();
  if (insertError) throw new Error(insertError.message);
  return created as ProfileRow;
}

/** Expire premium server-side when the paid window has passed. */
export async function expireIfNeeded(profile: ProfileRow): Promise<{ profile: ProfileRow; justExpired: boolean }> {
  const expired =
    profile.is_premium && (!profile.premium_expiry_date || new Date(profile.premium_expiry_date).getTime() <= Date.now());
  if (!expired) return { profile, justExpired: false };

  const db = await admin();
  const { data, error } = await db
    .from("profiles")
    .update({ is_premium: false, premium_plan: null })
    .eq("id", profile.id)
    .select("*")
    .single();
  if (error) throw new Error(error.message);
  return { profile: data as ProfileRow, justExpired: true };
}

export async function activatePremium(userId: string, plan: PlanId, paymentId: string) {
  const db = await admin();
  const { data: current } = await db
    .from("profiles")
    .select("premium_expiry_date, is_premium")
    .eq("id", userId)
    .maybeSingle();

  const now = Date.now();
  const existingExpiry = current?.is_premium && current.premium_expiry_date
    ? new Date(current.premium_expiry_date).getTime()
    : 0;
  const base = Math.max(now, existingExpiry);
  const expiry = new Date(base + PLANS[plan].days * 86_400_000).toISOString();

  const { error } = await db
    .from("profiles")
    .update({
      is_premium: true,
      premium_plan: plan,
      premium_start_date: new Date(now).toISOString(),
      premium_expiry_date: expiry,
      payment_id: paymentId,
    })
    .eq("id", userId);
  if (error) throw new Error(error.message);
  return expiry;
}

type HasRoleClient = {
  rpc: (fn: "has_role", args: { _user_id: string; _role: "admin" }) => PromiseLike<{ data: unknown }>;
};

/**
 * Server-side admin check. Verified twice:
 *  1. as the caller through `has_role` (RLS-scoped, proves the bearer token identity),
 *  2. against `user_roles` with the service-role client (source of truth).
 * Nothing about the request body or the caller's email is trusted.
 */
export async function assertAdmin(supabase: HasRoleClient, userId: string) {
  const { data } = await supabase.rpc("has_role", { _user_id: userId, _role: "admin" });
  if (!data) throw new Error("Forbidden: admin only");

  const db = await admin();
  const { data: row, error } = await db
    .from("user_roles")
    .select("id")
    .eq("user_id", userId)
    .eq("role", "admin")
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!row) throw new Error("Forbidden: admin only");
}

/** Blocks an admin from approving / granting anything to their own account. */
export function assertNotSelf(actorUserId: string, targetUserId: string) {
  if (actorUserId === targetUserId) {
    throw new Error("Forbidden: you cannot review or grant premium for your own account.");
  }
}


export type { ProfileRow };
