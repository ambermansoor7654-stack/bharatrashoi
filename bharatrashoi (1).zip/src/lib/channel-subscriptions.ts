import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/lib/auth';

export function canSubscribe(userId: string | undefined, ownerId: string) {
  return Boolean(userId && userId !== ownerId);
}

export function useChannelSubscriptions() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const query = useQuery({
    queryKey: ['channel-subscriptions', user?.id],
    enabled: Boolean(user),
    queryFn: async () => {
      if (!user) return [];
      const { data, error } = await supabase.from('channel_subscriptions').select('channel_id').eq('user_id', user.id);
      if (error) throw error;
      return data.map(row => row.channel_id);
    },
  });
  const ids = user ? query.data ?? [] : [];
  async function toggle(channelId: string, ownerId: string) {
    if (!user || !canSubscribe(user.id, ownerId)) throw new Error('Sign in to subscribe to another kitchen.');
    const result = ids.includes(channelId)
      ? await supabase.from('channel_subscriptions').delete().eq('user_id', user.id).eq('channel_id', channelId)
      : await supabase.from('channel_subscriptions').insert({ user_id: user.id, channel_id: channelId });
    if (result.error) throw result.error;
    await Promise.all([qc.invalidateQueries({ queryKey: ['channel-subscriptions'] }), qc.invalidateQueries({ queryKey: ['community'] })]);
  }
  return { ids, toggle, loading: query.isLoading, error: query.error };
}