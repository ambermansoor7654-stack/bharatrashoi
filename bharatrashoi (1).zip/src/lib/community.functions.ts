import { createServerFn } from '@tanstack/react-start';
import { createClient } from '@supabase/supabase-js';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';
import { canManageMonetization } from '@/lib/community-rules';
import { z } from 'zod';

export const listCommunity = createServerFn({ method: 'GET' }).handler(async () => {
  const url = process.env['SUPABASE_URL'];
  const key = process.env['SUPABASE_PUBLISHABLE_KEY'];
  if (!url || !key) throw new Error('Channels unavailable');
  const client = createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false }, global: { fetch: (input, init) => {
    const headers = new Headers(init?.headers);
    if (key.startsWith('sb_')) headers.delete('Authorization');
    headers.set('apikey', key);
    return fetch(input, { ...init, headers });
  } } });
  const [channels, videos] = await Promise.all([client.from('channels').select('id,owner_id,name,handle,description,monetized,banner_path,avatar_path').order('created_at', { ascending: false }), client.from('channel_videos').select('*').order('created_at', { ascending: false }).limit(100)]);
  if (channels.error || videos.error) throw new Error('Could not load channels');
  const counts = await client.rpc('channel_subscriber_counts');
  if (counts.error) throw new Error('Could not load subscriber counts');
  const signImage = async (path: string | null) => {
    if (!path) return null;
    const { data, error } = await client.storage.from('channel-images').createSignedUrl(path, 3600);
    return error ? null : data?.signedUrl ?? null;
  };
  const channelItems = await Promise.all((channels.data ?? []).map(async channel => ({
    ...channel,
    subscriberCount: Number(counts.data?.find((row: { channel_id: string }) => row.channel_id === channel.id)?.subscriber_count ?? 0),
    bannerUrl: await signImage(channel.banner_path),
    avatarUrl: await signImage(channel.avatar_path),
  })));
  const items = await Promise.all((videos.data ?? []).map(async video => {
    const { data, error } = await client.storage.from('channel-videos').createSignedUrl(video.video_path, 3600);
    return { ...video, url: error ? null : data?.signedUrl ?? null };
  }));
  return { channels: channelItems, videos: items };
});

export const recordLogin = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  const { data, error } = await context.supabase.auth.getUser();
  if (error || !data.user) throw new Error('Sign in required');
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server');
  const now = new Date().toISOString();
  const { error: writeError } = await supabaseAdmin.from('daily_logins').upsert({ user_id: context.userId, day: now.slice(0, 10), email: data.user.email, provider: data.user.app_metadata.provider, last_at: now }, { onConflict: 'user_id,day' });
  if (writeError) throw new Error('Could not record login');
  return { ok: true };
});

export const recordVisit = createServerFn({ method: 'POST' }).inputValidator(z.object({ visitor: z.string().uuid(), path: z.string().max(200) })).handler(async ({ data }) => {
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server');
  const { error } = await supabaseAdmin.from('site_visits').upsert({ visitor_id: data.visitor, day: new Date().toISOString().slice(0, 10), first_path: data.path.split('?')[0] }, { onConflict: 'visitor_id,day', ignoreDuplicates: true });
  if (error) throw new Error('Could not record visit');
  return { ok: true };
});

export const adminCommunity = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth]).inputValidator(z.object({ channel: z.string().uuid().optional(), monetized: z.boolean().optional(), day: z.string().regex(/^\d{4}-\d{2}-\d{2}$/) })).handler(async ({ data, context }) => {
  const { data: role, error } = await context.supabase.rpc('has_role', { _user_id: context.userId, _role: 'admin' });
  const { data: identity } = await context.supabase.auth.getUser();
  if (error || !canManageMonetization(Boolean(role), identity.user?.email ?? '')) throw new Error('Owner admin only');
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server');
  if (data.channel && typeof data.monetized === 'boolean') {
    const { error: updateError } = await supabaseAdmin.from('channels').update({ monetized: data.monetized, monetized_at: data.monetized ? new Date().toISOString() : null }).eq('id', data.channel);
    if (updateError) throw new Error('Could not update monetization');
  }
  const [users, logins, failed, visits, channels] = await Promise.all([
    supabaseAdmin.auth.admin.listUsers({ page: 1, perPage: 1000 }),
    supabaseAdmin.from('daily_logins').select('*').eq('day', data.day),
    supabaseAdmin.from('failed_logins').select('*').gte('created_at', `${data.day}T00:00:00Z`).lt('created_at', `${data.day}T23:59:59.999Z`).limit(100),
    supabaseAdmin.from('site_visits').select('visitor_id', { count: 'exact', head: true }).eq('day', data.day),
    supabaseAdmin.from('channels').select('id,name,handle,monetized')
  ]);
  if (users.error || logins.error || failed.error || visits.error || channels.error) throw new Error('Reports unavailable');
  return { users: users.data.users.map(u => ({ id: u.id, email: u.email ?? null, lastSignIn: u.last_sign_in_at ?? null })), logins: logins.data ?? [], failed: failed.data ?? [], visits: visits.count ?? 0, channels: channels.data ?? [] };
});
