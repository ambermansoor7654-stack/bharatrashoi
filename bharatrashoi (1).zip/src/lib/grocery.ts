import { useCallback, useEffect, useState } from "react";

const KEY = "bharat-rasoi:grocery";
const EVT = "grocery:changed";

export type GroceryItem = {
  id: string;
  name: string;
  qty: number;
  unit: string;
  category: GroceryCategory;
  checked: boolean;
  recipe?: string;
  raw?: string;
};

export const GROCERY_CATEGORIES = [
  "Vegetables & Fruit",
  "Dairy & Eggs",
  "Grains & Flour",
  "Dals & Pulses",
  "Spices & Masala",
  "Oils & Ghee",
  "Meat & Seafood",
  "Other",
] as const;

export type GroceryCategory = (typeof GROCERY_CATEGORIES)[number];

const RULES: Array<[GroceryCategory, RegExp]> = [
  ["Spices & Masala", /(masala|powder|haldi|turmeric|chilli|chili|mirch|jeera|cumin|coriander seed|dhania|garam|hing|asafoetida|ajwain|saunf|fennel|elaichi|cardamom|clove|laung|cinnamon|dalchini|bay leaf|tej patta|pepper|kalonji|methi seed|amchur|salt|namak|kasuri)/i],
  ["Dairy & Eggs", /(milk|doodh|curd|dahi|yog(h)?urt|paneer|cheese|cream|malai|butter|makhan|khoya|mawa|egg|anda)/i],
  ["Oils & Ghee", /(oil|tel|ghee|vanaspati|mustard oil)/i],
  ["Dals & Pulses", /(dal|daal|lentil|chana|chickpea|rajma|moong|urad|masoor|toor|arhar|lobia|matki|besan|sprout)/i],
  ["Grains & Flour", /(atta|flour|maida|rice|chawal|suji|semolina|rava|poha|sabudana|bread|noodle|vermicelli|oats|bajra|jowar|makki|wheat)/i],
  ["Meat & Seafood", /(chicken|mutton|lamb|goat|fish|prawn|shrimp|keema|meat|crab)/i],
  ["Vegetables & Fruit", /(onion|pyaz|tomato|tamatar|potato|aloo|garlic|lehsun|ginger|adrak|chilli|coriander leaf|cilantro|mint|pudina|curry lea(f|ves)|spinach|palak|methi|carrot|gajar|peas|matar|cauliflower|gobi|brinjal|baingan|bhindi|okra|capsicum|cabbage|pumpkin|kaddu|lemon|nimbu|lime|mango|aam|banana|coconut|nariyal|beet|cucumber|radish|mooli|gourd|tinda|papaya|apple|corn)/i],
];

export function categorize(name: string): GroceryCategory {
  for (const [cat, re] of RULES) if (re.test(name)) return cat;
  return "Other";
}

const UNITS =
  /^(kg|kgs|g|gm|gms|gram|grams|ml|l|litre|liters?|cup|cups|tbsp|tablespoons?|tsp|teaspoons?|pinch|cloves?|inch|piece|pieces|pcs|nos?|bunch|handful|sprigs?|leaves|slices?)\b/i;

const FRACTIONS: Record<string, number> = {
  "½": 0.5, "¼": 0.25, "¾": 0.75, "⅓": 1 / 3, "⅔": 2 / 3, "⅛": 0.125,
};

/** Turns "2 cups basmati rice" / "½ tsp haldi" into a structured grocery item. */
export function parseIngredient(raw: string, recipe?: string): Omit<GroceryItem, "id" | "checked"> {
  let rest = raw.trim().replace(/^[-•*]\s*/, "");
  let qty = 1;
  let unit = "";

  const fracMatch = rest.match(/^([½¼¾⅓⅔⅛])\s*/);
  const numMatch = rest.match(/^(\d+(?:\.\d+)?)(?:\s*\/\s*(\d+))?\s*/);
  if (fracMatch) {
    qty = FRACTIONS[fracMatch[1]] ?? 1;
    rest = rest.slice(fracMatch[0].length);
  } else if (numMatch) {
    const a = parseFloat(numMatch[1]);
    qty = numMatch[2] ? a / parseFloat(numMatch[2]) : a;
    rest = rest.slice(numMatch[0].length);
  }

  const unitMatch = rest.match(UNITS);
  if (unitMatch) {
    unit = unitMatch[1].toLowerCase();
    rest = rest.slice(unitMatch[0].length).trim();
  }

  const name = (rest.replace(/^of\s+/i, "").trim() || raw.trim()).replace(/\s{2,}/g, " ");
  return { name, qty: Math.round(qty * 100) / 100, unit, category: categorize(name), recipe, raw };
}

function read(): GroceryItem[] {
  if (typeof window === "undefined") return [];
  try {
    const parsed = JSON.parse(localStorage.getItem(KEY) || "[]");
    return Array.isArray(parsed) ? (parsed as GroceryItem[]) : [];
  } catch {
    return [];
  }
}

function write(items: GroceryItem[]) {
  localStorage.setItem(KEY, JSON.stringify(items));
  window.dispatchEvent(new Event(EVT));
}

function newId() {
  return `g_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
}

export function addIngredientsToGrocery(ingredients: string[], recipe?: string) {
  const items = read();
  let added = 0;
  for (const raw of ingredients) {
    if (!raw?.trim()) continue;
    const parsed = parseIngredient(raw, recipe);
    const existing = items.find(
      (i) => i.name.toLowerCase() === parsed.name.toLowerCase() && i.unit === parsed.unit,
    );
    if (existing) {
      existing.qty = Math.round((existing.qty + parsed.qty) * 100) / 100;
      existing.checked = false;
    } else {
      items.push({ id: newId(), checked: false, ...parsed });
    }
    added += 1;
  }
  write(items);
  return added;
}

export function useGroceryList() {
  const [items, setItems] = useState<GroceryItem[]>([]);

  useEffect(() => {
    const sync = () => setItems(read());
    sync();
    window.addEventListener(EVT, sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener(EVT, sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  const mutate = useCallback((fn: (items: GroceryItem[]) => GroceryItem[]) => {
    write(fn(read()));
  }, []);

  return {
    items,
    add: useCallback(
      (raw: string) => {
        if (!raw.trim()) return;
        mutate((cur) => [...cur, { id: newId(), checked: false, ...parseIngredient(raw) }]);
      },
      [mutate],
    ),
    setQty: useCallback(
      (id: string, qty: number) =>
        mutate((cur) =>
          cur.map((i) => (i.id === id ? { ...i, qty: Math.max(0.25, Math.round(qty * 100) / 100) } : i)),
        ),
      [mutate],
    ),
    toggle: useCallback(
      (id: string) => mutate((cur) => cur.map((i) => (i.id === id ? { ...i, checked: !i.checked } : i))),
      [mutate],
    ),
    remove: useCallback((id: string) => mutate((cur) => cur.filter((i) => i.id !== id)), [mutate]),
    clearChecked: useCallback(() => mutate((cur) => cur.filter((i) => !i.checked)), [mutate]),
    clearAll: useCallback(() => mutate(() => []), [mutate]),
  };
}

export function groupByCategory(items: GroceryItem[]) {
  const groups = new Map<GroceryCategory, GroceryItem[]>();
  for (const cat of GROCERY_CATEGORIES) {
    const list = items.filter((i) => i.category === cat);
    if (list.length) groups.set(cat, list);
  }
  return [...groups.entries()];
}

export function formatQty(item: GroceryItem) {
  const q = Number.isInteger(item.qty) ? String(item.qty) : item.qty.toFixed(2).replace(/0$/, "");
  return item.unit ? `${q} ${item.unit}` : q;
}
