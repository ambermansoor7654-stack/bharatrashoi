export type Recipe = {
  id: string;
  name: string;
  state: string;
  region: string;
  category: "Veg" | "Non-Veg" | "Dessert" | "Snack";
  time: string;
  difficulty: "Easy" | "Medium" | "Hard";
  rating: number;
  image: string;
  description: string;
  ingredients: string[];
  steps: string[];
};

export type Region = "North" | "South" | "East" | "West" | "Central" | "Northeast" | "Other";

export type IndianState = {
  id: string;
  name: string;
  capital: string;
  language: string;
  region: Region;
  signature: string;
  culture: string;
  foodCategories: string[];
  image: string;
  color: string;
};

export const REGIONS: Region[] = ["North", "South", "East", "West", "Central", "Northeast", "Other"];

export const STATES: IndianState[] = [
  {
    id: "andhra-pradesh", name: "Andhra Pradesh", capital: "Amaravati", language: "Telugu", region: "South",
    signature: "Andhra Chicken Curry",
    culture: "Fiery cuisine, Kuchipudi dance, ancient temples and the rhythmic Telugu cinema heartland.",
    foodCategories: ["Spicy Curries", "Biryani", "Pickles", "Seafood"],
    image: "https://images.unsplash.com/photo-1589302168068-964664d93dc0?w=800&q=80",
    color: "from-red-500 to-orange-500",
  },
  {
    id: "arunachal-pradesh", name: "Arunachal Pradesh", capital: "Itanagar", language: "English", region: "Northeast",
    signature: "Thukpa",
    culture: "Land of dawn-lit mountains, 26 tribes and Buddhist monasteries clinging to Himalayan slopes.",
    foodCategories: ["Bamboo Shoot", "Noodles", "Smoked Meat", "Rice"],
    image: "https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?w=800&q=80",
    color: "from-emerald-500 to-cyan-600",
  },
  {
    id: "assam", name: "Assam", capital: "Dispur", language: "Assamese", region: "Northeast",
    signature: "Masor Tenga",
    culture: "Endless tea estates, Bihu dance and the mighty Brahmaputra carving life through the valley.",
    foodCategories: ["Fish", "Tea", "Rice", "Fermented"],
    image: "https://images.unsplash.com/photo-1597318236186-5b08fc8b6a8b?w=800&q=80",
    color: "from-green-500 to-emerald-700",
  },
  {
    id: "bihar", name: "Bihar", capital: "Patna", language: "Hindi", region: "East",
    signature: "Litti Chokha",
    culture: "Cradle of Buddhism and Jainism, Nalanda's ancient halls and Chhath's riverside chants.",
    foodCategories: ["Litti", "Sattu", "Sweets", "Street Food"],
    image: "https://images.unsplash.com/photo-1606471191009-63994c53433b?w=800&q=80",
    color: "from-amber-500 to-orange-600",
  },
  {
    id: "chhattisgarh", name: "Chhattisgarh", capital: "Raipur", language: "Hindi", region: "Central",
    signature: "Chila",
    culture: "Tribal heartland of dense sal forests, folk Panthi dance and centuries-old bronze craft.",
    foodCategories: ["Tribal", "Rice", "Millet", "Forest Foods"],
    image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=800&q=80",
    color: "from-lime-500 to-green-700",
  },
  {
    id: "goa", name: "Goa", capital: "Panaji", language: "Konkani", region: "West",
    signature: "Goan Fish Curry",
    culture: "Portuguese-tinted coastline, sussegad sundowns, feni distilleries and azulejo-tiled churches.",
    foodCategories: ["Seafood", "Pork", "Coconut", "Curries"],
    image: "https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=800&q=80",
    color: "from-cyan-400 to-blue-600",
  },
  {
    id: "gujarat", name: "Gujarat", capital: "Gandhinagar", language: "Gujarati", region: "West",
    signature: "Dhokla & Thali",
    culture: "Garba nights, white Rann of Kutch and Asia's only Asiatic lions in Gir's golden forest.",
    foodCategories: ["Vegetarian", "Snacks", "Sweets", "Thali"],
    image: "https://images.unsplash.com/photo-1606491956689-2ea866880c84?w=800&q=80",
    color: "from-yellow-400 to-amber-500",
  },
  {
    id: "haryana", name: "Haryana", capital: "Chandigarh", language: "Hindi", region: "North",
    signature: "Bajra Khichdi",
    culture: "Wrestler akhadas, golden mustard fields and the storied battlefield of Kurukshetra.",
    foodCategories: ["Dairy", "Millet", "Rotis", "Ghee"],
    image: "https://images.unsplash.com/photo-1605197384485-c61daab6c0c3?w=800&q=80",
    color: "from-yellow-500 to-amber-700",
  },
  {
    id: "himachal-pradesh", name: "Himachal Pradesh", capital: "Shimla", language: "Hindi", region: "North",
    signature: "Dham",
    culture: "Pine-scented hill stations, apple orchards and Tibetan-rooted Buddhist monasteries.",
    foodCategories: ["Mountain", "Lentils", "Trout", "Yak Cheese"],
    image: "https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?w=800&q=80",
    color: "from-sky-400 to-indigo-500",
  },
  {
    id: "jammu-kashmir", name: "Jammu & Kashmir", capital: "Srinagar / Jammu", language: "Kashmiri, Dogri, Urdu", region: "North",
    signature: "Rogan Josh",
    culture: "Dal Lake shikaras, saffron fields of Pampore, Sufi shrines and snow-capped Pir Panjal peaks.",
    foodCategories: ["Wazwan", "Saffron", "Mutton", "Kahwa"],
    image: "https://images.unsplash.com/photo-1566837945700-30057527ade0?w=800&q=80",
    color: "from-rose-400 to-red-600",
  },
  {
    id: "jharkhand", name: "Jharkhand", capital: "Ranchi", language: "Hindi", region: "East",
    signature: "Dhuska",
    culture: "Land of forests and waterfalls, Sohrai harvest murals and the Santhal drumbeat.",
    foodCategories: ["Tribal", "Rice", "Forest", "Mahua"],
    image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=800&q=80",
    color: "from-emerald-600 to-teal-700",
  },
  {
    id: "karnataka", name: "Karnataka", capital: "Bengaluru", language: "Kannada", region: "South",
    signature: "Bisi Bele Bath",
    culture: "Hampi's stone temples, Mysuru palaces, silicon startups and Yakshagana under the moon.",
    foodCategories: ["Vegetarian", "Coastal", "Filter Coffee", "Mysore"],
    image: "https://images.unsplash.com/photo-1626500155435-7b2dd55bf83c?w=800&q=80",
    color: "from-red-500 to-yellow-500",
  },
  {
    id: "kerala", name: "Kerala", capital: "Thiruvananthapuram", language: "Malayalam", region: "South",
    signature: "Appam & Stew",
    culture: "Backwater houseboats, Kathakali masks, Ayurveda traditions and emerald spice plantations.",
    foodCategories: ["Coconut", "Seafood", "Banana Leaf", "Sadhya"],
    image: "https://images.unsplash.com/photo-1630383249896-424e482df921?w=800&q=80",
    color: "from-emerald-400 to-teal-600",
  },
  {
    id: "madhya-pradesh", name: "Madhya Pradesh", capital: "Bhopal", language: "Hindi", region: "Central",
    signature: "Poha Jalebi",
    culture: "Heart of India — Khajuraho's carvings, tiger reserves and the marble cliffs of Bhedaghat.",
    foodCategories: ["Street Food", "Poha", "Sweets", "Mughlai"],
    image: "https://images.unsplash.com/photo-1606471191009-63994c53433b?w=800&q=80",
    color: "from-orange-500 to-red-600",
  },
  {
    id: "maharashtra", name: "Maharashtra", capital: "Mumbai", language: "Marathi", region: "West",
    signature: "Vada Pav",
    culture: "Bollywood lights, Ganesh festivals, Sahyadri forts and Mumbai's tireless dabbawala precision.",
    foodCategories: ["Street Food", "Misal", "Coastal", "Maratha"],
    image: "https://images.unsplash.com/photo-1606755962773-d324e0a13086?w=800&q=80",
    color: "from-orange-500 to-pink-500",
  },
  {
    id: "manipur", name: "Manipur", capital: "Imphal", language: "Meitei", region: "Northeast",
    signature: "Eromba",
    culture: "Loktak's floating islands, the graceful Manipuri Raas Leela and polo's ancient birthplace.",
    foodCategories: ["Fermented", "Fish", "Herbs", "Rice"],
    image: "https://images.unsplash.com/photo-1597318236186-5b08fc8b6a8b?w=800&q=80",
    color: "from-pink-500 to-rose-600",
  },
  {
    id: "meghalaya", name: "Meghalaya", capital: "Shillong", language: "English", region: "Northeast",
    signature: "Jadoh",
    culture: "Abode of clouds — living root bridges, matrilineal Khasi society and rock-festival capital.",
    foodCategories: ["Smoked Meat", "Rice", "Bamboo", "Pork"],
    image: "https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?w=800&q=80",
    color: "from-teal-500 to-emerald-700",
  },
  {
    id: "mizoram", name: "Mizoram", capital: "Aizawl", language: "Mizo", region: "Northeast",
    signature: "Bai",
    culture: "Bamboo-clad hills, Cheraw dance over swinging poles and tight-knit church-going communities.",
    foodCategories: ["Bamboo Shoot", "Pork", "Boiled", "Herbs"],
    image: "https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?w=800&q=80",
    color: "from-green-500 to-teal-600",
  },
  {
    id: "nagaland", name: "Nagaland", capital: "Kohima", language: "English", region: "Northeast",
    signature: "Smoked Pork with Bamboo Shoot",
    culture: "Hornbill Festival warriors, 17 tribes and powerfully smoky food fermented in bamboo.",
    foodCategories: ["Smoked Pork", "Bamboo", "Axone", "Chilies"],
    image: "https://images.unsplash.com/photo-1597318236186-5b08fc8b6a8b?w=800&q=80",
    color: "from-red-600 to-orange-700",
  },
  {
    id: "odisha", name: "Odisha", capital: "Bhubaneswar", language: "Odia", region: "East",
    signature: "Dalma",
    culture: "Konark's sun chariot, Puri's Jagannath chariots and the elegance of Odissi classical dance.",
    foodCategories: ["Temple Food", "Seafood", "Sweets", "Pakhala"],
    image: "https://images.unsplash.com/photo-1606471191009-63994c53433b?w=800&q=80",
    color: "from-orange-500 to-amber-700",
  },
  {
    id: "punjab", name: "Punjab", capital: "Chandigarh", language: "Punjabi", region: "North",
    signature: "Butter Chicken",
    culture: "Golden Temple's langar, bhangra at every wedding and the endless rhythm of wheat fields.",
    foodCategories: ["Tandoor", "Dairy", "Wheat", "Curries"],
    image: "https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=800&q=80",
    color: "from-amber-400 to-rose-500",
  },
  {
    id: "rajasthan", name: "Rajasthan", capital: "Jaipur", language: "Hindi", region: "North",
    signature: "Dal Baati Churma",
    culture: "Forts of Rajput valor, Thar desert camels, mirror-work textiles and ghoomar swirling skirts.",
    foodCategories: ["Royal", "Dal Baati", "Sweets", "Spicy"],
    image: "https://images.unsplash.com/photo-1505253758473-96b7015fcd40?w=800&q=80",
    color: "from-orange-400 to-red-600",
  },
  {
    id: "sikkim", name: "Sikkim", capital: "Gangtok", language: "Nepali", region: "Northeast",
    signature: "Momos",
    culture: "Kanchenjunga's shadow, Buddhist gompas and India's first fully organic farming state.",
    foodCategories: ["Momos", "Thukpa", "Fermented", "Tibetan"],
    image: "https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?w=800&q=80",
    color: "from-indigo-500 to-purple-600",
  },
  {
    id: "tamil-nadu", name: "Tamil Nadu", capital: "Chennai", language: "Tamil", region: "South",
    signature: "Masala Dosa",
    culture: "Towering Dravidian temples, Bharatnatyam rhythms and a Tamil language two millennia old.",
    foodCategories: ["Tiffin", "Chettinad", "Filter Coffee", "Seafood"],
    image: "https://images.unsplash.com/photo-1668236543090-82eba5ee5976?w=800&q=80",
    color: "from-amber-500 to-orange-600",
  },
  {
    id: "telangana", name: "Telangana", capital: "Hyderabad", language: "Telugu", region: "South",
    signature: "Hyderabadi Biryani",
    culture: "Nizami palaces, Charminar's evening glow and a dum biryani recipe guarded for centuries.",
    foodCategories: ["Biryani", "Mughlai", "Spicy", "Kebabs"],
    image: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=800&q=80",
    color: "from-red-500 to-amber-600",
  },
  {
    id: "tripura", name: "Tripura", capital: "Agartala", language: "Bengali", region: "Northeast",
    signature: "Mui Borok",
    culture: "Ujjayanta palace, 19 tribal communities and bamboo crafts woven into daily life.",
    foodCategories: ["Bamboo", "Fish", "Herbs", "Fermented"],
    image: "https://images.unsplash.com/photo-1597318236186-5b08fc8b6a8b?w=800&q=80",
    color: "from-emerald-500 to-green-700",
  },
  {
    id: "uttar-pradesh", name: "Uttar Pradesh", capital: "Lucknow", language: "Hindi", region: "North",
    signature: "Lucknowi Biryani",
    culture: "Taj's marble dream, Varanasi's eternal ghats and Lucknow's nawabi adab and tehzeeb.",
    foodCategories: ["Awadhi", "Kebabs", "Chaat", "Mithai"],
    image: "https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?w=800&q=80",
    color: "from-rose-500 to-pink-600",
  },
  {
    id: "uttarakhand", name: "Uttarakhand", capital: "Dehradun", language: "Hindi", region: "North",
    signature: "Kafuli",
    culture: "Devbhoomi — Himalayan pilgrimages, Jim Corbett's tigers and slow-cooked mountain millets.",
    foodCategories: ["Millet", "Mountain", "Lentils", "Herbs"],
    image: "https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?w=800&q=80",
    color: "from-sky-500 to-blue-700",
  },
  {
    id: "west-bengal", name: "West Bengal", capital: "Kolkata", language: "Bengali", region: "East",
    signature: "Rasgulla & Macher Jhol",
    culture: "Durga Puja pandals, Rabindranath's verses, trams of Kolkata and an obsession with sweets.",
    foodCategories: ["Sweets", "Fish", "Mustard", "Rice"],
    image: "https://images.unsplash.com/photo-1571167530149-c1105da4c2c7?w=800&q=80",
    color: "from-rose-400 to-fuchsia-500",
  },
  {
    id: "other", name: "Other", capital: "Worldwide", language: "Multiple", region: "Other",
    signature: "International & Fusion",
    culture: "Beyond state borders — global classics, fusion creations and home-grown experiments curated by the chef.",
    foodCategories: ["International", "Fusion", "Continental", "Asian", "Dessert", "Street Food"],
    image: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800&q=80",
    color: "from-slate-600 to-zinc-800",
  },
];

export const RECIPES: Recipe[] = [
  {
    id: "butter-chicken",
    name: "Butter Chicken",
    state: "Punjab", region: "North", category: "Non-Veg",
    time: "45 min", difficulty: "Medium", rating: 4.8,
    image: "https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=1200&q=80",
    description: "Creamy tomato-based curry with tender tandoori chicken — Delhi's most beloved export.",
    ingredients: ["500g chicken thighs", "2 cups tomato puree", "1 cup heavy cream", "3 tbsp butter", "Ginger-garlic paste", "Garam masala", "Kasuri methi", "Salt to taste"],
    steps: ["Marinate chicken in yogurt and spices for 2 hours.", "Grill until charred at edges.", "Cook tomato puree with butter and spices.", "Add cream and chicken, simmer 15 min.", "Finish with kasuri methi and serve with naan."],
  },
  {
    id: "hyderabadi-biryani",
    name: "Hyderabadi Biryani",
    state: "Telangana", region: "South", category: "Non-Veg",
    time: "1h 30m", difficulty: "Hard", rating: 4.9,
    image: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=1200&q=80",
    description: "Layered basmati rice and spiced mutton, slow-cooked in the dum style.",
    ingredients: ["1kg mutton", "500g basmati rice", "Saffron", "Fried onions", "Yogurt", "Mint & coriander", "Whole spices"],
    steps: ["Marinate mutton overnight.", "Parboil rice with whole spices.", "Layer mutton, rice, fried onions, saffron milk.", "Seal pot with dough, cook on dum 45 min.", "Open and serve with raita."],
  },
  {
    id: "masala-dosa",
    name: "Masala Dosa",
    state: "Tamil Nadu", region: "South", category: "Veg",
    time: "30 min", difficulty: "Medium", rating: 4.7,
    image: "https://images.unsplash.com/photo-1668236543090-82eba5ee5976?w=1200&q=80",
    description: "Crispy fermented rice crepe filled with spiced potato masala.",
    ingredients: ["Dosa batter", "4 potatoes", "Mustard seeds", "Curry leaves", "Onions", "Green chilies", "Turmeric"],
    steps: ["Boil and mash potatoes.", "Temper mustard, curry leaves, onions.", "Mix with potatoes and turmeric.", "Spread batter on hot tawa, crisp it.", "Fill with masala, fold and serve with chutney."],
  },
  {
    id: "dhokla",
    name: "Khaman Dhokla",
    state: "Gujarat", region: "West", category: "Snack",
    time: "25 min", difficulty: "Easy", rating: 4.6,
    image: "https://images.unsplash.com/photo-1606491956689-2ea866880c84?w=1200&q=80",
    description: "Spongy, steamed gram-flour cake with a tangy mustard tempering.",
    ingredients: ["2 cups besan", "1 tbsp eno", "Ginger-chili paste", "Lemon juice", "Mustard seeds", "Curry leaves", "Sugar"],
    steps: ["Whisk besan with water, ginger paste, lemon.", "Add eno, pour in greased tin.", "Steam 15 min until spongy.", "Temper mustard, curry leaves, sugar water.", "Pour over dhokla, garnish coriander."],
  },
  {
    id: "rasgulla",
    name: "Rasgulla",
    state: "West Bengal", region: "East", category: "Dessert",
    time: "40 min", difficulty: "Medium", rating: 4.8,
    image: "https://images.unsplash.com/photo-1571167530149-c1105da4c2c7?w=1200&q=80",
    description: "Soft, spongy chenna balls soaked in fragrant cardamom syrup.",
    ingredients: ["1L full-fat milk", "2 tbsp lemon juice", "1.5 cups sugar", "4 cups water", "Cardamom pods"],
    steps: ["Curdle milk with lemon, strain chenna.", "Knead chenna 10 min until smooth.", "Shape into small balls.", "Boil in sugar syrup 15 min covered.", "Cool and refrigerate before serving."],
  },
  {
    id: "vada-pav",
    name: "Vada Pav",
    state: "Maharashtra", region: "West", category: "Snack",
    time: "30 min", difficulty: "Easy", rating: 4.7,
    image: "https://images.unsplash.com/photo-1606755962773-d324e0a13086?w=1200&q=80",
    description: "Mumbai's iconic spiced potato fritter in a soft pav with chutneys.",
    ingredients: ["4 potatoes", "Besan", "Pav buns", "Garlic chutney", "Green chutney", "Mustard seeds"],
    steps: ["Mash boiled potatoes with tempering.", "Shape into balls, dip in besan batter.", "Deep fry until golden.", "Slit pav, apply chutneys.", "Place vada inside and serve hot."],
  },
  {
    id: "dal-baati",
    name: "Dal Baati Churma",
    state: "Rajasthan", region: "North", category: "Veg",
    time: "1h 15m", difficulty: "Hard", rating: 4.7,
    image: "https://images.unsplash.com/photo-1505253758473-96b7015fcd40?w=1200&q=80",
    description: "Rajasthani trio of baked wheat balls, panchmel dal and sweet churma.",
    ingredients: ["Wheat flour", "Ghee", "Five lentils mix", "Jaggery", "Whole spices"],
    steps: ["Knead stiff dough, shape baatis, bake.", "Cook panchmel dal with spices.", "Crush extra baatis with ghee and jaggery for churma.", "Dip baatis in ghee.", "Serve all three together."],
  },
  {
    id: "appam-stew",
    name: "Appam & Stew",
    state: "Kerala", region: "South", category: "Veg",
    time: "50 min", difficulty: "Medium", rating: 4.6,
    image: "https://images.unsplash.com/photo-1630383249896-424e482df921?w=1200&q=80",
    description: "Lacy rice hoppers paired with coconut-milk vegetable stew.",
    ingredients: ["Appam batter", "Coconut milk", "Mixed vegetables", "Curry leaves", "Ginger", "Green chilies"],
    steps: ["Ferment appam batter overnight.", "Pour in appam pan, swirl, cover, cook.", "Sauté vegetables with ginger and chilies.", "Add coconut milk, simmer gently.", "Serve appam with stew."],
  },
];
