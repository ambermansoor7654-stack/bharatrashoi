// Offline recipe cache — saved recipes stay readable without internet.
import { useCallback, useEffect, useState } from "react";

const KEY = "bharat-rasoi:offline-recipes";
const EVENT = "offline-recipes:changed";

export type OfflineRecipe = {
  id: string;
  slug?: string | null;
  name: string;
  description: string;
  state?: string;
  category?: string;
  image_url?: string | null;
  prep_time?: string;
  cook_time?: string;
  difficulty?: string;
  ingredients: string[];
  steps: string[];
  nutrition?: Record<string, number | string | null> | null;
  tags?: string[];
  cachedAt: number;
};

type Store = Record<string, OfflineRecipe>;

export type OfflineStorageInfo = {
  recipeBytes: number;
  usedBytes: number | null;
  quotaBytes: number | null;
};

function read(): Store {
  if (typeof window === "undefined") return {};
  try {
    return JSON.parse(localStorage.getItem(KEY) || "{}") as Store;
  } catch {
    return {};
  }
}

function write(store: Store) {
  try {
    localStorage.setItem(KEY, JSON.stringify(store));
  } catch {
    /* quota exceeded — offline cache is best-effort */
  }
  window.dispatchEvent(new Event(EVENT));
}

export function cacheRecipeOffline(recipe: Omit<OfflineRecipe, "cachedAt">) {
  const store = read();
  store[recipe.id] = { ...recipe, cachedAt: Date.now() };
  write(store);
}

export function removeOfflineRecipe(id: string) {
  const store = read();
  delete store[id];
  write(store);
}

export function getOfflineRecipe(id: string): OfflineRecipe | null {
  return read()[id] ?? null;
}

export function listOfflineRecipes(): OfflineRecipe[] {
  return Object.values(read()).sort((a, b) => b.cachedAt - a.cachedAt);
}

export async function getOfflineStorageInfo(): Promise<OfflineStorageInfo> {
  if (typeof window === "undefined") return { recipeBytes: 0, usedBytes: null, quotaBytes: null };
  const encoded = new TextEncoder().encode(localStorage.getItem(KEY) ?? "{}");
  if (!navigator.storage?.estimate) {
    return { recipeBytes: encoded.byteLength, usedBytes: null, quotaBytes: null };
  }
  try {
    const estimate = await navigator.storage.estimate();
    return {
      recipeBytes: encoded.byteLength,
      usedBytes: estimate.usage ?? null,
      quotaBytes: estimate.quota ?? null,
    };
  } catch {
    return { recipeBytes: encoded.byteLength, usedBytes: null, quotaBytes: null };
  }
}

/** Reactive list of cached recipe ids. */
export function useOfflineRecipes() {
  const [items, setItems] = useState<OfflineRecipe[]>([]);
  const [storageInfo, setStorageInfo] = useState<OfflineStorageInfo>({
    recipeBytes: 0,
    usedBytes: null,
    quotaBytes: null,
  });

  useEffect(() => {
    const sync = () => {
      setItems(listOfflineRecipes());
      void getOfflineStorageInfo().then(setStorageInfo);
    };
    sync();
    window.addEventListener(EVENT, sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener(EVENT, sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  const isOffline = useCallback((id: string) => items.some((r) => r.id === id), [items]);
  return { offlineRecipes: items, isAvailableOffline: isOffline, storageInfo };
}

/** Live network status (SSR-safe). */
export function useOnlineStatus() {
  const [online, setOnline] = useState(true);
  useEffect(() => {
    const sync = () => setOnline(navigator.onLine);
    sync();
    window.addEventListener("online", sync);
    window.addEventListener("offline", sync);
    return () => {
      window.removeEventListener("online", sync);
      window.removeEventListener("offline", sync);
    };
  }, []);
  return online;
}
