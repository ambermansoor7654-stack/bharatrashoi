import { createServerFn } from "@tanstack/react-start";

export const incrementRecipeViews = createServerFn({ method: "POST" })
  .inputValidator((data: { slug: string }) => {
    if (!data?.slug || typeof data.slug !== "string") throw new Error("slug required");
    return { slug: data.slug.slice(0, 200) };
  })
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { recordAudit } = await import("./audit.server");
    const { data: views, error } = await supabaseAdmin.rpc("increment_recipe_views", { _slug: data.slug });
    if (error) {
      await recordAudit({ action: "recipe.view_increment.error", target: data.slug, metadata: { error: error.message } });
      throw new Error(error.message);
    }
    await recordAudit({ action: "recipe.view_increment", target: data.slug, metadata: { views } });
    return { views: views ?? 0 };
  });
