import { useCallback, useEffect, useMemo, useState } from "react";

const KEY = "bharat-rasoi:cooking-activity";
const EVT = "cooking-activity:changed";

export type CookedEntry = { id: string; name: string; at: string };

export type CookingActivity = {
  cooked: CookedEntry[];
  /** ISO day strings (YYYY-MM-DD) on which the user cooked. */
  days: string[];
  stepsCompleted: number;
};

const empty: CookingActivity = { cooked: [], days: [], stepsCompleted: 0 };

function dayKey(d = new Date()) {
  return d.toISOString().slice(0, 10);
}

function read(): CookingActivity {
  if (typeof window === "undefined") return empty;
  try {
    const parsed = JSON.parse(localStorage.getItem(KEY) || "null");
    if (!parsed) return empty;
    return {
      cooked: Array.isArray(parsed.cooked) ? parsed.cooked : [],
      days: Array.isArray(parsed.days) ? parsed.days : [],
      stepsCompleted: Number(parsed.stepsCompleted ?? 0),
    };
  } catch {
    return empty;
  }
}

function write(a: CookingActivity) {
  localStorage.setItem(KEY, JSON.stringify(a));
  window.dispatchEvent(new Event(EVT));
}

export function recordCooked(recipe: { id: string; name: string }, steps = 0) {
  const a = read();
  const today = dayKey();
  write({
    cooked: [{ id: recipe.id, name: recipe.name, at: new Date().toISOString() }, ...a.cooked].slice(0, 200),
    days: a.days.includes(today) ? a.days : [...a.days, today].sort(),
    stepsCompleted: a.stepsCompleted + steps,
  });
}

export function streaksFrom(days: string[]) {
  if (!days.length) return { current: 0, longest: 0 };
  const set = new Set(days);
  const sorted = [...set].sort();

  let longest = 1;
  let run = 1;
  for (let i = 1; i < sorted.length; i++) {
    const prev = new Date(sorted[i - 1] + "T00:00:00Z").getTime();
    const cur = new Date(sorted[i] + "T00:00:00Z").getTime();
    run = cur - prev === 86_400_000 ? run + 1 : 1;
    longest = Math.max(longest, run);
  }

  let current = 0;
  const cursor = new Date();
  if (!set.has(dayKey(cursor))) cursor.setUTCDate(cursor.getUTCDate() - 1);
  while (set.has(dayKey(cursor))) {
    current += 1;
    cursor.setUTCDate(cursor.getUTCDate() - 1);
  }

  return { current, longest };
}

export type Badge = {
  id: string;
  label: string;
  desc: string;
  target: number;
  progress: number;
  earned: boolean;
};

export type Level = { name: string; min: number; next?: number };

const LEVELS: Level[] = [
  { name: "Beginner", min: 0, next: 100 },
  { name: "Home Cook", min: 100, next: 300 },
  { name: "Skilled Cook", min: 300, next: 700 },
  { name: "Master Chef", min: 700, next: 1500 },
  { name: "Expert", min: 1500 },
];

export function levelFor(points: number): Level {
  return [...LEVELS].reverse().find((l) => points >= l.min) ?? LEVELS[0];
}

export function useCookingActivity(extra: { saves?: number; likes?: number; recipes?: number } = {}) {
  const [activity, setActivity] = useState<CookingActivity>(empty);

  useEffect(() => {
    const sync = () => setActivity(read());
    sync();
    window.addEventListener(EVT, sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener(EVT, sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  const saves = extra.saves ?? 0;
  const likes = extra.likes ?? 0;
  const recipes = extra.recipes ?? 0;

  const derived = useMemo(() => {
    const { current, longest } = streaksFrom(activity.days);
    const uniqueCooked = new Set(activity.cooked.map((c) => c.id)).size;
    const points =
      activity.cooked.length * 25 + activity.stepsCompleted * 2 + saves * 5 + likes * 3 + recipes * 50 + current * 10;
    const level = levelFor(points);

    const badges: Badge[] = [
      { id: "first-cook", label: "First Tadka", desc: "Finish your first recipe in Cooking Mode", target: 1, progress: activity.cooked.length, earned: activity.cooked.length >= 1 },
      { id: "five-dishes", label: "Rasoi Regular", desc: "Cook 5 dishes", target: 5, progress: activity.cooked.length, earned: activity.cooked.length >= 5 },
      { id: "explorer", label: "Swaad Explorer", desc: "Cook 10 different dishes", target: 10, progress: uniqueCooked, earned: uniqueCooked >= 10 },
      { id: "streak-3", label: "3-Day Streak", desc: "Cook 3 days in a row", target: 3, progress: longest, earned: longest >= 3 },
      { id: "streak-7", label: "Weekly Warrior", desc: "Cook 7 days in a row", target: 7, progress: longest, earned: longest >= 7 },
      { id: "collector", label: "Recipe Collector", desc: "Save 10 recipes", target: 10, progress: saves, earned: saves >= 10 },
      { id: "creator", label: "Creator", desc: "Publish your first recipe", target: 1, progress: recipes, earned: recipes >= 1 },
      { id: "steps-100", label: "Century of Steps", desc: "Complete 100 cooking steps", target: 100, progress: activity.stepsCompleted, earned: activity.stepsCompleted >= 100 },
    ];

    return {
      cookedTotal: activity.cooked.length,
      uniqueCooked,
      stepsCompleted: activity.stepsCompleted,
      recent: activity.cooked.slice(0, 8),
      days: activity.days,
      streak: current,
      longestStreak: longest,
      points,
      level,
      badges,
      earnedCount: badges.filter((b) => b.earned).length,
    };
  }, [activity, saves, likes, recipes]);

  const reset = useCallback(() => write(empty), []);

  return { ...derived, reset };
}

/** Last 7 UTC days with a cooked/not-cooked flag, oldest first. */
export function weekGrid(days: string[]) {
  const set = new Set(days);
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setUTCDate(d.getUTCDate() - (6 - i));
    return { key: dayKey(d), label: d.toLocaleDateString(undefined, { weekday: "narrow" }), active: set.has(dayKey(d)) };
  });
}
