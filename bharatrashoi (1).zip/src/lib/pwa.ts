import { registerSW } from "virtual:pwa-register";

const APP_SW_PATH = "/sw.js";

function isPreviewHost(hostname: string) {
  return (
    hostname.startsWith("id-preview--") ||
    hostname.startsWith("preview--") ||
    hostname === "lovableproject.com" ||
    hostname.endsWith(".lovableproject.com") ||
    hostname === "lovableproject-dev.com" ||
    hostname.endsWith(".lovableproject-dev.com") ||
    hostname === "beta.lovable.dev" ||
    hostname.endsWith(".beta.lovable.dev")
  );
}

async function unregisterAppWorker() {
  if (!("serviceWorker" in navigator)) return;
  const registrations = await navigator.serviceWorker.getRegistrations();
  await Promise.all(
    registrations.map(async (registration) => {
      const worker = registration.active ?? registration.waiting ?? registration.installing;
      if (!worker) return;
      const workerUrl = new URL(worker.scriptURL);
      if (workerUrl.pathname === APP_SW_PATH) await registration.unregister();
    }),
  );
}

export async function setupPwa() {
  if (!("serviceWorker" in navigator)) return;

  const disabled = new URLSearchParams(window.location.search).get("sw") === "off";
  const framed = window.self !== window.top;
  const registrationBlocked =
    !import.meta.env.PROD || framed || isPreviewHost(window.location.hostname) || disabled;

  if (registrationBlocked) {
    await unregisterAppWorker();
    return;
  }

  registerSW({ immediate: true });
}