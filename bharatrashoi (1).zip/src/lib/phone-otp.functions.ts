import { createServerFn } from "@tanstack/react-start";
import { createHash, randomBytes, randomInt, timingSafeEqual } from "node:crypto";

// -- Helpers ------------------------------------------------------------

function normalizePhone(raw: string): string {
  const trimmed = raw.trim().replace(/[\s\-()]/g, "");
  if (!/^\+\d{8,15}$/.test(trimmed)) {
    throw new Error("Phone number country code ke saath do (e.g. +9198…)");
  }
  return trimmed;
}

function phoneToE164Int(phone: string): number {
  // GatewayAPI wants MSISDN as integer without '+'
  const digits = phone.replace(/^\+/, "");
  const n = Number(digits);
  if (!Number.isFinite(n)) throw new Error("Invalid phone number");
  return n;
}

function hashCode(code: string, salt: string): string {
  return createHash("sha256").update(`${salt}:${code}`).digest("hex");
}

function phoneToSurrogateEmail(phone: string): string {
  return `${phone.replace(/^\+/, "")}@phone.bharatrasoi.local`;
}

async function sendSms(recipient: number, message: string) {
  const gatewayKey = process.env.GATEWAYAPI_API_KEY;
  const lovableKey = process.env.LOVABLE_API_KEY;
  if (!gatewayKey || !lovableKey) throw new Error("SMS provider not configured");

  const res = await fetch("https://connector-gateway.lovable.dev/gatewayapi/mobile/single", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${lovableKey}`,
      "X-Connection-Api-Key": gatewayKey,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      sender: "BharatRasoi",
      recipient,
      message,
    }),
  });

  if (!res.ok) {
    const body = await res.text().catch(() => "");
    console.error("[phone-otp] SMS send failed", res.status, body);
    if (res.status === 403 || /frozen/i.test(body)) {
      throw new Error("SMS service account abhi band (frozen/blocked) hai, isliye OTP nahi ja raha. Abhi Email ya Google se login karo.");
    }
    if (/credit|balance|insufficient/i.test(body)) {
      throw new Error("SMS service mein balance khatam hai. Abhi Email ya Google se login karo.");
    }
    throw new Error(`SMS service ne request reject ki (${res.status}). Abhi Email ya Google se login karo.`);
  }
}

// -- Request OTP --------------------------------------------------------

export const requestPhoneOtp = createServerFn({ method: "POST" })
  .inputValidator((data: { phone: string }) => data)
  .handler(async ({ data }) => {
    const phone = normalizePhone(data.phone);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { recordAudit } = await import("./audit.server");

    // Rate limit: max 3 codes per 10 minutes per phone
    const tenMinAgo = new Date(Date.now() - 10 * 60_000).toISOString();
    const { count } = await supabaseAdmin
      .from("phone_otps")
      .select("*", { count: "exact", head: true })
      .eq("phone_e164", phone)
      .gte("created_at", tenMinAgo);
    if ((count ?? 0) >= 3) {
      await recordAudit({ action: "otp.request.rate_limited", target: phone, metadata: { count } });
      throw new Error("Bahut jaldi jaldi requests — 10 min baad try karo");
    }

    const code = String(randomInt(0, 1_000_000)).padStart(6, "0");
    const salt = randomBytes(8).toString("hex");
    const codeHash = `${salt}:${hashCode(code, salt)}`;
    const expiresAt = new Date(Date.now() + 5 * 60_000).toISOString();

    const { data: pending, error } = await supabaseAdmin.from("phone_otps").insert({
      phone_e164: phone,
      code_hash: codeHash,
      expires_at: expiresAt,
    }).select('id').single();
    if (error) {
      await recordAudit({ action: "otp.request.error", target: phone, metadata: { error: error.message } });
      throw new Error(error.message);
    }

    try { await sendSms(
      phoneToE164Int(phone),
      `Bharat Rasoi OTP: ${code}\nYeh code 5 minute mai expire ho jayega. Kisi ke saath share na karo.`,
    ); } catch (error) {
      if (pending) await supabaseAdmin.from('phone_otps').delete().eq('id', pending.id);
      throw error;
    }

    await recordAudit({ action: "otp.request.sent", target: phone });
    return { ok: true };
  });

// -- Verify OTP + issue sign-in credentials ----------------------------

export const verifyPhoneOtp = createServerFn({ method: "POST" })
  .inputValidator((data: { phone: string; code: string }) => data)
  .handler(async ({ data }) => {
    const phone = normalizePhone(data.phone);
    const code = data.code.trim();
    if (!/^\d{6}$/.test(code)) throw new Error("6-digit OTP daalo");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { recordAudit } = await import("./audit.server");

    const { data: rows, error: qErr } = await supabaseAdmin
      .from("phone_otps")
      .select("*")
      .eq("phone_e164", phone)
      .is("consumed_at", null)
      .order("created_at", { ascending: false })
      .limit(1);
    if (qErr) throw new Error(qErr.message);
    const row = rows?.[0];
    if (!row) {
      await recordAudit({ action: "otp.verify.no_pending", target: phone });
      throw new Error("Pehle OTP request karo");
    }

    if (new Date(row.expires_at).getTime() < Date.now()) {
      await recordAudit({ action: "otp.verify.expired", target: phone });
      throw new Error("OTP expire ho gaya, naya request karo");
    }
    if (row.attempts >= 5) {
      await recordAudit({ action: "otp.verify.too_many_attempts", target: phone, metadata: { attempts: row.attempts } });
      throw new Error("Bahut galat tries — naya OTP request karo");
    }

    const [salt, expectedHex] = String(row.code_hash).split(":");
    const actualHex = hashCode(code, salt ?? "");
    const a = Buffer.from(actualHex, "hex");
    const b = Buffer.from(expectedHex ?? "", "hex");
    const match = a.length === b.length && timingSafeEqual(a, b);

    if (!match) {
      await supabaseAdmin
        .from("phone_otps")
        .update({ attempts: row.attempts + 1 })
        .eq("id", row.id);
      await recordAudit({ action: "otp.verify.wrong_code", target: phone, metadata: { attempts: row.attempts + 1 } });
      throw new Error("Galat OTP — dobara try karo");
    }

    await supabaseAdmin
      .from("phone_otps")
      .update({ consumed_at: new Date().toISOString() })
      .eq("id", row.id);

    // Create or fetch surrogate email user for this phone
    const email = phoneToSurrogateEmail(phone);
    const ephemeralPassword = randomBytes(24).toString("base64url");

    // Try to find existing user via listUsers (paginated)
    let existingUserId: string | undefined;
    // Best-effort search via getUserByEmail if available
    const { data: byEmail } = await supabaseAdmin.auth.admin
      .listUsers({ page: 1, perPage: 200 })
      .catch(() => ({ data: { users: [] as { id: string; email?: string | null }[] } }));
    existingUserId = byEmail?.users?.find((u) => (u.email ?? "").toLowerCase() === email)?.id;

    if (!existingUserId) {
      const { data: created, error: cErr } = await supabaseAdmin.auth.admin.createUser({
        email,
        password: ephemeralPassword,
        email_confirm: true,
        phone,
        user_metadata: { login_method: "phone_otp", phone },
      });
      if (cErr || !created.user) throw new Error(cErr?.message ?? "Sign-in failed");
      existingUserId = created.user.id;
      await recordAudit({ action: "otp.verify.user_created", target: phone, actorUserId: existingUserId });
    } else {
      const { error: uErr } = await supabaseAdmin.auth.admin.updateUserById(existingUserId, {
        password: ephemeralPassword,
      });
      if (uErr) throw new Error(uErr.message);
    }

    await recordAudit({ action: "otp.verify.success", target: phone, actorUserId: existingUserId });
    return { email, password: ephemeralPassword };
  });
