export function pageMeta(title: string, description: string) {
  return { meta: [{ title: `${title} — Bharat Rasoi` }, { name: 'description', content: description }, { property: 'og:title', content: `${title} — Bharat Rasoi` }, { property: 'og:description', content: description }, { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary' }] };
}
