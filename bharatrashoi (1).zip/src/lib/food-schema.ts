export type NutritionInfo = {
  protein_g: number;
  carbs_g: number;
  fat_g: number;
  fiber_g: number;
};

export type FoodCard = {
  food_name: string;
  origin: string;
  category: string;
  diet: "Veg" | "Non-Veg" | "Vegan" | "Egg";
  main_ingredients: string[];
  cooking_method: string;
  taste_profile: string[];
  calories_per_serving: number;
  nutrition: NutritionInfo;
  health_benefits: string[];
  risks_or_allergies: string[];
  best_time_to_eat: string;
  popular_places: string[];
  cultural_background: string;
  similar_foods: string[];
  image_query: string;
};

export const FOOD_CARD_TOOL_NAME = "render_food_card";

export const FOOD_CARD_PARAMETERS = {
  type: "object",
  additionalProperties: false,
  properties: {
    food_name: { type: "string" },
    origin: { type: "string", description: "Origin state/region in India" },
    category: { type: "string", description: "e.g. Street Food, Dessert, Curry, Snack, Drink" },
    diet: { type: "string", enum: ["Veg", "Non-Veg", "Vegan", "Egg"] },
    main_ingredients: { type: "array", items: { type: "string" } },
    cooking_method: { type: "string" },
    taste_profile: { type: "array", items: { type: "string" } },
    calories_per_serving: { type: "number" },
    nutrition: {
      type: "object",
      additionalProperties: false,
      properties: {
        protein_g: { type: "number" },
        carbs_g: { type: "number" },
        fat_g: { type: "number" },
        fiber_g: { type: "number" },
      },
      required: ["protein_g", "carbs_g", "fat_g", "fiber_g"],
    },
    health_benefits: { type: "array", items: { type: "string" } },
    risks_or_allergies: { type: "array", items: { type: "string" } },
    best_time_to_eat: { type: "string" },
    popular_places: { type: "array", items: { type: "string" } },
    cultural_background: { type: "string" },
    similar_foods: { type: "array", items: { type: "string" } },
    image_query: { type: "string", description: "Short Unsplash search query for an image of this food" },
  },
  required: [
    "food_name", "origin", "category", "diet", "main_ingredients",
    "cooking_method", "taste_profile", "calories_per_serving", "nutrition",
    "health_benefits", "risks_or_allergies", "best_time_to_eat",
    "popular_places", "cultural_background", "similar_foods", "image_query",
  ],
} as const;
