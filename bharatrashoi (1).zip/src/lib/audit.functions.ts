import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export type AuditRow = {
  id: string;
  action: string;
  target: string | null;
  actor_user_id: string | null;
  ip: string | null;
  user_agent: string | null;
  metadata: Record<string, string | number | boolean | null>;
  created_at: string;
  actor: { id: string; name: string | null; username: string | null } | null;
  targetUser: { id: string; name: string | null; username: string | null } | null;
};

/** Actions that represent premium unlocks and blue-tick approvals. */
export const AUDIT_ACTIONS = [
  "premium.payment_approved",
  "premium.payment_rejected",
  "premium.granted_by_admin",
  "premium.cancelled",
  "profile.verified_granted",
  "profile.verified_revoked",
] as const;

export const listAuditTrail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        filter: z.enum(["all", "premium", "verified"]).default("all"),
        limit: z.number().int().min(1).max(200).default(100),
      })
      .parse(input ?? {}),
  )
  .handler(async ({ data, context }): Promise<AuditRow[]> => {
    const { assertAdmin } = await import("@/lib/premium.server");
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const actions =
      data.filter === "premium"
        ? AUDIT_ACTIONS.filter((a) => a.startsWith("premium."))
        : data.filter === "verified"
          ? AUDIT_ACTIONS.filter((a) => a.startsWith("profile.verified"))
          : AUDIT_ACTIONS;

    const { data: rows, error } = await supabaseAdmin
      .from("audit_logs")
      .select("id, action, target, actor_user_id, ip, user_agent, metadata, created_at")
      .in("action", actions as unknown as string[])
      .order("created_at", { ascending: false })
      .limit(data.limit);
    if (error) throw new Error(error.message);

    const list = rows ?? [];
    const ids = new Set<string>();
    for (const r of list) {
      if (r.actor_user_id) ids.add(r.actor_user_id);
      const meta = (r.metadata ?? {}) as Record<string, string | number | boolean | null>;
      const metaUser = typeof meta["user_id"] === "string" ? (meta["user_id"] as string) : null;
      if (metaUser) ids.add(metaUser);
      if (r.target && /^[0-9a-f-]{36}$/i.test(r.target)) ids.add(r.target);
    }

    const { data: profiles } = ids.size
      ? await supabaseAdmin.from("profiles").select("id, name, username").in("id", [...ids])
      : { data: [] as { id: string; name: string | null; username: string | null }[] };
    const byId = new Map((profiles ?? []).map((p) => [p.id, p]));

    return list.map((r) => {
      const meta = (r.metadata ?? {}) as Record<string, string | number | boolean | null>;
      const metaUser = typeof meta["user_id"] === "string" ? (meta["user_id"] as string) : null;
      const targetId = metaUser ?? (r.target && /^[0-9a-f-]{36}$/i.test(r.target) ? r.target : null);
      return {
        ...r,
        metadata: meta,
        actor: (r.actor_user_id && byId.get(r.actor_user_id)) || null,
        targetUser: (targetId && byId.get(targetId)) || null,
      } as AuditRow;
    });
  });
