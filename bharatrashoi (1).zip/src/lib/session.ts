import { useEffect, useState } from "react";

const KEY = "bharat-rasoi:session-token";

export function getSessionToken(): string {
  if (typeof window === "undefined") return "ssr";
  let token = localStorage.getItem(KEY);
  if (!token) {
    token = crypto.randomUUID();
    localStorage.setItem(KEY, token);
  }
  return token;
}

export function useSessionToken(): string | null {
  const [token, setToken] = useState<string | null>(null);
  useEffect(() => { setToken(getSessionToken()); }, []);
  return token;
}
