import { defineMcp, auth } from "@lovable.dev/mcp-js";
import listRecipesTool from "./tools/list-recipes";
import getRecipeTool from "./tools/get-recipe";
import searchRecipesTool from "./tools/search-recipes";

const SUPABASE_URL = process.env.SUPABASE_URL ?? "";

export default defineMcp({
  name: "bharat-rasoi-mcp",
  title: "Bharat Rasoi",
  version: "0.1.0",
  instructions:
    "Tools for Bharat Rasoi — authentic Indian recipes from every state. Use `list_recipes` to browse by state/category, `search_recipes` for keyword search, and `get_recipe` to fetch full ingredients, steps, and nutrition for a specific dish by slug.",
  auth: auth.oauth.issuer({
    issuer: `${SUPABASE_URL}/auth/v1`,
    acceptedAudiences: "authenticated",
    resourceName: "Bharat Rasoi MCP",
  }),
  tools: [listRecipesTool, getRecipeTool, searchRecipesTool],
});
