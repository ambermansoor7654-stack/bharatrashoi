import { defineTool } from "@lovable.dev/mcp-js";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";

export default defineTool({
  name: "search_recipes",
  title: "Search recipes",
  description:
    "Full-text search across published Bharat Rasoi recipes by name, description, and tags. Returns matching recipes with basic metadata.",
  inputSchema: {
    query: z.string().min(1).describe("Search text, e.g. 'paneer', 'sweet', 'gulab jamun'."),
    limit: z.number().int().min(1).max(50).optional().describe("Max rows to return (default 20)."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ query, limit }) => {
    const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_PUBLISHABLE_KEY!, {
      auth: { persistSession: false, autoRefreshToken: false },
    });
    const escaped = query.replace(/[%,]/g, " ").trim();
    const pattern = `%${escaped}%`;
    const { data, error } = await supabase
      .from("recipes")
      .select("id,slug,name,state,category,description,image_url,views")
      .eq("published", true)
      .or(`name.ilike.${pattern},description.ilike.${pattern}`)
      .limit(limit ?? 20);
    if (error) return { content: [{ type: "text", text: error.message }], isError: true };
    return {
      content: [{ type: "text", text: JSON.stringify(data ?? []) }],
      structuredContent: { results: data ?? [] },
    };
  },
});
