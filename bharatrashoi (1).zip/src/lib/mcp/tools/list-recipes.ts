import { defineTool } from "@lovable.dev/mcp-js";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";

export default defineTool({
  name: "list_recipes",
  title: "List recipes",
  description:
    "List published recipes from Bharat Rasoi. Optionally filter by Indian state, category, or featured flag. Returns lightweight metadata (id, slug, name, state, category, description, views).",
  inputSchema: {
    state: z.string().optional().describe("Filter by Indian state name, e.g. 'Rajasthan'. Use 'Other' for international/fusion dishes."),
    category: z.string().optional().describe("Filter by category, e.g. 'Curry', 'Sweet', 'Bread'."),
    featured: z.boolean().optional().describe("If true, only return featured recipes."),
    limit: z.number().int().min(1).max(100).optional().describe("Max rows to return (default 25)."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ state, category, featured, limit }) => {
    const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_PUBLISHABLE_KEY!, {
      auth: { persistSession: false, autoRefreshToken: false },
    });
    let q = supabase
      .from("recipes")
      .select("id,slug,name,state,region,category,description,image_url,featured,views,created_at")
      .eq("published", true)
      .order("created_at", { ascending: false })
      .limit(limit ?? 25);
    if (state) q = q.eq("state", state);
    if (category) q = q.eq("category", category);
    if (typeof featured === "boolean") q = q.eq("featured", featured);
    const { data, error } = await q;
    if (error) return { content: [{ type: "text", text: error.message }], isError: true };
    return {
      content: [{ type: "text", text: JSON.stringify(data ?? []) }],
      structuredContent: { recipes: data ?? [] },
    };
  },
});
