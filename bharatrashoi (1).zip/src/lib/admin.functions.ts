import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const ADMIN_EMAILS = ["ambermansoor880@gmail.com", "ambermansoor880@gmai.com"];

export const syncAdminRole = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const emailFromToken = typeof context.claims.email === "string" ? context.claims.email : "";
    const email = emailFromToken.toLowerCase();

    if (!ADMIN_EMAILS.includes(email)) {
      const { data } = await context.supabase.rpc("has_role", {
        _user_id: context.userId,
        _role: "admin",
      });
      return { isAdmin: Boolean(data), email };
    }

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error: userRoleError } = await supabaseAdmin
      .from("user_roles")
      .upsert({ user_id: context.userId, role: "user" }, { onConflict: "user_id,role" });
    if (userRoleError) throw new Error(userRoleError.message);

    const { error: adminRoleError } = await supabaseAdmin
      .from("user_roles")
      .upsert({ user_id: context.userId, role: "admin" }, { onConflict: "user_id,role" });
    if (adminRoleError) throw new Error(adminRoleError.message);

    return { isAdmin: true, email };
  });