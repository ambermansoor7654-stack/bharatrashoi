import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { PLANS, FREE_STATE, type PlanId, type PremiumState } from "@/lib/premium";

const PlanSchema = z.enum(["monthly", "yearly"]);

export const getPremiumState = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<PremiumState> => {
    const { ensureProfile, expireIfNeeded } = await import("@/lib/premium.server");
    const profile = await ensureProfile(context.userId, context.claims as Record<string, unknown>);
    const { profile: fresh, justExpired } = await expireIfNeeded(profile);

    const { data: adminFlag } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    const isAdmin = Boolean(adminFlag);

    const { data: pending } = await context.supabase
      .from("payments")
      .select("id")
      .eq("user_id", context.userId)
      .eq("status", "pending")
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    return {
      ...FREE_STATE,
      signedIn: true,
      isAdmin,
      // Admin has permanent premium — no payment, no expiry.
      isPremium: isAdmin || fresh.is_premium,
      verified: isAdmin || fresh.verified,
      plan: isAdmin ? null : ((fresh.premium_plan as PlanId | null) ?? null),
      startDate: fresh.premium_start_date,
      expiryDate: isAdmin ? null : fresh.premium_expiry_date,
      justExpired: justExpired && !isAdmin,
      pendingPaymentId: pending?.id ?? null,
    };
  });

export const submitPaymentRequest = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        plan: PlanSchema,
        reference: z.string().trim().min(6, "Enter the full UPI reference / UTR number").max(40),
        note: z.string().trim().max(300).optional(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { recordAudit } = await import("@/lib/audit.server");

    const reference = data.reference.replace(/\s+/g, "");

    const { data: dupe } = await supabaseAdmin
      .from("payments")
      .select("id, user_id, status")
      .ilike("reference", reference)
      .maybeSingle();
    // A rejected attempt by the same user may be resubmitted (retry flow).
    const retryingOwnRejected = dupe && dupe.user_id === context.userId && dupe.status === "rejected";
    if (dupe && !retryingOwnRejected) {
      return {
        ok: false as const,
        code: "duplicate" as const,
        message:
          dupe.user_id === context.userId
            ? dupe.status === "approved"
              ? "This reference is already approved — your Premium is active."
              : "You already submitted this reference. We're reviewing it."
            : "This payment reference is already used. Please check your UPI app and enter the correct one.",
      };
    }

    const { data: pending } = await supabaseAdmin
      .from("payments")
      .select("id")
      .eq("user_id", context.userId)
      .eq("status", "pending")
      .maybeSingle();
    if (pending) {
      return {
        ok: false as const,
        code: "pending" as const,
        message: "You already have a payment under review. It usually takes a few minutes.",
      };
    }

    const { data: created, error } = await supabaseAdmin
      .from("payments")
      .insert({
        user_id: context.userId,
        plan: data.plan,
        amount: PLANS[data.plan].price,
        currency: "INR",
        method: "upi_qr",
        reference,
        note: data.note ?? null,
        status: "pending",
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);

    await recordAudit({
      action: "premium.payment_submitted",
      target: created.id,
      actorUserId: context.userId,
      metadata: { plan: data.plan, amount: PLANS[data.plan].price },
    });

    return { ok: true as const, paymentId: created.id };
  });

export const listMyPayments = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("payments")
      .select("id, plan, amount, currency, status, reference, note, created_at, reviewed_at")
      .eq("user_id", context.userId)
      .order("created_at", { ascending: false })
      .limit(50);
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const cancelSubscription = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { recordAudit } = await import("@/lib/audit.server");

    const { error } = await supabaseAdmin
      .from("profiles")
      .update({ is_premium: false, premium_plan: null, premium_expiry_date: new Date().toISOString() })
      .eq("id", context.userId);
    if (error) throw new Error(error.message);

    await recordAudit({ action: "premium.cancelled", actorUserId: context.userId });
    return { ok: true as const };
  });

/** Recompute premium from approved payments — used by "Restore purchase". */
export const restorePurchase = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { PLANS: PLAN_MAP } = await import("@/lib/premium");

    const { data: approved, error } = await supabaseAdmin
      .from("payments")
      .select("id, plan, created_at, reviewed_at")
      .eq("user_id", context.userId)
      .eq("status", "approved")
      .order("created_at", { ascending: true });
    if (error) throw new Error(error.message);
    if (!approved?.length) return { ok: false as const, message: "No approved payment found for this account." };

    let cursor = 0;
    let plan: PlanId = "monthly";
    let start: string | null = null;
    let lastId = "";
    for (const row of approved) {
      const from = new Date(row.reviewed_at ?? row.created_at).getTime();
      const base = Math.max(from, cursor);
      plan = row.plan as PlanId;
      start = new Date(base).toISOString();
      cursor = base + PLAN_MAP[plan].days * 86_400_000;
      lastId = row.id;
    }

    const active = cursor > Date.now();
    const { error: updateError } = await supabaseAdmin
      .from("profiles")
      .update({
        is_premium: active,
        premium_plan: active ? plan : null,
        premium_start_date: start,
        premium_expiry_date: new Date(cursor).toISOString(),
        payment_id: lastId,
      })
      .eq("id", context.userId);
    if (updateError) throw new Error(updateError.message);

    return active
      ? { ok: true as const, message: "Premium restored.", expiryDate: new Date(cursor).toISOString() }
      : { ok: false as const, message: "Your last premium plan has already expired." };
  });

/* ---------------------------------- admin ---------------------------------- */

export const listAllPayments = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { assertAdmin } = await import("@/lib/premium.server");
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: payments, error } = await supabaseAdmin
      .from("payments")
      .select("id, user_id, plan, amount, currency, status, reference, note, created_at, reviewed_at")
      .order("created_at", { ascending: false })
      .limit(200);
    if (error) throw new Error(error.message);

    const ids = [...new Set((payments ?? []).map((p) => p.user_id))];
    const { data: profiles } = ids.length
      ? await supabaseAdmin.from("profiles").select("id, name, email, verified, is_premium, premium_expiry_date").in("id", ids)
      : { data: [] as { id: string; name: string | null; email: string | null; verified: boolean; is_premium: boolean; premium_expiry_date: string | null }[] };

    const byId = new Map((profiles ?? []).map((p) => [p.id, p]));
    return (payments ?? []).map((p) => ({
      ...p,
      user: byId.get(p.user_id) ?? null,
    }));
  });

export const reviewPayment = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({ paymentId: z.string().uuid(), decision: z.enum(["approved", "rejected"]) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { assertAdmin, assertNotSelf, activatePremium } = await import("@/lib/premium.server");
    await assertAdmin(context.supabase, context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { recordAudit } = await import("@/lib/audit.server");

    const { data: payment, error } = await supabaseAdmin
      .from("payments")
      .select("id, user_id, plan, status")
      .eq("id", data.paymentId)
      .single();
    if (error) throw new Error(error.message);
    // Admins cannot self-approve — premium can only be unlocked for another account.
    assertNotSelf(context.userId, payment.user_id);
    if (payment.status !== "pending") {
      return { ok: false as const, message: `This payment is already ${payment.status}.` };
    }

    const { error: updateError } = await supabaseAdmin
      .from("payments")
      .update({ status: data.decision, reviewed_by: context.userId, reviewed_at: new Date().toISOString() })
      .eq("id", payment.id);
    if (updateError) throw new Error(updateError.message);

    let expiryDate: string | null = null;
    if (data.decision === "approved") {
      expiryDate = await activatePremium(payment.user_id, payment.plan as PlanId, payment.id);
    }

    await recordAudit({
      action: `premium.payment_${data.decision}`,
      target: payment.id,
      actorUserId: context.userId,
      metadata: { user_id: payment.user_id, plan: payment.plan },
    });

    return { ok: true as const, expiryDate };
  });

export const setUserVerified = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ userId: z.string().uuid(), verified: z.boolean() }).parse(input))
  .handler(async ({ data, context }) => {
    const { assertAdmin, assertNotSelf } = await import("@/lib/premium.server");
    await assertAdmin(context.supabase, context.userId);
    assertNotSelf(context.userId, data.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { recordAudit } = await import("@/lib/audit.server");

    const { error } = await supabaseAdmin.from("profiles").update({ verified: data.verified }).eq("id", data.userId);
    if (error) throw new Error(error.message);

    await recordAudit({
      action: data.verified ? "profile.verified_granted" : "profile.verified_revoked",
      target: data.userId,
      actorUserId: context.userId,
    });
    return { ok: true as const };
  });

export const grantPremiumManually = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ userId: z.string().uuid(), plan: PlanSchema }).parse(input))
  .handler(async ({ data, context }) => {
    const { assertAdmin, assertNotSelf, activatePremium } = await import("@/lib/premium.server");
    await assertAdmin(context.supabase, context.userId);
    assertNotSelf(context.userId, data.userId);
    const { recordAudit } = await import("@/lib/audit.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: created, error } = await supabaseAdmin
      .from("payments")
      .insert({
        user_id: data.userId,
        plan: data.plan,
        amount: PLANS[data.plan].price,
        currency: "INR",
        method: "admin_grant",
        status: "approved",
        reviewed_by: context.userId,
        reviewed_at: new Date().toISOString(),
        note: "Granted by admin",
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);

    const expiryDate = await activatePremium(data.userId, data.plan, created.id);
    await recordAudit({
      action: "premium.granted_by_admin",
      target: data.userId,
      actorUserId: context.userId,
      metadata: { plan: data.plan },
    });
    return { ok: true as const, expiryDate };
  });
