// Client-side recipe PDF export via a print-ready document (no extra deps).
export type PdfRecipe = {
  name: string;
  description: string;
  state?: string;
  category?: string;
  prep_time?: string;
  cook_time?: string;
  difficulty?: string;
  image_url?: string | null;
  ingredients: string[];
  steps: string[];
  nutrition?: Record<string, number | string | null> | null;
};

function esc(value: string) {
  return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function buildHtml(recipe: PdfRecipe, imageSrc?: string | null) {
  const nutrition = Object.entries(recipe.nutrition ?? {}).filter(([, v]) => v !== null && v !== undefined && v !== "");
  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8" />
<title>${esc(recipe.name)} — Bharat Rasoi</title>
<style>
  @page { margin: 18mm 16mm; }
  * { box-sizing: border-box; }
  body { font-family: Georgia, "Times New Roman", serif; color: #23180c; margin: 0; }
  header { border-bottom: 3px solid #e9a13b; padding-bottom: 12px; margin-bottom: 18px; }
  .brand { font-size: 11px; letter-spacing: .22em; text-transform: uppercase; color: #b9762a; }
  h1 { font-size: 30px; margin: 6px 0 4px; }
  .meta { font-size: 12px; color: #6b5945; }
  .desc { margin-top: 10px; font-size: 13.5px; line-height: 1.55; }
  img.hero { width: 100%; max-height: 260px; object-fit: cover; border-radius: 10px; margin: 14px 0 4px; }
  h2 { font-size: 16px; margin: 22px 0 8px; color: #b9762a; text-transform: uppercase; letter-spacing: .08em; }
  ul, ol { margin: 0; padding-left: 20px; }
  li { font-size: 13px; line-height: 1.6; margin-bottom: 4px; }
  .stats { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 12px; }
  .stat { border: 1px solid #e6dccc; border-radius: 8px; padding: 6px 10px; font-size: 11.5px; }
  .stat b { display: block; font-size: 13px; }
  footer { margin-top: 26px; border-top: 1px solid #e6dccc; padding-top: 8px; font-size: 10.5px; color: #8a7a67; }
  @media print { a { text-decoration: none; color: inherit; } }
</style></head>
<body>
  <header>
    <div class="brand">Bharat Rasoi</div>
    <h1>${esc(recipe.name)}</h1>
    <div class="meta">${[recipe.category, recipe.state].filter(Boolean).map((v) => esc(String(v))).join(" · ")}</div>
    <div class="desc">${esc(recipe.description || "")}</div>
    <div class="stats">
      ${[
        ["Prep", recipe.prep_time],
        ["Cook", recipe.cook_time],
        ["Difficulty", recipe.difficulty],
      ]
        .filter(([, v]) => Boolean(v))
        .map(([k, v]) => `<div class="stat">${esc(String(k))}<b>${esc(String(v))}</b></div>`)
        .join("")}
    </div>
  </header>
  ${imageSrc ? `<img class="hero" src="${imageSrc}" alt="${esc(recipe.name)}" />` : ""}
  <h2>Ingredients</h2>
  <ul>${recipe.ingredients.map((i) => `<li>${esc(i)}</li>`).join("")}</ul>
  <h2>Method</h2>
  <ol>${recipe.steps.map((s) => `<li>${esc(s)}</li>`).join("")}</ol>
  ${
    nutrition.length
      ? `<h2>Nutrition (per serving)</h2><div class="stats">${nutrition
          .map(([k, v]) => `<div class="stat">${esc(k.replace(/_/g, " "))}<b>${esc(String(v))}</b></div>`)
          .join("")}</div>`
      : ""
  }
  <footer>Downloaded from Bharat Rasoi · Premium recipe PDF · ${new Date().toLocaleDateString("en-IN")}</footer>
</body></html>`;
}

/** Opens the browser print dialog with a styled recipe sheet ("Save as PDF"). */
export function downloadRecipePdf(recipe: PdfRecipe, imageSrc?: string | null) {
  const win = window.open("", "_blank", "width=880,height=1000");
  if (!win) throw new Error("Pop-up blocked — allow pop-ups to download the PDF.");
  win.document.write(buildHtml(recipe, imageSrc));
  win.document.close();
  const start = () => {
    win.focus();
    win.print();
  };
  if (win.document.readyState === "complete") setTimeout(start, 300);
  else win.onload = () => setTimeout(start, 300);
}
