// Client-safe premium constants & types (no server imports).
import upiQr from "@/assets/amber-upi-qr.jpg.asset.json";

export const UPI_QR_URL = upiQr.url;
export const UPI_PAYEE_NAME = "AMBER Mansoori";

export type PlanId = "monthly" | "yearly";

export type Plan = {
  id: PlanId;
  label: string;
  price: number;
  days: number;
  cadence: string;
  perMonth: string;
  popular?: boolean;
  save?: string;
};

export const PLANS: Record<PlanId, Plan> = {
  monthly: {
    id: "monthly",
    label: "Monthly",
    price: 99,
    days: 30,
    cadence: "per month",
    perMonth: "₹99/mo",
  },
  yearly: {
    id: "yearly",
    label: "Yearly",
    price: 799,
    days: 365,
    cadence: "per year",
    perMonth: "₹67/mo",
    popular: true,
    save: "Save 33%",
  },
};

export const PLAN_LIST: Plan[] = [PLANS.monthly, PLANS.yearly];

export const PREMIUM_BENEFITS = [
  "No ads anywhere in the app",
  "Unlimited AI recipe generation",
  "Premium Indian recipes library",
  "Exclusive state-wise recipes",
  "Download any recipe as PDF",
  "Save unlimited favorites",
  "Offline recipe access",
  "Early access to new features",
  "Priority AI response speed",
] as const;

export const FREE_LIMITS = {
  favorites: 10,
  aiRecipesPerDay: Infinity,
} as const;

export type PremiumState = {
  signedIn: boolean;
  isAdmin: boolean;
  isPremium: boolean;
  verified: boolean;
  plan: PlanId | null;
  startDate: string | null;
  expiryDate: string | null;
  justExpired: boolean;
  pendingPaymentId: string | null;
};

export const FREE_STATE: PremiumState = {
  signedIn: false,
  isAdmin: false,
  isPremium: false,
  verified: false,
  plan: null,
  startDate: null,
  expiryDate: null,
  justExpired: false,
  pendingPaymentId: null,
};

export function formatDate(value?: string | null) {
  if (!value) return "—";
  return new Date(value).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
}

export function daysLeft(expiry?: string | null) {
  if (!expiry) return 0;
  const ms = new Date(expiry).getTime() - Date.now();
  return Math.max(0, Math.ceil(ms / 86_400_000));
}
