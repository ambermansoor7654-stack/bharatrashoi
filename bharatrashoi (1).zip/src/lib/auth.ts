import { createContext, createElement, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { syncAdminRole } from "@/lib/admin.functions";
import type { Session, User } from "@supabase/supabase-js";

export const ADMIN_EMAILS = ["ambermansoor880@gmail.com", "ambermansoor880@gmai.com"] as const;

export function isAmberAdminEmail(email?: string | null) {
  return Boolean(email && ADMIN_EMAILS.includes(email.trim().toLowerCase() as (typeof ADMIN_EMAILS)[number]));
}

export type AuthState = {
  loading: boolean;
  session: Session | null;
  user: User | null;
  isAdmin: boolean;
};

const initialAuthState: AuthState = {
  loading: true,
  session: null,
  user: null,
  isAdmin: false,
};

const AuthContext = createContext<AuthState>(initialAuthState);

export function AuthProvider({ children }: { children: ReactNode }) {
  const syncRole = useServerFn(syncAdminRole);
  const syncRoleRef = useRef(syncRole);
  const [state, setState] = useState<AuthState>(initialAuthState);
  const syncedForUser = useRef<string | null>(null);

  syncRoleRef.current = syncRole;

  useEffect(() => {
    let mounted = true;

    const resolveSession = async (session: Session | null) => {
      const user = session?.user ?? null;
      if (!user) {
        if (mounted) setState({ loading: false, session: null, user: null, isAdmin: false });
        return;
      }

      // The owner email must feel instant in the UI.  We mark it admin immediately,
      // then sync the DB role in the background so RLS-protected admin writes work too.
      if (isAmberAdminEmail(user.email)) {
        if (mounted) setState({ loading: false, session, user, isAdmin: true });
        if (syncedForUser.current !== user.id) {
          syncedForUser.current = user.id;
          queueMicrotask(() => {
            syncRoleRef.current().catch(() => {
              // UI admin access is email-locked; DB sync retries on the next auth refresh.
              syncedForUser.current = null;
            });
          });
        }
        return;
      }

      // Only Amber's email is admin. Everyone else stays normal and navigation stays instant.
      if (mounted) setState({ loading: false, session, user, isAdmin: false });
    };

    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      // Keep Supabase auth callbacks synchronous to avoid UI stalls/deadlocks.
      queueMicrotask(() => resolveSession(session));
    });

    supabase.auth
      .getSession()
      .then(({ data: { session } }) => resolveSession(session))
      .catch(() => mounted && setState({ loading: false, session: null, user: null, isAdmin: false }));

    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  const value = useMemo(() => state, [state]);
  return createElement(AuthContext.Provider, { value }, children);
}

export function useAuth(): AuthState {
  return useContext(AuthContext);
}
