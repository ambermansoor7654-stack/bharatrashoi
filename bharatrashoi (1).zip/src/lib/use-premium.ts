import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getPremiumState } from "@/lib/premium.functions";
import { FREE_STATE, type PremiumState } from "@/lib/premium";
import { useAuth } from "@/lib/auth";

export const PREMIUM_QUERY_KEY = ["premium-state"] as const;

export function usePremium() {
  const { user, loading } = useAuth();
  const fetchState = useServerFn(getPremiumState);

  const query = useQuery<PremiumState>({
    queryKey: [...PREMIUM_QUERY_KEY, user?.id ?? "anon"],
    queryFn: () => fetchState(),
    enabled: Boolean(user),
    staleTime: 60_000,
  });

  return {
    ...(query.data ?? FREE_STATE),
    loading: loading || (Boolean(user) && query.isLoading),
    refetch: query.refetch,
  };
}

export function useRefreshPremium() {
  const queryClient = useQueryClient();
  return () => queryClient.invalidateQueries({ queryKey: PREMIUM_QUERY_KEY });
}
