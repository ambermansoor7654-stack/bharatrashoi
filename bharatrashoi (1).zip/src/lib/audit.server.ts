// Server-only audit logging helper. Import inside server-function handlers.
import { getRequest, getRequestIP } from "@tanstack/react-start/server";

export type AuditEntry = {
  action: string;
  target?: string | null;
  actorUserId?: string | null;
  metadata?: Record<string, unknown>;
};

export async function recordAudit(entry: AuditEntry): Promise<void> {
  try {
    let ip: string | null = null;
    let userAgent: string | null = null;
    try {
      ip = getRequestIP({ xForwardedFor: true }) ?? null;
      userAgent = getRequest()?.headers.get("user-agent") ?? null;
    } catch {
      // Called outside a request context — leave request fields null.
    }

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("audit_logs").insert({
      action: entry.action,
      target: entry.target ?? null,
      actor_user_id: entry.actorUserId ?? null,
      ip,
      user_agent: userAgent,
      metadata: (entry.metadata ?? {}) as never,
    });
    if (error) console.error("[audit] insert failed", entry.action, error.message);
  } catch (err) {
    // Audit logging must never break the caller path.
    console.error("[audit] unexpected failure", entry.action, err);
  }
}
