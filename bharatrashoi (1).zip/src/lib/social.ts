// Real, persistent social layer (profiles, likes, saves, follows, ratings).
// Everything here talks to the live database through RLS — no mock data.
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export const PUBLIC_PROFILE_COLS =
  "id, username, display_name, name, bio, location, avatar_url, food_preferences, specialties, is_creator, creator_status, verified, onboarded";

export type PublicProfile = {
  id: string;
  username: string | null;
  display_name: string | null;
  name: string | null;
  bio: string | null;
  location: string | null;
  avatar_url: string | null;
  food_preferences: string[];
  specialties: string[];
  is_creator: boolean;
  creator_status: string;
  verified: boolean;
  onboarded: boolean;
};

export type ProfileStats = {
  user_id: string;
  followers: number;
  following: number;
  recipes_count: number;
  likes_received: number;
  saves_received: number;
  saved_count: number;
};

export type RecipeStats = {
  recipe_id: string;
  likes: number;
  saves: number;
  ratings_count: number;
  rating: number;
};

export function profileLabel(p?: Partial<PublicProfile> | null) {
  return p?.display_name || p?.name || (p?.username ? `@${p.username}` : "Bharat Rasoi user");
}

export function profileHandle(p?: Partial<PublicProfile> | null) {
  return p?.username ? `@${p.username}` : "";
}

/* ---------------------------------------------------------------- profiles */

export function useMyProfile() {
  const { user } = useAuth();
  return useQuery({
    queryKey: ["my-profile", user?.id],
    enabled: Boolean(user?.id),
    staleTime: 30_000,
    queryFn: async (): Promise<PublicProfile | null> => {
      const { data, error } = await supabase
        .from("profiles")
        .select(PUBLIC_PROFILE_COLS)
        .eq("id", user!.id)
        .maybeSingle();
      if (error) throw new Error(error.message);
      return (data as PublicProfile | null) ?? null;
    },
  });
}

export function useProfileByUsername(username: string) {
  return useQuery({
    queryKey: ["profile-by-username", username.toLowerCase()],
    queryFn: async (): Promise<PublicProfile | null> => {
      const { data, error } = await supabase
        .from("profiles")
        .select(PUBLIC_PROFILE_COLS)
        .ilike("username", username)
        .maybeSingle();
      if (error) throw new Error(error.message);
      return (data as PublicProfile | null) ?? null;
    },
  });
}

export function useProfileStats(userId?: string | null) {
  return useQuery({
    queryKey: ["profile-stats", userId],
    enabled: Boolean(userId),
    queryFn: async (): Promise<ProfileStats> => {
      const { data, error } = await supabase
        .from("profile_stats")
        .select("*")
        .eq("user_id", userId!)
        .maybeSingle();
      if (error) throw new Error(error.message);
      return (
        (data as ProfileStats | null) ?? {
          user_id: userId!,
          followers: 0,
          following: 0,
          recipes_count: 0,
          likes_received: 0,
          saves_received: 0,
          saved_count: 0,
        }
      );
    },
  });
}

export async function isUsernameAvailable(username: string, selfId?: string) {
  const { data, error } = await supabase
    .from("profiles")
    .select("id")
    .ilike("username", username)
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) return true;
  return data.id === selfId;
}

export async function uploadAvatar(userId: string, file: File) {
  const ext = (file.name.split(".").pop() || "jpg").toLowerCase().replace(/[^a-z0-9]/g, "");
  const path = `${userId}/${Date.now()}.${ext || "jpg"}`;
  const { error } = await supabase.storage.from("avatars").upload(path, file, { upsert: true });
  if (error) throw new Error(error.message);
  return path;
}

export type ProfileUpdate = {
  username?: string;
  display_name?: string | null;
  bio?: string | null;
  location?: string | null;
  avatar_url?: string | null;
  food_preferences?: string[];
  onboarded?: boolean;
};

export function useUpdateMyProfile() {
  const { user } = useAuth();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (patch: ProfileUpdate) => {
      if (!user?.id) throw new Error("Not signed in");
      const { error } = await supabase.from("profiles").update(patch).eq("id", user.id);
      if (error) {
        if (/profiles_username_lower_key/.test(error.message)) {
          throw new Error("Yeh username already taken hai — dusra try karo.");
        }
        throw new Error(error.message);
      }
      return true;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["my-profile"] });
      qc.invalidateQueries({ queryKey: ["profile-by-username"] });
    },
  });
}

/* ------------------------------------------------------- recipe engagement */

export function useRecipeStats(recipeId?: string | null) {
  return useQuery({
    queryKey: ["recipe-stats", recipeId],
    enabled: Boolean(recipeId),
    queryFn: async (): Promise<RecipeStats> => {
      const { data, error } = await supabase
        .from("recipe_stats")
        .select("*")
        .eq("recipe_id", recipeId!)
        .maybeSingle();
      if (error) throw new Error(error.message);
      return (
        (data as RecipeStats | null) ?? { recipe_id: recipeId!, likes: 0, saves: 0, ratings_count: 0, rating: 0 }
      );
    },
  });
}

export function useMyRecipeFlags(recipeId?: string | null) {
  const { user } = useAuth();
  return useQuery({
    queryKey: ["my-recipe-flags", user?.id, recipeId],
    enabled: Boolean(user?.id && recipeId),
    queryFn: async () => {
      const [liked, saved] = await Promise.all([
        supabase.from("recipe_likes").select("id").eq("user_id", user!.id).eq("recipe_id", recipeId!).maybeSingle(),
        supabase.from("recipe_saves").select("id").eq("user_id", user!.id).eq("recipe_id", recipeId!).maybeSingle(),
      ]);
      return { liked: Boolean(liked.data), saved: Boolean(saved.data) };
    },
  });
}

function useToggleRow(table: "recipe_likes" | "recipe_saves", recipeId?: string | null) {
  const { user } = useAuth();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (on: boolean) => {
      if (!user?.id || !recipeId) throw new Error("Sign in karo pehle");
      if (on) {
        const { error } = await supabase.from(table).insert({ user_id: user.id, recipe_id: recipeId });
        if (error && !/duplicate key/i.test(error.message)) throw new Error(error.message);
      } else {
        const { error } = await supabase.from(table).delete().eq("user_id", user.id).eq("recipe_id", recipeId);
        if (error) throw new Error(error.message);
      }
      return on;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["recipe-stats", recipeId] });
      qc.invalidateQueries({ queryKey: ["my-recipe-flags"] });
      qc.invalidateQueries({ queryKey: ["saved-recipes"] });
      qc.invalidateQueries({ queryKey: ["profile-stats"] });
    },
  });
}

export const useToggleLike = (recipeId?: string | null) => useToggleRow("recipe_likes", recipeId);
export const useToggleSave = (recipeId?: string | null) => useToggleRow("recipe_saves", recipeId);

export function useSavedRecipes() {
  const { user } = useAuth();
  return useQuery({
    queryKey: ["saved-recipes", user?.id],
    enabled: Boolean(user?.id),
    queryFn: async () => {
      const { data, error } = await supabase
        .from("recipe_saves")
        .select("recipe_id, created_at, recipes(id, slug, name, state, category, description, image_url, author_id, views)")
        .eq("user_id", user!.id)
        .order("created_at", { ascending: false });
      if (error) throw new Error(error.message);
      return (data ?? [])
        .map((r) => (r as unknown as { recipes: SearchRecipe | null }).recipes)
        .filter(Boolean) as SearchRecipe[];
    },
  });
}

/* ------------------------------------------------------------ follow system */

export function useIsFollowing(creatorId?: string | null) {
  const { user } = useAuth();
  return useQuery({
    queryKey: ["is-following", user?.id, creatorId],
    enabled: Boolean(user?.id && creatorId),
    queryFn: async () => {
      const { data, error } = await supabase
        .from("follows")
        .select("id")
        .eq("follower_id", user!.id)
        .eq("creator_id", creatorId!)
        .maybeSingle();
      if (error) throw new Error(error.message);
      return Boolean(data);
    },
  });
}

export function useToggleFollow(creatorId?: string | null) {
  const { user } = useAuth();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (on: boolean) => {
      if (!user?.id) throw new Error("Follow karne ke liye sign in karo");
      if (!creatorId) throw new Error("Creator missing");
      if (creatorId === user.id) throw new Error("Khud ko follow nahi kar sakte 🙂");
      if (on) {
        const { error } = await supabase.from("follows").insert({ follower_id: user.id, creator_id: creatorId });
        if (error && !/duplicate key/i.test(error.message)) throw new Error(error.message);
      } else {
        const { error } = await supabase
          .from("follows")
          .delete()
          .eq("follower_id", user.id)
          .eq("creator_id", creatorId);
        if (error) throw new Error(error.message);
      }
      return on;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["is-following"] });
      qc.invalidateQueries({ queryKey: ["profile-stats"] });
      qc.invalidateQueries({ queryKey: ["top-creators"] });
    },
  });
}

/* -------------------------------------------------------------- real search */

export type SearchRecipe = {
  id: string;
  slug: string;
  name: string;
  state: string;
  category: string;
  description: string;
  image_url: string | null;
  author_id: string | null;
  views: number;
};

export type SearchResult = {
  recipes: (SearchRecipe & { author: PublicProfile | null; stats: RecipeStats })[];
  creators: (PublicProfile & { stats: ProfileStats })[];
};

const EMPTY_RESULT: SearchResult = { recipes: [], creators: [] };

export async function searchEverything(term: string): Promise<SearchResult> {
  const q = term.trim();
  if (q.length < 2) return EMPTY_RESULT;
  const like = `%${q}%`;

  const { data: recipeRows, error } = await supabase
    .from("recipes")
    .select("id, slug, name, state, category, description, image_url, author_id, views, cuisine, tags")
    .eq("published", true)
    .or(
      [
        `name.ilike.${like}`,
        `description.ilike.${like}`,
        `category.ilike.${like}`,
        `state.ilike.${like}`,
        `cuisine.ilike.${like}`,
        `ingredients.cs.["${q}"]`,
      ].join(","),
    )
    .limit(40);
  if (error) throw new Error(error.message);

  let recipes = (recipeRows ?? []) as unknown as SearchRecipe[];

  // Tag matches (array column needs its own filter)
  const { data: tagRows } = await supabase
    .from("recipes")
    .select("id, slug, name, state, category, description, image_url, author_id, views")
    .eq("published", true)
    .contains("tags", [q.toLowerCase()])
    .limit(20);
  for (const r of (tagRows ?? []) as unknown as SearchRecipe[]) {
    if (!recipes.some((x) => x.id === r.id)) recipes.push(r);
  }

  // Creator name / username matches
  const { data: creatorRows } = await supabase
    .from("profiles")
    .select(PUBLIC_PROFILE_COLS)
    .or([`username.ilike.${like}`, `display_name.ilike.${like}`, `name.ilike.${like}`].join(","))
    .eq("is_creator", true)
    .limit(12);

  const authorIds = Array.from(new Set(recipes.map((r) => r.author_id).filter(Boolean))) as string[];
  const [{ data: authorRows }, { data: statRows }] = await Promise.all([
    authorIds.length
      ? supabase.from("profiles").select(PUBLIC_PROFILE_COLS).in("id", authorIds)
      : Promise.resolve({ data: [] as PublicProfile[] }),
    recipes.length
      ? supabase.from("recipe_stats").select("*").in("recipe_id", recipes.map((r) => r.id))
      : Promise.resolve({ data: [] as RecipeStats[] }),
  ]);

  const authorById = new Map(((authorRows ?? []) as PublicProfile[]).map((p) => [p.id, p]));
  const statById = new Map(((statRows ?? []) as RecipeStats[]).map((s) => [s.recipe_id, s]));

  const decorated = recipes.map((r) => ({
    ...r,
    author: r.author_id ? authorById.get(r.author_id) ?? null : null,
    stats: statById.get(r.id) ?? { recipe_id: r.id, likes: 0, saves: 0, ratings_count: 0, rating: 0 },
  }));

  decorated.sort((a, b) => b.stats.likes - a.stats.likes || b.views - a.views);

  // Top creators = creators with matching recipes, plus creator-name matches
  const creatorIds = Array.from(
    new Set([
      ...decorated.map((r) => r.author_id).filter(Boolean),
      ...((creatorRows ?? []) as PublicProfile[]).map((c) => c.id),
    ]),
  ) as string[];

  let creators: (PublicProfile & { stats: ProfileStats })[] = [];
  if (creatorIds.length) {
    const [{ data: profs }, { data: pstats }] = await Promise.all([
      supabase.from("profiles").select(PUBLIC_PROFILE_COLS).in("id", creatorIds).eq("is_creator", true),
      supabase.from("profile_stats").select("*").in("user_id", creatorIds),
    ]);
    const statsById = new Map(((pstats ?? []) as ProfileStats[]).map((s) => [s.user_id, s]));
    creators = ((profs ?? []) as PublicProfile[]).map((p) => ({
      ...p,
      stats:
        statsById.get(p.id) ?? {
          user_id: p.id,
          followers: 0,
          following: 0,
          recipes_count: 0,
          likes_received: 0,
          saves_received: 0,
          saved_count: 0,
        },
    }));
    creators.sort(
      (a, b) =>
        Number(b.verified) - Number(a.verified) ||
        b.stats.likes_received - a.stats.likes_received ||
        b.stats.followers - a.stats.followers,
    );
  }

  return { recipes: decorated, creators };
}

export function useSearchEverything(term: string) {
  return useQuery({
    queryKey: ["search-everything", term.trim().toLowerCase()],
    enabled: term.trim().length >= 2,
    queryFn: () => searchEverything(term),
  });
}

export function useCreatorRecipes(authorId?: string | null, opts?: { includeDrafts?: boolean }) {
  return useQuery({
    queryKey: ["creator-recipes", authorId, Boolean(opts?.includeDrafts)],
    enabled: Boolean(authorId),
    queryFn: async () => {
      let query = supabase
        .from("recipes")
        .select("id, slug, name, state, category, description, image_url, author_id, views, status, published, locked")
        .eq("author_id", authorId!)
        .order("created_at", { ascending: false });
      if (!opts?.includeDrafts) query = query.eq("published", true);
      const { data, error } = await query;
      if (error) throw new Error(error.message);
      return (data ?? []) as unknown as (SearchRecipe & {
        status: string;
        published: boolean;
        locked: boolean;
      })[];
    },
  });
}
