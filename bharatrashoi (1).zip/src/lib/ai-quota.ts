export function aiUsedToday() { return 0; }
export function aiRemainingToday() { return Infinity; }
export function recordAiUse() { return 0; }
