import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/** Generates a food photo for a dish via Lovable AI image gateway,
 *  uploads it to the `recipe-images` bucket, and returns the storage path
 *  (which RecipeImage will resolve to a signed URL on the client). */
export const generateRecipeImage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { dish: string; slug?: string; state?: string }) => {
    if (!data?.dish || typeof data.dish !== "string") throw new Error("dish required");
    return {
      dish: data.dish.slice(0, 120),
      slug: (data.slug ?? data.dish).slice(0, 80),
      state: data.state?.slice(0, 60) ?? "",
    };
  })
  .handler(async ({ data, context }) => {
    const { data: isAdmin, error: roleErr } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (roleErr) throw new Error("Role check failed");
    if (!isAdmin) throw new Error("Forbidden: admin only");

    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) throw new Error("AI gateway not configured");

    const prompt = `Hyper-realistic overhead food photography of "${data.dish}"${
      data.state ? `, an authentic ${data.state} cuisine dish` : ""
    }. Plated beautifully on a rustic ceramic plate, warm natural lighting, soft shadows, fresh garnish, vibrant colors, professional restaurant menu photo, ultra detailed, depth of field. No text, no watermark.`;

    const res = await fetch("https://ai.gateway.lovable.dev/v1/images/generations", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "openai/gpt-image-2",
        prompt,
        quality: "low",
        size: "1024x1024",
        n: 1,
      }),
    });

    if (!res.ok) {
      const t = await res.text().catch(() => "");
      throw new Error(`Image generation failed (${res.status}): ${t.slice(0, 200)}`);
    }
    const json: any = await res.json();
    const b64 = json?.data?.[0]?.b64_json;
    if (!b64) throw new Error("AI returned no image data");

    // Decode base64 PNG → bytes
    const binary = Uint8Array.from(atob(b64), c => c.charCodeAt(0));

    const slug = data.slug.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "dish";
    const path = `${slug}-ai-${Date.now()}.png`;

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error: upErr } = await supabaseAdmin.storage
      .from("recipe-images")
      .upload(path, binary, { contentType: "image/png", upsert: true });
    if (upErr) throw new Error(`Storage upload failed: ${upErr.message}`);

    return { path };
  });
