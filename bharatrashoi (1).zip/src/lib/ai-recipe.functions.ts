import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const generateRecipeWithAI = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { dish: string; state?: string }) => {
    if (!data?.dish || typeof data.dish !== "string") throw new Error("dish required");
    return { dish: data.dish.slice(0, 120), state: data.state?.slice(0, 60) ?? "India" };
  })
  .handler(async ({ data, context }) => {
    // Server-side admin check
    const { data: isAdmin, error: roleErr } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (roleErr) throw new Error("Role check failed");
    if (!isAdmin) throw new Error("Forbidden: admin only");

    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) throw new Error("AI gateway not configured");

    const prompt = `Generate a detailed authentic recipe for "${data.dish}" from ${data.state} cuisine. Respond ONLY with valid JSON matching this schema (no markdown, no commentary):
{
  "description": "1-2 sentence description",
  "category": "Main Course|Curry|Dry Sabzi|Dal|Bread|Rice|Snack|Sweet|Drink|Non-Veg",
  "prep_time": "e.g. 15 mins",
  "cook_time": "e.g. 30 mins",
  "difficulty": "Easy|Medium|Hard",
  "ingredients": ["item with quantity", ...],
  "steps": ["clear step", ...],
  "nutrition": { "calories": number, "protein_g": number, "carbs_g": number, "fat_g": number, "fiber_g": number },
  "tags": ["short", "tags"]
}`;

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "openai/gpt-5-nano",
        messages: [
          { role: "system", content: "You are a culinary expert. Return only strict JSON, no prose." },
          { role: "user", content: prompt },
        ],
      }),
    });

    if (!res.ok) {
      const t = await res.text().catch(() => "");
      throw new Error(`AI error ${res.status}: ${t.slice(0, 200)}`);
    }
    const json: any = await res.json();
    const raw: string = json.choices?.[0]?.message?.content ?? "";
    const cleaned = raw.replace(/^```json\s*/i, "").replace(/^```\s*/i, "").replace(/```\s*$/i, "").trim();
    try {
      return JSON.parse(cleaned);
    } catch {
      throw new Error("AI returned invalid JSON");
    }
  });
