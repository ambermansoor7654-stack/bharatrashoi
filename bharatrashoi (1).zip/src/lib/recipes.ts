import { useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type DbRecipe = {
  id: string;
  slug: string;
  name: string;
  state: string;
  region: string;
  category: string;
  description: string;
  image_url: string | null;
  prep_time: string;
  cook_time: string;
  difficulty: string;
  ingredients: string[];
  steps: string[];
  nutrition: { calories?: number; protein_g?: number; carbs_g?: number; fat_g?: number; fiber_g?: number };
  tags: string[];
  featured: boolean;
  published: boolean;
  views: number;
  video_url: string | null;
  created_at: string;
  updated_at: string;
};

export type RecipeFeedItem = Pick<
  DbRecipe,
  "id" | "slug" | "name" | "state" | "region" | "category" | "description" | "image_url" | "featured" | "views" | "video_url" | "created_at"
>;

function normalize(row: any): DbRecipe {
  return {
    ...row,
    ingredients: Array.isArray(row.ingredients) ? row.ingredients : [],
    steps: Array.isArray(row.steps) ? row.steps : [],
    nutrition: row.nutrition ?? {},
    tags: row.tags ?? [],
    views: Number(row.views ?? 0),
    video_url: row.video_url ?? null,
  } as DbRecipe;
}

export function youtubeUrl(name: string) {
  const q = encodeURIComponent(`${name} recipe`);
  return `https://www.youtube.com/results?search_query=${q}`;
}

export function useRecipes(opts: { state?: string; includeUnpublished?: boolean } = {}) {
  const qc = useQueryClient();
  const key = ["recipes", opts.state ?? "all", opts.includeUnpublished ? "all-status" : "published"];

  const q = useQuery({
    queryKey: key,
    queryFn: async () => {
      let query = supabase.from("recipes").select("*").order("created_at", { ascending: false });
      if (opts.state) query = query.eq("state", opts.state);
      if (!opts.includeUnpublished) query = query.eq("published", true);
      const { data, error } = await query;
      if (error) throw error;
      return (data ?? []).map(normalize);
    },
  });

  // Realtime sync
  useEffect(() => {
    const channel = supabase
      .channel("recipes-feed")
      .on("postgres_changes", { event: "*", schema: "public", table: "recipes" }, () => {
        qc.invalidateQueries({ queryKey: ["recipes"] });
        qc.invalidateQueries({ queryKey: ["recipe"] });
      })
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [qc]);

  return q;
}

export function useRecipeFeed(limit = 24) {
  const qc = useQueryClient();

  const q = useQuery({
    queryKey: ["recipe-feed", limit],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("recipes")
        .select("id,slug,name,state,region,category,description,image_url,featured,views,video_url,created_at")
        .eq("published", true)
        .order("created_at", { ascending: false })
        .limit(limit);
      if (error) throw error;
      return (data ?? []).map(row => ({ ...row, views: Number(row.views ?? 0) })) as RecipeFeedItem[];
    },
  });

  useEffect(() => {
    const channel = supabase
      .channel("recipe-feed")
      .on("postgres_changes", { event: "*", schema: "public", table: "recipes" }, () => {
        qc.invalidateQueries({ queryKey: ["recipe-feed"] });
      })
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [qc]);

  return q;
}

export function useRecipe(slug: string | undefined) {
  return useQuery({
    queryKey: ["recipe", slug],
    enabled: Boolean(slug),
    queryFn: async () => {
      const { data, error } = await supabase.from("recipes").select("*").eq("slug", slug!).maybeSingle();
      if (error) throw error;
      return data ? normalize(data) : null;
    },
  });
}

export const RAJASTHAN_CATEGORIES = [
  "All",
  "Main Course",
  "Curry",
  "Dry Sabzi",
  "Dal",
  "Bread",
  "Rice",
  "Snack",
  "Sweet",
  "Drink",
  "Non-Veg",
] as const;
