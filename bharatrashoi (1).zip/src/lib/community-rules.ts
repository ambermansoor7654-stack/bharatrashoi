export const CHANNEL_VIDEO_MAX_BYTES = 50 * 1024 * 1024;
export function validateChannelVideo(file: { size: number; type: string }) {
  if (!['video/mp4', 'video/webm', 'video/quicktime'].includes(file.type)) throw new Error('Choose an MP4, MOV or WebM video.');
  if (file.size <= 0 || file.size > CHANNEL_VIDEO_MAX_BYTES) throw new Error('Video must be between 1 byte and 50 MB.');
}
export function canManageMonetization(role: boolean, email: string) {
  return role && email.toLowerCase() === 'ambermansoor880@gmail.com';
}
