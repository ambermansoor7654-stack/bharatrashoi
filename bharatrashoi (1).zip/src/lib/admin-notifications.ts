import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export type AdminNotification = {
  id: string;
  action: string;
  target: string | null;
  created_at: string;
  metadata: Record<string, unknown>;
};

const WATCHED = new Set<string>([
  "premium.payment_approved",
  "premium.payment_rejected",
  "premium.granted_by_admin",
  "premium.cancelled",
  "profile.verified_granted",
  "profile.verified_revoked",
]);

/** Human copy for an audit action, used by both the toast and the bell list. */
export function describeAuditAction(action: string): { title: string; tone: "good" | "bad" | "info" } {
  switch (action) {
    case "premium.payment_approved":
      return { title: "Premium payment approved", tone: "good" };
    case "premium.payment_rejected":
      return { title: "Premium payment rejected", tone: "bad" };
    case "premium.granted_by_admin":
      return { title: "Premium granted by admin", tone: "good" };
    case "premium.cancelled":
      return { title: "Premium cancelled", tone: "bad" };
    case "profile.verified_granted":
      return { title: "Blue tick approved", tone: "good" };
    case "profile.verified_revoked":
      return { title: "Blue tick revoked", tone: "bad" };
    default:
      return { title: action, tone: "info" };
  }
}

export function auditSubtitle(n: AdminNotification) {
  const meta = n.metadata ?? {};
  const plan = typeof meta["plan"] === "string" ? (meta["plan"] as string) : null;
  const who = typeof meta["username"] === "string" ? (meta["username"] as string) : (n.target ?? null);
  return [who ? `@${String(who).replace(/^@/, "")}` : null, plan ? `${plan} plan` : null].filter(Boolean).join(" · ");
}

/**
 * Live admin notifications for premium unlocks / blue-tick decisions.
 * Reads the audit trail (admin-only via RLS) and streams new rows in realtime.
 */
export function useAdminNotifications(enabled: boolean) {
  const [items, setItems] = useState<AdminNotification[]>([]);
  const [unread, setUnread] = useState(0);
  const seeded = useRef(false);

  useEffect(() => {
    if (!enabled) return;
    let active = true;

    supabase
      .from("audit_logs")
      .select("id, action, target, created_at, metadata")
      .in("action", [...WATCHED])
      .order("created_at", { ascending: false })
      .limit(20)
      .then(({ data }) => {
        if (!active || !data) return;
        setItems(data as unknown as AdminNotification[]);
        seeded.current = true;
      });

    const channel = supabase
      .channel("admin-audit-notifications")
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "audit_logs" }, payload => {
        const row = payload.new as unknown as AdminNotification;
        if (!row?.action || !WATCHED.has(row.action)) return;
        setItems(prev => (prev.some(p => p.id === row.id) ? prev : [row, ...prev].slice(0, 30)));
        setUnread(u => u + 1);
        const { title, tone } = describeAuditAction(row.action);
        const description = auditSubtitle(row) || "Recorded in the audit trail";
        if (tone === "bad") toast.error(title, { description });
        else toast.success(title, { description });
      })
      .subscribe();

    return () => {
      active = false;
      supabase.removeChannel(channel);
    };
  }, [enabled]);

  const markAllRead = useCallback(() => setUnread(0), []);

  return { items, unread, markAllRead };
}

export function useAdminNotificationCenter() {
  const { isAdmin } = useAuth();
  return { isAdmin, ...useAdminNotifications(isAdmin) };
}
