export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.15"
  }
  public: {
    Tables: {
      audit_logs: {
        Row: {
          action: string
          actor_user_id: string | null
          created_at: string
          id: string
          ip: string | null
          metadata: Json
          target: string | null
          user_agent: string | null
        }
        Insert: {
          action: string
          actor_user_id?: string | null
          created_at?: string
          id?: string
          ip?: string | null
          metadata?: Json
          target?: string | null
          user_agent?: string | null
        }
        Update: {
          action?: string
          actor_user_id?: string | null
          created_at?: string
          id?: string
          ip?: string | null
          metadata?: Json
          target?: string | null
          user_agent?: string | null
        }
        Relationships: []
      }
      channel_subscriptions: {
        Row: {
          channel_id: string
          created_at: string
          user_id: string
        }
        Insert: {
          channel_id: string
          created_at?: string
          user_id: string
        }
        Update: {
          channel_id?: string
          created_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "channel_subscriptions_channel_id_fkey"
            columns: ["channel_id"]
            isOneToOne: false
            referencedRelation: "channels"
            referencedColumns: ["id"]
          },
        ]
      }
      channel_videos: {
        Row: {
          channel_id: string
          created_at: string
          description: string
          id: string
          owner_id: string
          state: string
          title: string
          video_path: string
        }
        Insert: {
          channel_id: string
          created_at?: string
          description?: string
          id?: string
          owner_id: string
          state?: string
          title: string
          video_path: string
        }
        Update: {
          channel_id?: string
          created_at?: string
          description?: string
          id?: string
          owner_id?: string
          state?: string
          title?: string
          video_path?: string
        }
        Relationships: [
          {
            foreignKeyName: "channel_videos_channel_id_fkey"
            columns: ["channel_id"]
            isOneToOne: false
            referencedRelation: "channels"
            referencedColumns: ["id"]
          },
        ]
      }
      channels: {
        Row: {
          avatar_path: string | null
          banner_path: string | null
          created_at: string
          description: string
          handle: string
          id: string
          monetized: boolean
          monetized_at: string | null
          name: string
          owner_id: string
          updated_at: string
        }
        Insert: {
          avatar_path?: string | null
          banner_path?: string | null
          created_at?: string
          description?: string
          handle: string
          id?: string
          monetized?: boolean
          monetized_at?: string | null
          name: string
          owner_id: string
          updated_at?: string
        }
        Update: {
          avatar_path?: string | null
          banner_path?: string | null
          created_at?: string
          description?: string
          handle?: string
          id?: string
          monetized?: boolean
          monetized_at?: string | null
          name?: string
          owner_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      chat_messages: {
        Row: {
          created_at: string
          id: string
          parts: Json
          role: string
          session_token: string
        }
        Insert: {
          created_at?: string
          id?: string
          parts: Json
          role: string
          session_token: string
        }
        Update: {
          created_at?: string
          id?: string
          parts?: Json
          role?: string
          session_token?: string
        }
        Relationships: []
      }
      correction_requests: {
        Row: {
          created_at: string
          id: string
          message: string
          recipe_id: string
          requested_by: string
          resolved_at: string | null
          resolved_by: string | null
          status: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          message: string
          recipe_id: string
          requested_by: string
          resolved_at?: string | null
          resolved_by?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          message?: string
          recipe_id?: string
          requested_by?: string
          resolved_at?: string | null
          resolved_by?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "correction_requests_recipe_id_fkey"
            columns: ["recipe_id"]
            isOneToOne: false
            referencedRelation: "recipe_stats"
            referencedColumns: ["recipe_id"]
          },
          {
            foreignKeyName: "correction_requests_recipe_id_fkey"
            columns: ["recipe_id"]
            isOneToOne: false
            referencedRelation: "recipes"
            referencedColumns: ["id"]
          },
        ]
      }
      creator_applications: {
        Row: {
          bio: string
          created_at: string
          id: string
          location: string | null
          message: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          specialties: string[]
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          bio?: string
          created_at?: string
          id?: string
          location?: string | null
          message?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          specialties?: string[]
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          bio?: string
          created_at?: string
          id?: string
          location?: string | null
          message?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          specialties?: string[]
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      daily_logins: {
        Row: {
          day: string
          email: string | null
          first_at: string
          last_at: string
          provider: string | null
          user_id: string
        }
        Insert: {
          day: string
          email?: string | null
          first_at?: string
          last_at?: string
          provider?: string | null
          user_id: string
        }
        Update: {
          day?: string
          email?: string | null
          first_at?: string
          last_at?: string
          provider?: string | null
          user_id?: string
        }
        Relationships: []
      }
      failed_logins: {
        Row: {
          created_at: string
          email: string
          id: string
          method: string
          reason: string | null
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          method: string
          reason?: string | null
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          method?: string
          reason?: string | null
        }
        Relationships: []
      }
      follows: {
        Row: {
          created_at: string
          creator_id: string
          follower_id: string
          id: string
        }
        Insert: {
          created_at?: string
          creator_id: string
          follower_id: string
          id?: string
        }
        Update: {
          created_at?: string
          creator_id?: string
          follower_id?: string
          id?: string
        }
        Relationships: []
      }
      food_favorites: {
        Row: {
          created_at: string
          food_data: Json
          food_name: string
          id: string
          session_token: string
        }
        Insert: {
          created_at?: string
          food_data: Json
          food_name: string
          id?: string
          session_token: string
        }
        Update: {
          created_at?: string
          food_data?: Json
          food_name?: string
          id?: string
          session_token?: string
        }
        Relationships: []
      }
      payments: {
        Row: {
          amount: number
          created_at: string
          currency: string
          id: string
          method: string
          note: string | null
          plan: string
          reference: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          currency?: string
          id?: string
          method?: string
          note?: string | null
          plan: string
          reference?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          currency?: string
          id?: string
          method?: string
          note?: string | null
          plan?: string
          reference?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      phone_otps: {
        Row: {
          attempts: number
          code_hash: string
          consumed_at: string | null
          created_at: string
          expires_at: string
          id: string
          phone_e164: string
        }
        Insert: {
          attempts?: number
          code_hash: string
          consumed_at?: string | null
          created_at?: string
          expires_at: string
          id?: string
          phone_e164: string
        }
        Update: {
          attempts?: number
          code_hash?: string
          consumed_at?: string | null
          created_at?: string
          expires_at?: string
          id?: string
          phone_e164?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          bio: string | null
          created_at: string
          creator_status: string
          display_name: string | null
          email: string | null
          food_preferences: string[]
          id: string
          is_creator: boolean
          is_premium: boolean
          location: string | null
          name: string | null
          onboarded: boolean
          payment_id: string | null
          premium_expiry_date: string | null
          premium_plan: string | null
          premium_start_date: string | null
          specialties: string[]
          updated_at: string
          username: string | null
          verified: boolean
        }
        Insert: {
          avatar_url?: string | null
          bio?: string | null
          created_at?: string
          creator_status?: string
          display_name?: string | null
          email?: string | null
          food_preferences?: string[]
          id: string
          is_creator?: boolean
          is_premium?: boolean
          location?: string | null
          name?: string | null
          onboarded?: boolean
          payment_id?: string | null
          premium_expiry_date?: string | null
          premium_plan?: string | null
          premium_start_date?: string | null
          specialties?: string[]
          updated_at?: string
          username?: string | null
          verified?: boolean
        }
        Update: {
          avatar_url?: string | null
          bio?: string | null
          created_at?: string
          creator_status?: string
          display_name?: string | null
          email?: string | null
          food_preferences?: string[]
          id?: string
          is_creator?: boolean
          is_premium?: boolean
          location?: string | null
          name?: string | null
          onboarded?: boolean
          payment_id?: string | null
          premium_expiry_date?: string | null
          premium_plan?: string | null
          premium_start_date?: string | null
          specialties?: string[]
          updated_at?: string
          username?: string | null
          verified?: boolean
        }
        Relationships: []
      }
      recipe_likes: {
        Row: {
          created_at: string
          id: string
          recipe_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          recipe_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          recipe_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "recipe_likes_recipe_id_fkey"
            columns: ["recipe_id"]
            isOneToOne: false
            referencedRelation: "recipe_stats"
            referencedColumns: ["recipe_id"]
          },
          {
            foreignKeyName: "recipe_likes_recipe_id_fkey"
            columns: ["recipe_id"]
            isOneToOne: false
            referencedRelation: "recipes"
            referencedColumns: ["id"]
          },
        ]
      }
      recipe_ratings: {
        Row: {
          created_at: string
          id: string
          rating: number
          recipe_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          rating: number
          recipe_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          rating?: number
          recipe_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "recipe_ratings_recipe_id_fkey"
            columns: ["recipe_id"]
            isOneToOne: false
            referencedRelation: "recipe_stats"
            referencedColumns: ["recipe_id"]
          },
          {
            foreignKeyName: "recipe_ratings_recipe_id_fkey"
            columns: ["recipe_id"]
            isOneToOne: false
            referencedRelation: "recipes"
            referencedColumns: ["id"]
          },
        ]
      }
      recipe_saves: {
        Row: {
          created_at: string
          id: string
          recipe_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          recipe_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          recipe_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "recipe_saves_recipe_id_fkey"
            columns: ["recipe_id"]
            isOneToOne: false
            referencedRelation: "recipe_stats"
            referencedColumns: ["recipe_id"]
          },
          {
            foreignKeyName: "recipe_saves_recipe_id_fkey"
            columns: ["recipe_id"]
            isOneToOne: false
            referencedRelation: "recipes"
            referencedColumns: ["id"]
          },
        ]
      }
      recipes: {
        Row: {
          author_id: string | null
          category: string
          chef_tips: string | null
          cook_time: string
          cover_image_url: string | null
          created_at: string
          created_by: string | null
          cuisine: string | null
          description: string
          difficulty: string
          featured: boolean
          id: string
          image_url: string | null
          images: Json
          ingredients: Json
          locked: boolean
          name: string
          nutrition: Json
          prep_time: string
          published: boolean
          region: string
          servings: number | null
          slug: string
          spice_level: string | null
          state: string
          status: string
          steps: Json
          tags: string[]
          updated_at: string
          video_url: string | null
          views: number
        }
        Insert: {
          author_id?: string | null
          category?: string
          chef_tips?: string | null
          cook_time?: string
          cover_image_url?: string | null
          created_at?: string
          created_by?: string | null
          cuisine?: string | null
          description?: string
          difficulty?: string
          featured?: boolean
          id?: string
          image_url?: string | null
          images?: Json
          ingredients?: Json
          locked?: boolean
          name: string
          nutrition?: Json
          prep_time?: string
          published?: boolean
          region?: string
          servings?: number | null
          slug: string
          spice_level?: string | null
          state?: string
          status?: string
          steps?: Json
          tags?: string[]
          updated_at?: string
          video_url?: string | null
          views?: number
        }
        Update: {
          author_id?: string | null
          category?: string
          chef_tips?: string | null
          cook_time?: string
          cover_image_url?: string | null
          created_at?: string
          created_by?: string | null
          cuisine?: string | null
          description?: string
          difficulty?: string
          featured?: boolean
          id?: string
          image_url?: string | null
          images?: Json
          ingredients?: Json
          locked?: boolean
          name?: string
          nutrition?: Json
          prep_time?: string
          published?: boolean
          region?: string
          servings?: number | null
          slug?: string
          spice_level?: string | null
          state?: string
          status?: string
          steps?: Json
          tags?: string[]
          updated_at?: string
          video_url?: string | null
          views?: number
        }
        Relationships: []
      }
      site_visits: {
        Row: {
          created_at: string
          day: string
          first_path: string | null
          visitor_id: string
        }
        Insert: {
          created_at?: string
          day: string
          first_path?: string | null
          visitor_id: string
        }
        Update: {
          created_at?: string
          day?: string
          first_path?: string | null
          visitor_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      profile_stats: {
        Row: {
          followers: number | null
          following: number | null
          likes_received: number | null
          recipes_count: number | null
          saved_count: number | null
          saves_received: number | null
          user_id: string | null
        }
        Insert: {
          followers?: never
          following?: never
          likes_received?: never
          recipes_count?: never
          saved_count?: never
          saves_received?: never
          user_id?: string | null
        }
        Update: {
          followers?: never
          following?: never
          likes_received?: never
          recipes_count?: never
          saved_count?: never
          saves_received?: never
          user_id?: string | null
        }
        Relationships: []
      }
      recipe_stats: {
        Row: {
          likes: number | null
          rating: number | null
          ratings_count: number | null
          recipe_id: string | null
          saves: number | null
        }
        Insert: {
          likes?: never
          rating?: never
          ratings_count?: never
          recipe_id?: string | null
          saves?: never
        }
        Update: {
          likes?: never
          rating?: never
          ratings_count?: never
          recipe_id?: string | null
          saves?: never
        }
        Relationships: []
      }
    }
    Functions: {
      channel_subscriber_counts: {
        Args: never
        Returns: {
          channel_id: string
          subscriber_count: number
        }[]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      increment_recipe_views: { Args: { _slug: string }; Returns: number }
    }
    Enums: {
      app_role: "admin" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user"],
    },
  },
} as const
